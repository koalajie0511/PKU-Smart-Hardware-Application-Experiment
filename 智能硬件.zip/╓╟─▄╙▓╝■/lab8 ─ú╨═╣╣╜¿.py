def extract_mfcc(path,n_mfcc=13):
    y,sr=librosa.load(path,sr=8000)
    mfcc=librosa.feature.mfcc(y=y,sr=sr,n_mfcc=n_mfcc,n_fft=256,hop_length=80)
    return mfcc.T
from hmmlearn import hmm
from sklearn.preprocessing import StandardScaler
models=[]
for digit in range(10):
    model=hmm.GMMHMM(
        n_components=5,
        n_mix=3,
        covariance_type="diag",
        n_iter=20,
        verbose=False,
        random_state=42)
    models.append(model)
    data=[[] for _ in range(10)]
    for m in meta:
        label=int(m["label"])
        feat=extract_mfcc(m["file"])
        data[label].append(feat)
    all_feats=np.vstack([f for d in data for f in d])
    scaler=StandardScaler()
    scaler.fit(all_feats)
    for d in range(10):
        data[d]=[scaler.transform(f) for f in data[d]]
    X=np.concatenate(data[digit])
    lengths=[len(x) for x in data[digit]]
    model.fit(X,lengths)
def predict(wav):
    feat=extract_mfcc(wav)
    scores=[m.score(feat) for m in models]
    return np.argmax(scores),scores
def save(self,path="models.pkl"):
    joblib.dump(self.models,path)
def load(self,path="models.pkl"):
    self.models=joblib.load(path)
