import cv2 as cv
def calculate_overlap(rect1, rect2):
    x1, y1, w1, h1 = rect1
    x2, y2, w2, h2 = rect2
    x_left = max(x1, x2)
    y_top = max(y1, y2)
    x_right = min(x1 + w1, x2 + w2)
    y_bottom = min(y1 + h1, y2 + h2)
    if x_right < x_left or y_bottom < y_top:
        return 0.0
    intersection_area = (x_right - x_left) * (y_bottom - y_top)
    area1 = w1 * h1
    area2 = w2 * h2
    return intersection_area / min(area1, area2)
def detect_face_eyes_advanced():
    face_cascade = cv.CascadeClassifier(cv.data.haarcascades + 'haarcascade_frontalface_default.xml')
    eye_cascade1 = cv.CascadeClassifier(cv.data.haarcascades + 'haarcascade_eye.xml')
    eye_cascade2 = cv.CascadeClassifier(cv.data.haarcascades + 'haarcascade_eye_tree_eyeglasses.xml')
    cap = cv.VideoCapture(0)
    if not cap.isOpened():
        print("无法打开摄像头")
        return
    cv.namedWindow('Advanced Face and Eyes Detection')
    try:
        while True:
            ret, img = cap.read()
            if not ret:
                print("无法读取帧")
                break
            gray = cv.cvtColor(img, cv.COLOR_BGR2GRAY)
            faces = face_cascade.detectMultiScale(gray, 1.3, 5)
            face_count = 0
            total_eye_count = 0
            for (x, y, w, h) in faces:
                face_count += 1
                cv.rectangle(img, (x, y), (x + w, y + h), (255, 0, 0), 2)
                cv.putText(img, f'Face {face_count}', (x, y-10), 
                          cv.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 0), 2)
                upper_face_height = int(h * 0.6)
                roi_gray = gray[y:y + upper_face_height, x:x + w]
                roi_color = img[y:y + upper_face_height, x:x + w]
                eyes1 = eye_cascade1.detectMultiScale(roi_gray, 1.1, 8, 
                                                     minSize=(20, 20), maxSize=(60, 60))
                eyes2 = eye_cascade2.detectMultiScale(roi_gray, 1.1, 10, 
                                                     minSize=(20, 20), maxSize=(60, 60))
                all_eyes = list(eyes1) + list(eyes2)
                final_eyes = []
                for i, eye1 in enumerate(all_eyes):
                    ex1, ey1, ew1, eh1 = eye1
                    keep = True
                    for j, eye2 in enumerate(all_eyes):
                        if i != j:
                            ex2, ey2, ew2, eh2 = eye2
                            overlap = calculate_overlap((ex1, ey1, ew1, eh1), 
                                                      (ex2, ey2, ew2, eh2))
                            if overlap > 0.5: 
                                if ew1 * eh1 < ew2 * eh2:  
                                    keep = False
                                    break
                    if keep:
                        final_eyes.append(eye1)
                eye_count = 0
                for (ex, ey, ew, eh) in final_eyes:
                    eye_count += 1
                    total_eye_count += 1
                    cv.rectangle(roi_color, (ex, ey), (ex + ew, ey + eh), (0, 255, 0), 2)
                    cv.putText(roi_color, f'Eye {eye_count}', (ex, ey-5), 
                              cv.FONT_HERSHEY_SIMPLEX, 0.4, (0, 255, 0), 1)
            cv.putText(img, f'Faces: {face_count}, Eyes: {total_eye_count}', 
                      (10, 30), cv.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
            cv.putText(img, 'Press Q to quit', (10, img.shape[0] - 10), 
                      cv.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
            
            cv.imshow('Advanced Face and Eyes Detection', img)
            key = cv.waitKey(1) & 0xFF
            if key == ord("q"):  
                break
    finally:
        cap.release()
        cv.destroyAllWindows()
if __name__ == "__main__":
    detect_face_eyes_advanced()
