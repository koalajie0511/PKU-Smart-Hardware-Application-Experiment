import time
import matplotlib.pyplot as plt
from bmp280 import BMP280

# 初始化BMP280传感器
sensor = BMP280("/dev/i2c-7", 0x76)

# 设置记录时长（秒）和采样间隔（秒）
duration = 60  # 一分钟
interval = 1   # 每秒一次

# 初始化存储时间和温度的列表
timestamps = []
temperatures = []

print(f"开始记录温度，持续{duration}秒，每秒采样一次...")

try:
    start_time = time.time()
    end_time = start_time + duration

    while time.time() < end_time:
        # 读取当前温度
        temp = sensor.get_temperature()
        current_time = time.time() - start_time

        # 记录时间和温度
        timestamps.append(current_time)
        temperatures.append(temp)

        print(f"时间: {current_time:.1f}s, 温度: {temp:.2f}°C")

        # 等待到下一秒
        time.sleep(interval - (time.time() % interval))

except KeyboardInterrupt:
    print("用户中断记录")
finally:
    sensor.close()

# 绘制温度变化曲线
plt.figure(figsize=(10, 6))
plt.plot(timestamps, temperatures, 'b-', marker='o', markersize=3)
plt.title('BMP280 温度变化曲线 (1分钟)')
plt.xlabel('时间 (秒)')
plt.ylabel('温度 (°C)')
plt.grid(True, linestyle='--', alpha=0.7)
plt.tight_layout()

# 保存图像（可选）
plt.savefig('temperature_plot.png', dpi=300)

# 显示图像
plt.show()

print("温度记录完成，图表已显示并保存。")
