import cv2 as cv
import numpy as np
import time
global frame #frame表示由摄像头拍到的照片
time.sleep(1)
while True:
    #读取frame
    hsv=cv.cvtColor(frame,cv.COLOR_BGR2HSV)
    image_mask=cv.inRange(hsv,np.array([40,50,50]),np.array([80,255,255]))
    output=cv.bitwise_and(frame,frame,mask=image_mask)
    cv.imshow(Original,frame)
    if cv.waitkey(1)==ord("q"):
        break
points=[]
def mouse_callback(event,x,y,flags,param):
    if event==cv.EVENT_LBUTTONDOWN:
        print(x,y)
        points.append(x,y)
resized_image=cv.resize(image,(800,600))
cv.namedWindow(1)
cv.setMouseCallback(1,mouse_callback)
while(1):
    cv.imshow(1,resized_image)
    if (cv.waitKey(1)&0xFF==27): #按Esc退出
        break
x11=points[0][0]
y11=points[0][1]
x21=points[1][0]
y21=points[1][1]
x31=points[2][0]
y31=points[2][1]
x41=points[3][0]
y41=points[3][1]
print(x11,y11,x21,y21,x31,y31,x41,y41)
original_points=np.float32([[x11,y11],[x21,y21],[x31,y31],[x41,y41]])
target_points=np.float32([[0,0],[800,0],[0,600],[800,600]])
perspective_matrix=cv.getPerspectiveTransform(original_points,target_points)
output_image=cv.warpPerspective(image,perspective_matrix,(600,450))
cv.imshow(Result,output_image)
cv.waitKey(0)
