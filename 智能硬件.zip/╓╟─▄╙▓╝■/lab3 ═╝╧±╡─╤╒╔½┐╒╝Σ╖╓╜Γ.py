import cv2
from IPython.display import display
import ipywidgets as widgets
from io import BytesIO
import numpy as np
cap=cv2.VideoCapture(0)
if not cap.isOpened():
    print("无法打开摄像头")
else:
    #分别显示原始图像和过滤后的图像
    original_image_widget=widgets.Image(format="jpeg",description="原始图像")
    filtered_image_widget=widgets.Image(format="jpeg",description="HSV过滤图像")
    display(widgets.HBox([original_image_widget,filtered_image_widget]))
    try:
        while True:
            ret,frame=cap.read()
            if not ret:
                print("无法接收")
                break
            hsv=cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)
            lower_green=np.array([40,50,50])
            upper_green=np.array([80,255,255])
            image_mask=cv2.inRange(hsv,lower_green,upper_green)
            output=cv2.bitwise_and(hsv,hsv,mask=image_mask)
            is_success,original_buffer=cv2.imencode(".jpg",frame)
            if is_success:
                original_io_buf=BytesIO(original_buffer)
                original_image_widget.value=original_io_buf.getvalue()
            else:
                print("原始图像编码失败")
            is_success,filtered_buffer=cv2.imencode(".jpg",cv2,cvtColor(output,cv2.COLOR_HSV2RGB))
            if is_success:
                filtered_io_buf=BytesIO(filtered_buffer)
                filtered_image_widget.value=filtered_io_buf.getvalue()
            else:
                print("过滤图像编码失败")
    except KeyboardInterrupt:
        print("用户中断")
    finally:
        cap.release()
