from periphery import GPIO
import time
button=GPIO(2,"in")
gpio=GPIO(3,"out")
button.edge="falling"
state=False
try:
    while True:
        if button.poll(timeout=1.0):
            button.read()
            if state==False: #此时灯光熄灭
                gpio.write(True)
                state=True
                print("Light on!")
            else:
                gpio.write(False)
                state=False
                print("Light off!")
            time.sleep(0.2)
except KeyboardInterrupt:
    button.close()
    print("\nProgram stopped by user")
finally:
    gpio.write(False)
    gpio.close()
    button.close()
    print("GPIO resources released")
