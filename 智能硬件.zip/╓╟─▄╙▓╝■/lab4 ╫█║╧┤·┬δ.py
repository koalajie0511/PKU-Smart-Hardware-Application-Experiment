import matplotlib.pyplot as plt
from periphery import GPIO, SPI
import time
from sklearn import datasets, svm, metrics
from PIL import Image, ImageDraw, ImageFont
import numpy as np
import os
import cv2 as cv
from IPython.display import display, clear_output
import ipywidgets as widgets
from io import BytesIO
import threading

# 加载和准备数字数据集
digits = datasets.load_digits()
images_and_labels = list(zip(digits.images, digits.target))

for index, (image, label) in enumerate(images_and_labels[:4]):
    plt.subplot(2, 4, index + 1)
    plt.axis("off")
    plt.imshow(image, cmap=plt.cm.gray_r, interpolation="nearest")
    plt.title("Training: %i" % label)

n_samples = len(digits.images)
data = digits.images.reshape((n_samples, -1))

classifier = svm.SVC(gamma=0.001)
classifier.fit(data[:n_samples // 2], digits.target[:n_samples // 2])

expected = digits.target[n_samples // 2:]
predicted = classifier.predict(data[n_samples // 2:])

print("Classification report for classifier %s:\n%s\n"
      % (classifier, metrics.classification_report(expected, predicted)))
print("Confusion matrix:\n%s" % metrics.confusion_matrix(expected, predicted))

images_and_predictions = list(zip(digits.images[n_samples // 2:], predicted))

for index, (image, prediction) in enumerate(images_and_predictions[:4]):
    plt.subplot(2, 4, index + 5)
    plt.axis("off")
    plt.imshow(image, cmap=plt.cm.gray_r, interpolation="nearest")
    plt.title("Prediction: %i" % prediction)

plt.show()

# 创建显示控件
original_image = widgets.Image(format="jpeg", width=300, height=300, description="原始图像")
contour_image = widgets.Image(format="jpeg", width=300, height=300, description="轮廓检测")
prediction_text = widgets.HTML(value="<h2>预测结果: </h2>")

# 创建容器
image_box = widgets.HBox([original_image, contour_image])
main_box = widgets.VBox([image_box, prediction_text])

# 显示控件
display(main_box)

cap = cv.VideoCapture(0)

def preprocess_for_contours(image):
    """改进的预处理图像以更好地检测轮廓"""
    # 转换为灰度图
    gray = cv.cvtColor(image, cv.COLOR_BGR2GRAY)
    
    # 高斯模糊去噪 - 调整参数
    blurred = cv.GaussianBlur(gray, (7, 7), 0)
    
    # 使用Otsu阈值处理
    _, thresh_otsu = cv.threshold(blurred, 0, 255, cv.THRESH_BINARY_INV + cv.THRESH_OTSU)
    
    # 同时使用自适应阈值作为备选
    thresh_adaptive = cv.adaptiveThreshold(blurred, 255, cv.ADAPTIVE_THRESH_GAUSSIAN_C, 
                                         cv.THRESH_BINARY_INV, 15, 5)
    
    # 结合两种阈值结果
    thresh_combined = cv.bitwise_or(thresh_otsu, thresh_adaptive)
    
    # 改进的形态学操作
    kernel_open = np.ones((2, 2), np.uint8)
    kernel_close = np.ones((3, 3), np.uint8)
    
    # 先开运算去除小噪声
    thresh_cleaned = cv.morphologyEx(thresh_combined, cv.MORPH_OPEN, kernel_open)
    # 再闭运算连接断裂部分
    thresh_cleaned = cv.morphologyEx(thresh_cleaned, cv.MORPH_CLOSE, kernel_close)
    
    return thresh_cleaned

def find_digit_contours(thresh, original):
    """改进的数字轮廓查找和框定"""
    # 创建原始图像的副本
    result = original.copy()
    
    # 查找轮廓
    contours, hierarchy = cv.findContours(thresh, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE)
    
    # 筛选可能的数字轮廓
    digit_contours = []
    
    for contour in contours:
        # 计算轮廓面积
        area = cv.contourArea(contour)
        
        # 计算边界矩形
        x, y, w, h = cv.boundingRect(contour)
        
        # 计算轮廓周长
        perimeter = cv.arcLength(contour, True)
        
        # 计算轮廓的紧凑度
        if perimeter > 0:
            compactness = 4 * np.pi * area / (perimeter * perimeter)
        else:
            compactness = 0
        
        # 改进的筛选条件：
        # 1. 面积适中
        # 2. 宽高比合理（考虑数字的形状特征）
        # 3. 紧凑度适中（排除过于不规则的形状）
        # 4. 最小尺寸限制
        # 5. 最大尺寸限制（避免检测到整个图像）
        
        min_area = 300
        max_area = original.shape[0] * original.shape[1] * 0.3  # 最大为图像的30%
        min_width = 25
        min_height = 35
        max_width = original.shape[1] * 0.7
        max_height = original.shape[0] * 0.7
        
        aspect_ratio = w / h if h > 0 else 0
        
        if (area > min_area and area < max_area and
            w > min_width and h > min_height and
            w < max_width and h < max_height and
            0.2 < aspect_ratio < 3.0 and
            0.1 < compactness < 1.0):  # 紧凑度筛选
            
            digit_contours.append(contour)
            
            # 使用最小外接矩形获得更精确的边界
            rect = cv.minAreaRect(contour)
            box = cv.boxPoints(rect)
            box = np.int0(box)
            
            # 绘制最小外接矩形
            cv.drawContours(result, [box], 0, (0, 255, 0), 2)
            
            # 添加更详细的标签
            cv.putText(result, f"Digit: {area:.0f}", (x, y-10), 
                      cv.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
    
    # 如果找到多个轮廓，选择最可能是数字的那个
    if len(digit_contours) > 1:
        # 根据面积、位置和形状特征排序
        digit_contours.sort(key=lambda c: (
            cv.contourArea(c),  # 面积
            -cv.boundingRect(c)[1]  # 位置（y坐标越小越靠上）
        ), reverse=True)
        # 只保留最可能的一个
        digit_contours = [digit_contours[0]]
    
    return result, digit_contours

def extract_digit_roi(thresh, contour):
    """从轮廓中精确提取数字ROI区域"""
    # 获取轮廓的边界矩形
    x, y, w, h = cv.boundingRect(contour)
    
    # 添加一些边距以确保完整捕获数字
    margin = 5
    x = max(0, x - margin)
    y = max(0, y - margin)
    w = min(thresh.shape[1] - x, w + 2 * margin)
    h = min(thresh.shape[0] - y, h + 2 * margin)
    
    # 提取ROI
    roi = thresh[y:y+h, x:x+w]
    
    # 进一步清理ROI
    if roi.size > 0:
        # 去除小的孤立点
        kernel_clean = np.ones((2, 2), np.uint8)
        roi = cv.morphologyEx(roi, cv.MORPH_OPEN, kernel_clean)
        
        # 确保数字是白色，背景是黑色
        if np.mean(roi) > 127:  # 如果主要是白色，需要反转
            roi = cv.bitwise_not(roi)
    
    return roi, (x, y, w, h)

def extract_and_predict_digit(original, thresh, contours):
    """改进的数字提取和预测"""
    if not contours:
        return None
    
    # 选择最可能的轮廓
    best_contour = contours[0]
    
    # 精确提取ROI区域
    roi, (x, y, w, h) = extract_digit_roi(thresh, best_contour)
    
    if roi.size == 0:
        return None
    
    # 预处理用于预测
    try:
        # 调整到MNIST数据集的大小 (8x8)
        resized = cv.resize(roi, (8, 8), interpolation=cv.INTER_AREA)
        
        # 归一化到0-16范围，与训练数据匹配
        resized_normalized = cv.normalize(resized, None, 0, 16, cv.NORM_MINMAX)
        
        # 转换为整数类型
        digit_data = resized_normalized.astype(np.uint8)
        
        # 重塑并预测
        reshaped = digit_data.reshape(1, -1)
        prediction = classifier.predict(reshaped)
        
        return prediction[0]
        
    except Exception as e:
        print(f"预测处理错误: {e}")
        return None

def update_display():
    """更新显示的帧"""
    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                print("无法读取摄像头画面")
                break
            
            # 预处理图像进行轮廓检测
            thresh = preprocess_for_contours(frame)
            contour_result, digit_contours = find_digit_contours(thresh, frame)
            prediction = None
            if digit_contours:
                prediction = extract_and_predict_digit(frame, thresh, digit_contours)
            if prediction is not None:
                cv.putText(contour_result, f"Prediction: {prediction}", 
                          (10, 30), cv.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2)
                cv.putText(contour_result, f"Confidence: High", 
                          (10, 60), cv.FONT_HERSHEY_SIMPLEX, 0.7, (255, 0, 0), 2)
            _, original_jpeg = cv.imencode('.jpg', frame)
            _, contour_jpeg = cv.imencode('.jpg', contour_result)
            original_image.value = original_jpeg.tobytes()
            contour_image.value = contour_jpeg.tobytes()
            if prediction is not None:
                prediction_text.value = f"<h2 style='color: green;'>预测数字: {prediction}</h2>"
            else:
                prediction_text.value = "<h2 style='color: red;'>未检测到数字</h2>"
            
            time.sleep(0.2) 
            
    except Exception as e:
        print(f"发生错误: {e}")
    finally:
        cap.release()
display_thread = threading.Thread(target=update_display)
display_thread.daemon = True
display_thread.start()

























import matplotlib.pyplot as plt

from sklearn import datasets,svm,metrics

digits=datasets.load_digits()

images_and_labels=list(zip(digits.images,digits.target))

for index,(image,label) in enumerate(images_and_labels[:4]):

    plt.subplot(2,4,index+1)

    plt.axis("off")

    plt.imshow(image,cmap=plt.cm.gray_r,interpolation="nearest")

    plt.title("Training: %i"%label)

n_samples=len(digits.images)

data=digits.images.reshape((n_samples,-1))

classifier=svm.SVC(gamma=0.001)

classifier.fit(data[:n_samples//2],digits.target[:n_samples//2])

expected=digits.target[n_samples//2:]

predicted=classifier.predict(data[n_samples//2:])

print("Classification report for classifier %s:\n%s\n"

      % (classifier , metrics.classification_report(expected , predicted)))

print("Confusion matrix:\n%s" % metrics.confusion_matrix(expected , predicted))

images_and_predictions=list(zip(digits.images[n_samples//2:],predicted))

for index,(image,prediction) in enumerate(images_and_predictions[:4]):

    plt.subplot(2,4,index+5)

    plt.axis("off")

    plt.imshow(image,cmap=plt.cm.gray_r,interpolation="nearest")

    plt.title("Prediction: %i"%prediction)

plt.show()




















import matplotlib.pyplot as plt

from sklearn import datasets, svm, metrics

import numpy as np

digits = datasets.load_digits()

images_and_labels = list(zip(digits.images, digits.target))

for index, (image, label) in enumerate(images_and_labels[:4]):

    plt.subplot(2, 4, index + 1)

    plt.axis("off")

    plt.imshow(image, cmap=plt.cm.gray_r, interpolation="nearest")

    plt.title("Training: %i" % label)

n_samples = len(digits.images)

data = digits.images.reshape((n_samples, -1))

kernels = ['linear', 'poly', 'rbf', 'sigmoid']

for kernel in kernels:

    print(f"\n{'='*50}")

    print(f"使用核函数: {kernel}")

    print(f"{'='*50}")

    if kernel == 'rbf':

        classifier = svm.SVC(kernel=kernel, gamma=0.001)

    elif kernel == 'poly':

        classifier = svm.SVC(kernel=kernel, degree=3, gamma='scale')  # 多项式核可以调整degree

    else:

        classifier = svm.SVC(kernel=kernel, gamma='scale')

    classifier.fit(data[:n_samples//2], digits.target[:n_samples//2])

    expected = digits.target[n_samples//2:]

    predicted = classifier.predict(data[n_samples//2:])

    print("Classification report:\n%s" 

          % metrics.classification_report(expected, predicted))

    print("Accuracy: %.4f" % metrics.accuracy_score(expected, predicted))

    print("Confusion matrix:\n%s" % metrics.confusion_matrix(expected, predicted))






from periphery import SPI, GPIO
from PIL import Image, ImageDraw, ImageFont
import time
# === SSD1306 command constants ===
SSD1306_SETCONTRAST = 0x81
SSD1306_DISPLAYALLON_RESUME = 0xA4
SSD1306_DISPLAYALLON = 0xA5
SSD1306_NORMALDISPLAY = 0xA6
SSD1306_INVERTDISPLAY = 0xA7
SSD1306_DISPLAYOFF = 0xAE
SSD1306_DISPLAYON = 0xAF
SSD1306_SETDISPLAYOFFSET = 0xD3
SSD1306_SETCOMPINS = 0xDA
SSD1306_SETVCOMDETECT = 0xDB
SSD1306_SETDISPLAYCLOCKDIV = 0xD5
SSD1306_SETPRECHARGE = 0xD9
SSD1306_SETMULTIPLEX = 0xA8
SSD1306_SETSTARTLINE = 0x40
SSD1306_MEMORYMODE = 0x20
SSD1306_COLUMNADDR = 0x21
SSD1306_PAGEADDR = 0x22
SSD1306_COMSCANINC = 0xC0
SSD1306_COMSCANDEC = 0xC8
SSD1306_SEGREMAP = 0xA0
SSD1306_CHARGEPUMP = 0x8D
SSD1306_EXTERNALVCC = 0x1
SSD1306_SWITCHCAPVCC = 0x2


class SSD1306:
    """SSD1306 OLED driver using python-periphery (SPI + GPIO)."""

    def __init__(self, rst, dc, spi_dev="/dev/spidev0.0", vccstate=SSD1306_SWITCHCAPVCC):
        self.width = 128
        self.height = 64
        self._pages = self.height // 8
        self._buffer = [0x00] * (self.width * self._pages)
        self._vccstate = vccstate

        # Initialize GPIOs
        self._rst = GPIO(rst, "out")
        self._dc = GPIO(dc, "out")

        # Initialize SPI
        self._spi = SPI(spi_dev, 0, 1000000)  # 1 MHz safe default
        self._spi.mode = 0
        self._spi.bit_order = "msb"
        self._spi.bits_per_word = 8

    # === Low-level helpers ===
    def command(self, cmd):
        self._dc.write(False)
        self._spi.transfer([cmd])

    def data(self, val):
        if isinstance(val, int):
            val = [val]
        self._dc.write(True)
        self._spi.transfer(val)

    # === High-level methods ===
    def reset(self):
        """Reset the OLED controller."""
        self._rst.write(True)
        time.sleep(0.001)
        self._rst.write(False)
        time.sleep(0.01)
        self._rst.write(True)
        time.sleep(0.05)

    def begin(self):
        """Initialize the display hardware."""
        self.reset()

        self.command(SSD1306_DISPLAYOFF)
        self.command(SSD1306_SETDISPLAYCLOCKDIV)
        self.command(0x80)

        self.command(SSD1306_SETMULTIPLEX)
        self.command(0x3F)

        self.command(SSD1306_SETDISPLAYOFFSET)
        self.command(0x00)

        self.command(SSD1306_SETSTARTLINE | 0x00)

        self.command(SSD1306_CHARGEPUMP)
        if self._vccstate == SSD1306_EXTERNALVCC:
            self.command(0x10)
        else:
            self.command(0x14)

        self.command(SSD1306_MEMORYMODE)
        self.command(0x00)

        self.command(SSD1306_SEGREMAP | 0x1)
        self.command(SSD1306_COMSCANDEC)

        self.command(SSD1306_SETCOMPINS)
        self.command(0x12)

        self.command(SSD1306_SETCONTRAST)
        if self._vccstate == SSD1306_EXTERNALVCC:
            self.command(0x9F)
        else:
            self.command(0xCF)

        self.command(SSD1306_SETPRECHARGE)
        if self._vccstate == SSD1306_EXTERNALVCC:
            self.command(0x22)
        else:
            self.command(0xF1)

        self.command(SSD1306_SETVCOMDETECT)
        self.command(0x40)

        self.command(SSD1306_DISPLAYALLON_RESUME)
        self.command(SSD1306_NORMALDISPLAY)
        self.command(SSD1306_DISPLAYON)

    def clear(self):
        """Clear display buffer."""
        self._buffer = [0x00] * (self.width * self._pages)

    def image(self, image):
        """Copy a PIL image into the internal buffer."""
        if image.mode != "1":
            raise ValueError("Image must be in mode '1' (1-bit pixels).")
        if image.size != (self.width, self.height):
            raise ValueError(f"Image must be {self.width}x{self.height}")

        pix = image.load()
        idx = 0
        for page in range(self._pages):
            for x in range(self.width):
                bits = 0
                for bit in range(8):
                    y = page * 8 + bit
                    if pix[x, y]:
                        bits |= (1 << bit)
                self._buffer[idx] = bits
                idx += 1

    def display(self):
        """Flush the internal buffer to the OLED display."""
        self.command(SSD1306_COLUMNADDR)
        self.command(0)
        self.command(self.width - 1)

        self.command(SSD1306_PAGEADDR)
        self.command(0)
        self.command(self._pages - 1)

        self.data(self._buffer)

    def set_contrast(self, contrast):
        """Set display contrast (0–255)."""
        if not 0 <= contrast <= 255:
            raise ValueError("Contrast must be between 0–255.")
        self.command(SSD1306_SETCONTRAST)
        self.command(contrast)

    def dim(self, dim_on):
        """Dim or undim display."""
        contrast = 0x00 if dim_on else (0x9F if self._vccstate == SSD1306_EXTERNALVCC else 0xCF)
        self.set_contrast(contrast)

    def close(self):
        """Release GPIO and SPI."""
        self._spi.close()
        self._rst.close()
        self._dc.close()
disp=SSD1306(rst=3,dc=81,spi_dev="/dev/spidev0.0")
disp.begin()
disp.clear()
img=Image.new("1",(disp.width,disp.height))
draw=ImageDraw.Draw(img)
font=ImageFont.load_default()
draw.text((0,0),"Hello World!",fill=255)
disp.image(img)
disp.display()
print("success!")
disp.close()



















from periphery import SPI, GPIO
from PIL import Image
import time

# === SSD1306 command constants ===
SSD1306_SETCONTRAST = 0x81
SSD1306_DISPLAYALLON_RESUME = 0xA4
SSD1306_DISPLAYALLON = 0xA5
SSD1306_NORMALDISPLAY = 0xA6
SSD1306_INVERTDISPLAY = 0xA7
SSD1306_DISPLAYOFF = 0xAE
SSD1306_DISPLAYON = 0xAF
SSD1306_SETDISPLAYOFFSET = 0xD3
SSD1306_SETCOMPINS = 0xDA
SSD1306_SETVCOMDETECT = 0xDB
SSD1306_SETDISPLAYCLOCKDIV = 0xD5
SSD1306_SETPRECHARGE = 0xD9
SSD1306_SETMULTIPLEX = 0xA8
SSD1306_SETSTARTLINE = 0x40
SSD1306_MEMORYMODE = 0x20
SSD1306_COLUMNADDR = 0x21
SSD1306_PAGEADDR = 0x22
SSD1306_COMSCANINC = 0xC0
SSD1306_COMSCANDEC = 0xC8
SSD1306_SEGREMAP = 0xA0
SSD1306_CHARGEPUMP = 0x8D
SSD1306_EXTERNALVCC = 0x1
SSD1306_SWITCHCAPVCC = 0x2

class SSD1306:
    """SSD1306 OLED driver using python-periphery (SPI + GPIO)."""

    def __init__(self, rst, dc, spi_dev="/dev/spidev0.0", vccstate=SSD1306_SWITCHCAPVCC):
        self.width = 128
        self.height = 64
        self._pages = self.height // 8
        self._buffer = [0x00] * (self.width * self._pages)
        self._vccstate = vccstate

        # Initialize GPIOs
        self._rst = GPIO(rst, "out")
        self._dc = GPIO(dc, "out")

        # Initialize SPI
        self._spi = SPI(spi_dev, 0, 1000000)  # 1 MHz safe default
        self._spi.mode = 0
        self._spi.bit_order = "msb"
        self._spi.bits_per_word = 8

    # === Low-level helpers ===
    def command(self, cmd):
        self._dc.write(False)
        self._spi.transfer([cmd])

    def data(self, val):
        if isinstance(val, int):
            val = [val]
        self._dc.write(True)
        self._spi.transfer(val)

    # === High-level methods ===
    def reset(self):
        """Reset the OLED controller."""
        self._rst.write(True)
        time.sleep(0.001)
        self._rst.write(False)
        time.sleep(0.01)
        self._rst.write(True)
        time.sleep(0.05)

    def begin(self):
        """Initialize the display hardware."""
        self.reset()

        self.command(SSD1306_DISPLAYOFF)
        self.command(SSD1306_SETDISPLAYCLOCKDIV)
        self.command(0x80)

        self.command(SSD1306_SETMULTIPLEX)
        self.command(0x3F)

        self.command(SSD1306_SETDISPLAYOFFSET)
        self.command(0x00)

        self.command(SSD1306_SETSTARTLINE | 0x00)

        self.command(SSD1306_CHARGEPUMP)
        if self._vccstate == SSD1306_EXTERNALVCC:
            self.command(0x10)
        else:
            self.command(0x14)

        self.command(SSD1306_MEMORYMODE)
        self.command(0x00)

        self.command(SSD1306_SEGREMAP | 0x1)
        self.command(SSD1306_COMSCANDEC)

        self.command(SSD1306_SETCOMPINS)
        self.command(0x12)

        self.command(SSD1306_SETCONTRAST)
        if self._vccstate == SSD1306_EXTERNALVCC:
            self.command(0x9F)
        else:
            self.command(0xCF)

        self.command(SSD1306_SETPRECHARGE)
        if self._vccstate == SSD1306_EXTERNALVCC:
            self.command(0x22)
        else:
            self.command(0xF1)

        self.command(SSD1306_SETVCOMDETECT)
        self.command(0x40)

        self.command(SSD1306_DISPLAYALLON_RESUME)
        self.command(SSD1306_NORMALDISPLAY)
        self.command(SSD1306_DISPLAYON)

    def clear(self):
        """Clear display buffer."""
        self._buffer = [0x00] * (self.width * self._pages)

    def image(self, image):
        """Copy a PIL image into the internal buffer."""
        if image.mode != "1":
            raise ValueError("Image must be in mode '1' (1-bit pixels).")
        if image.size != (self.width, self.height):
            raise ValueError(f"Image must be {self.width}x{self.height}")

        pix = image.load()
        idx = 0
        for page in range(self._pages):
            for x in range(self.width):
                bits = 0
                for bit in range(8):
                    y = page * 8 + bit
                    if pix[x, y]:
                        bits |= (1 << bit)
                self._buffer[idx] = bits
                idx += 1

    def display(self):
        """Flush the internal buffer to the OLED display."""
        self.command(SSD1306_COLUMNADDR)
        self.command(0)
        self.command(self.width - 1)

        self.command(SSD1306_PAGEADDR)
        self.command(0)
        self.command(self._pages - 1)

        self.data(self._buffer)

    def close(self):
        """Release GPIO and SPI."""
        self._spi.close()
        self._rst.close()
        self._dc.close()

# 初始化显示设备
# 请根据实际硬件连接修改 GPIO 引脚号
disp = SSD1306(rst=3, dc=81)  # 修改为实际连接的引脚
disp.begin()

try:
    # 加载并调整图像大小
    pku = Image.open("opencv-logo-white.png")
    
    # 调整图像大小以适应显示屏（128x64）
    pku = pku.resize((128, 64), Image.LANCZOS).convert('1')
    
    # 创建黑色背景图像
    image = Image.new("1", (disp.width, disp.height), "black")
    
    # 将调整后的图像粘贴到背景中（居中显示）
    pku_size = pku.size
    x_offset = (disp.width - pku_size[0]) // 2
    y_offset = (disp.height - pku_size[1]) // 2
    image.paste(pku, (x_offset, y_offset))
    
    # 显示图像
    disp.clear()
    disp.image(image)
    disp.display()
    
    print("OpenCV logo 显示成功！")
    
    # 保持显示
    while True:
        time.sleep(1)

except FileNotFoundError:
    print("错误：opencv-logo-white.png 文件未找到")
    print("请确保图片文件存在于当前目录")
except Exception as e:
    print(f"发生错误：{e}")
finally:
    # 清理资源
    disp.close()















import matplotlib.pyplot as plt
from periphery import GPIO, SPI
import time
from sklearn import datasets, svm, metrics
from PIL import Image, ImageDraw, ImageFont
import numpy as np
import os

# Load and prepare the digits dataset
digits = datasets.load_digits()
images_and_labels = list(zip(digits.images, digits.target))

for index, (image, label) in enumerate(images_and_labels[:4]):
    plt.subplot(2, 4, index + 1)
    plt.axis("off")
    plt.imshow(image, cmap=plt.cm.gray_r, interpolation="nearest")
    plt.title("Training: %i" % label)

n_samples = len(digits.images)
data = digits.images.reshape((n_samples, -1))

classifier = svm.SVC(gamma=0.001)
classifier.fit(data[:n_samples // 2], digits.target[:n_samples // 2])

expected = digits.target[n_samples // 2:]
predicted = classifier.predict(data[n_samples // 2:])

print("Classification report for classifier %s:\n%s\n"
      % (classifier, metrics.classification_report(expected, predicted)))
print("Confusion matrix:\n%s" % metrics.confusion_matrix(expected, predicted))

images_and_predictions = list(zip(digits.images[n_samples // 2:], predicted))

for index, (image, prediction) in enumerate(images_and_predictions[:4]):
    plt.subplot(2, 4, index + 5)
    plt.axis("off")
    plt.imshow(image, cmap=plt.cm.gray_r, interpolation="nearest")
    plt.title("Prediction: %i" % prediction)

plt.show()

a = n_samples // 2
SSD1306_SETCONTRAST = 0x81
SSD1306_DISPLAYALLON_RESUME = 0xA4
SSD1306_DISPLAYALLON = 0xA5
SSD1306_NORMALDISPLAY = 0xA6
SSD1306_INVERTDISPLAY = 0xA7
SSD1306_DISPLAYOFF = 0xAE
SSD1306_DISPLAYON = 0xAF
SSD1306_SETDISPLAYOFFSET = 0xD3
SSD1306_SETCOMPINS = 0xDA
SSD1306_SETVCOMDETECT = 0xDB
SSD1306_SETDISPLAYCLOCKDIV = 0xD5
SSD1306_SETPRECHARGE = 0xD9
SSD1306_SETMULTIPLEX = 0xA8
SSD1306_SETSTARTLINE = 0x40
SSD1306_MEMORYMODE = 0x20
SSD1306_COLUMNADDR = 0x21
SSD1306_PAGEADDR = 0x22
SSD1306_COMSCANINC = 0xC0
SSD1306_COMSCANDEC = 0xC8
SSD1306_SEGREMAP = 0xA0
SSD1306_CHARGEPUMP = 0x8D
SSD1306_EXTERNALVCC = 0x1
SSD1306_SWITCHCAPVCC = 0x2

class SSD1306:
    """SSD1306 OLED driver using python-periphery (SPI + GPIO)."""

    def __init__(self, rst, dc, spi_dev="/dev/spidev0.0", vccstate=SSD1306_SWITCHCAPVCC):
        self.width = 128
        self.height = 64
        self._pages = self.height // 8
        self._buffer = [0x00] * (self.width * self._pages)
        self._vccstate = vccstate

        # Initialize GPIOs
        self._rst = GPIO(rst, "out")
        self._dc = GPIO(dc, "out")

        # Initialize SPI
        self._spi = SPI(spi_dev, 0, 1000000)  # 1 MHz safe default
        self._spi.mode = 0
        self._spi.bit_order = "msb"
        self._spi.bits_per_word = 8

    # === Low-level helpers ===
    def command(self, cmd):
        self._dc.write(False)
        self._spi.transfer([cmd])

    def data(self, val):
        if isinstance(val, int):
            val = [val]
        self._dc.write(True)
        self._spi.transfer(val)

    # === High-level methods ===
    def reset(self):
        """Reset the OLED controller."""
        self._rst.write(True)
        time.sleep(0.001)
        self._rst.write(False)
        time.sleep(0.01)
        self._rst.write(True)
        time.sleep(0.05)

    def begin(self):
        """Initialize the display hardware."""
        self.reset()

        self.command(SSD1306_DISPLAYOFF)
        self.command(SSD1306_SETDISPLAYCLOCKDIV)
        self.command(0x80)

        self.command(SSD1306_SETMULTIPLEX)
        self.command(0x3F)

        self.command(SSD1306_SETDISPLAYOFFSET)
        self.command(0x00)

        self.command(SSD1306_SETSTARTLINE | 0x00)

        self.command(SSD1306_CHARGEPUMP)
        if self._vccstate == SSD1306_EXTERNALVCC:
            self.command(0x10)
        else:
            self.command(0x14)

        self.command(SSD1306_MEMORYMODE)
        self.command(0x00)

        self.command(SSD1306_SEGREMAP | 0x1)
        self.command(SSD1306_COMSCANDEC)

        self.command(SSD1306_SETCOMPINS)
        self.command(0x12)

        self.command(SSD1306_SETCONTRAST)
        if self._vccstate == SSD1306_EXTERNALVCC:
            self.command(0x9F)
        else:
            self.command(0xCF)

        self.command(SSD1306_SETPRECHARGE)
        if self._vccstate == SSD1306_EXTERNALVCC:
            self.command(0x22)
        else:
            self.command(0xF1)

        self.command(SSD1306_SETVCOMDETECT)
        self.command(0x40)

        self.command(SSD1306_DISPLAYALLON_RESUME)
        self.command(SSD1306_NORMALDISPLAY)
        self.command(SSD1306_DISPLAYON)

    def clear(self):
        """Clear display buffer."""
        self._buffer = [0x00] * (self.width * self._pages)

    def image(self, image):
        """Copy a PIL image into the internal buffer."""
        if image.mode != "1":
            raise ValueError("Image must be in mode '1' (1-bit pixels).")
        if image.size != (self.width, self.height):
            raise ValueError(f"Image must be {self.width}x{self.height}")

        pix = image.load()
        idx = 0
        for page in range(self._pages):
            for x in range(self.width):
                bits = 0
                for bit in range(8):
                    y = page * 8 + bit
                    if pix[x, y]:
                        bits |= (1 << bit)
                self._buffer[idx] = bits
                idx += 1

    def display(self):
        """Flush the internal buffer to the OLED display."""
        self.command(SSD1306_COLUMNADDR)
        self.command(0)
        self.command(self.width - 1)

        self.command(SSD1306_PAGEADDR)
        self.command(0)
        self.command(self._pages - 1)

        self.data(self._buffer)

    def close(self):
        """Release GPIO and SPI."""
        self._spi.close()
        self._rst.close()
        self._dc.close()

disp = SSD1306(rst=3, dc=81)  
disp.begin()
button = GPIO(2, "in")
gpio = GPIO(3, "out")
button.edge = "falling"
button.read()
state = False
try:
    while True:
        if button.poll(timeout=1.0):
            button.read()
            if state == False:
                print("on")
                temp_array = digits.images[a]
                digit_img = Image.fromarray((temp_array * 8).astype(np.uint8), mode='L')
                digit_img = digit_img.resize((64, 64)).convert('1')
                img = Image.new("1", (disp.width, disp.height), "black")
                img.paste(digit_img, (32, 0))  
                disp.clear()
                disp.image(img)
                disp.display()
                a += 1
                if a >= len(digits.images):
                    a = n_samples // 2  
except KeyboardInterrupt:
    button.close()
finally:
    gpio.write(False)
    gpio.close()
    button.close()
    disp.close()
















































print("摄像头已启动，点击停止按钮中断内核来停止")
