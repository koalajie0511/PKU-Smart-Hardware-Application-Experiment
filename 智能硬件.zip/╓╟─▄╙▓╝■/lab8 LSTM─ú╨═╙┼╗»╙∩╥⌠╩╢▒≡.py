from python_speech_features import mfcc
from scipy.io import wavfile
import os
import joblib
import numpy as np
import pyaudio
import wave
import time
import warnings
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout, BatchNormalization
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau
warnings.filterwarnings("ignore")

filen = "./test.wav"

def record_audio(filename, record_second): 
    CHUNK = 512
    FORMAT = pyaudio.paInt16
    CHANNELS = 1
    RATE = 44100
    p = pyaudio.PyAudio()
    print("begin")
    stream = p.open(format=FORMAT, channels=CHANNELS, rate=RATE, input=True,
                    frames_per_buffer=CHUNK)
    wf = wave.open(filename, 'wb')
    wf.setnchannels(CHANNELS)
    wf.setsampwidth(p.get_sample_size(FORMAT))
    wf.setframerate(RATE)
    for i in range(0, int(RATE/CHUNK * record_second)):
        data = stream.read(CHUNK)
        wf.writeframes(data)
    print("done")
    stream.stop_stream()
    stream.close()
    p.terminate()
    wf.close()
def gen_wavlist(filepath):
    wavdict = {}
    labeldict = {}
    for (dirpath, dirnames, filenames) in os.walk(filepath):
        for filename in filenames:
            if filename.endswith(".wav"):
                line = os.path.join(dirpath, filename)
                fileid = filename.strip('.wav')
                label = fileid.split("_")[0]
                wavdict[fileid] = line
                labeldict[fileid] = label
    return wavdict, labeldict
def compute_mfcc(file, numcep=13, nfft=2048):
    fs, audio = wavfile.read(file)
    if len(audio.shape) > 1:
        audio = audio[:, 0]
    mfcc_feat = mfcc(audio, samplerate=fs, numcep=numcep, nfft=nfft)
    return mfcc_feat
def pad_features(features, max_length=100):
    if len(features) > max_length:
        return features[:max_length]
    else:
        padded = np.zeros((max_length, features.shape[1]))
        padded[:len(features)] = features
        return padded

class LSTMModel():
    def __init__(self, CATEGORY=None, input_shape=(100, 13), lstm_units=128, dropout_rate=0.3):
        super(LSTMModel, self).__init__()
        self.CATEGORY = CATEGORY
        self.category = len(CATEGORY)
        self.input_shape = input_shape
        self.lstm_units = lstm_units
        self.dropout_rate = dropout_rate
        self.model = None
        self.label_encoder = LabelEncoder()
        self.is_fitted = False
        if CATEGORY is not None:
            self.label_encoder.fit(CATEGORY)
            self.build_model()
    
    def build_model(self):
        self.model = Sequential([
            LSTM(self.lstm_units, return_sequences=True, input_shape=self.input_shape),
            BatchNormalization(),
            Dropout(self.dropout_rate),
            
            LSTM(self.lstm_units // 2, return_sequences=False),
            BatchNormalization(),
            Dropout(self.dropout_rate),
            
            Dense(64, activation='relu'),
            BatchNormalization(),
            Dropout(self.dropout_rate / 2),
            
            Dense(32, activation='relu'),
            Dropout(self.dropout_rate / 3),
            
            Dense(self.category, activation='softmax')
        ])
        
        self.model.compile(
            optimizer='adam',
            loss='categorical_crossentropy',
            metrics=['accuracy']
        )
        
        print("LSTM模型构建完成")
        print(self.model.summary())
    
    def prepare_training_data(self, wavdict, labeldict, max_length=100):
        print("准备训练数据...")
        X = []
        y = []
        
        for fileid, filepath in wavdict.items():
            label = labeldict[fileid]
            if label in self.CATEGORY:
                try:
                    mfcc_feat = compute_mfcc(filepath)
                    padded_feat = pad_features(mfcc_feat, max_length)
                    X.append(padded_feat)
                    y.append(label)
                except Exception as e:
                    print(f"处理文件 {filepath} 时出错: {e}")
        
        X = np.array(X)
        y_encoded = self.label_encoder.transform(y)
        y_categorical = to_categorical(y_encoded, num_classes=self.category)
        
        print(f"训练数据形状: X={X.shape}, y={y_categorical.shape}")
        return X, y_categorical
    
    def train(self, wavdict=None, labeldict=None, validation_split=0.2, epochs=100, batch_size=16):
        print("开始训练LSTM模型...")
        print(f"训练数据数量: {len(wavdict)}")
        X, y = self.prepare_training_data(wavdict, labeldict)
        if len(X) == 0:
            print("错误: 没有可用的训练数据")
            return
        callbacks = [
            EarlyStopping(monitor='val_loss', patience=15, restore_best_weights=True),
            ReduceLROnPlateau(monitor='val_loss', factor=0.5, patience=10, min_lr=1e-6)
        ]
        history = self.model.fit(
            X, y,
            batch_size=batch_size,
            epochs=epochs,
            validation_split=validation_split,
            callbacks=callbacks,
            verbose=1
        )
        
        self.is_fitted = True
        print("LSTM模型训练完成")
        return history
    def reco(self, fil):
        if not self.is_fitted:
            print("错误: 模型尚未训练")
            return None
        try:
            mfcc_feat = compute_mfcc(fil)
            padded_feat = pad_features(mfcc_feat, self.input_shape[0])
            padded_feat = np.expand_dims(padded_feat, axis=0)              
            predictions = self.model.predict(padded_feat, verbose=0)
            best_index = np.argmax(predictions[0])
            confidence = predictions[0][best_index]
            result = self.label_encoder.inverse_transform([best_index])[0]
            print(f'识别结果: {result} (置信度: {confidence:.3f})')
            if confidence < 0.5:
                print("置信度过低，可能识别错误")
                return None
            return result
        except Exception as e:
            print(f"识别过程中出错: {e}")
            return None
    def evaluate(self, test_wavdict, test_labeldict):
        if not self.is_fitted:
            print("错误: 模型尚未训练")
            return 
        print("评估模型性能...")
        X_test, y_test = self.prepare_training_data(test_wavdict, test_labeldict)
        test_loss, test_accuracy = self.model.evaluate(X_test, y_test, verbose=0)
        print(f"测试集准确率: {test_accuracy:.4f}")
        y_pred_proba = self.model.predict(X_test, verbose=0)
        y_pred = np.argmax(y_pred_proba, axis=1)
        y_true = np.argmax(y_test, axis=1)
        y_true_labels = self.label_encoder.inverse_transform(y_true)
        y_pred_labels = self.label_encoder.inverse_transform(y_pred)
        correct = 0
        total = len(y_true_labels)
        for i, (true_label, pred_label) in enumerate(zip(y_true_labels, y_pred_labels)):
            if true_label == pred_label:
                correct += 1
                print(f"✓ 正确: 预测 {pred_label}, 实际 {true_label} (置信度: {y_pred_proba[i][y_pred[i]]:.3f})")
            else:
                print(f"✗ 错误: 预测 {pred_label}, 实际 {true_label} (置信度: {y_pred_proba[i][y_pred[i]]:.3f})")
        
        accuracy = correct / total * 100
        print(f"详细准确率: {accuracy:.1f}% ({correct}/{total})")
        return test_accuracy
    def save(self, path="lstm_model.h5"):
        if self.model is not None:
            self.model.save(path)
            joblib.dump(self.label_encoder, 'label_encoder.pkl')
            print(f"模型已保存到 {path}")
        else:
            print("错误: 没有模型可保存")
    
    def load(self, path="lstm_model.h5"):
        try:
            self.model = tf.keras.models.load_model(path)
            self.label_encoder = joblib.load('label_encoder.pkl')
            self.is_fitted = True
            print(f"模型已从 {path} 加载")
        except Exception as e:
            print(f"加载模型失败: {e}")
if __name__ == '__main__':
    CATEGORY = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
    if not os.path.exists('./digits_wav'):
        print("错误: 找不到录音文件目录 './digits_wav'")
        print("请先运行录音程序生成训练数据")
        exit(1)
    wavdict, labeldict = gen_wavlist('./digits_wav')
    print(f"找到 {len(wavdict)} 个音频文件")
    if len(wavdict) == 0:
        print("错误: 没有找到任何.wav文件")
        exit(1)
    label_counts = {}
    for label in labeldict.values():
        label_counts[label] = label_counts.get(label, 0) + 1
    print("各数字训练数据数量:")
    for label in CATEGORY:
        count = label_counts.get(label, 0)
        print(f"数字 {label}: {count} 个")
    train_wavdict = {}
    train_labeldict = {}
    test_wavdict = {}
    test_labeldict = {}
    for digit in CATEGORY:
        digit_files = [k for k, v in labeldict.items() if v == digit]
        digit_files.sort() 
        if len(digit_files) >= 8:
            for fileid in digit_files[:8]:
                train_wavdict[fileid] = wavdict[fileid]
                train_labeldict[fileid] = labeldict[fileid]
            for fileid in digit_files[8:10]:
                test_wavdict[fileid] = wavdict[fileid]
                test_labeldict[fileid] = labeldict[fileid]
    print(f"训练集: {len(train_wavdict)} 个文件")
    print(f"测试集: {len(test_wavdict)} 个文件")
    print("开始训练LSTM模型...")
    lstm_model = LSTMModel(CATEGORY=CATEGORY, input_shape=(100, 13), lstm_units=128, dropout_rate=0.3)
    history = lstm_model.train(
        wavdict=train_wavdict, 
        labeldict=train_labeldict, 
        epochs=100, 
        batch_size=8
    )
    lstm_model.save()
    print("\n测试模型...")
    lstm_model.evaluate(test_wavdict, test_labeldict)
    print("\n开始实时测试...")
    print("按 Ctrl+C 停止")
    try:
        while True:
            record_audio(filen, record_second=1)
            lstm_model.reco(filen)
            time.sleep(0.5)
    except KeyboardInterrupt:
        print("\n程序结束")
