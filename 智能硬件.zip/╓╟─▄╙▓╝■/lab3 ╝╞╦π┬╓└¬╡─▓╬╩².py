import numpy as np
import cv2 as cv
im=cv.imread() #填入图片路径
cv.imshow(11,im)
cv.waitKey(0)
imgray=cv.cvtColor(im,cv.COLOR_BGR2GRAY)
ret,thresh=cv.threshold(imgray,127,255,0)
contours,hierarchy=cv.findContours(thresh,
                                   cv.RETR_TREE,cv.CHAIN_APPROX_SIMPLE)
cnt=contours[0]
M=cv.moments(cnt)
cv.drawContours(im,[cnt],0,(0,255,0),3)
cv.imshow(2,im)
cv.waitKey(0)
cx=int(M[m10]/M[m00])
cy=int(M[m01]/M[m00])
print(cx,cy)
area=cv.contourArea(cnt)
print(area)
perimeter=cv.arcLength(cnt,True)
print(perimeter)
