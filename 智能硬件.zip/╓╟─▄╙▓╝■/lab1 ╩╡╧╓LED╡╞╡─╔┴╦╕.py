from periphery import GPIO
import time
def main():
    # 初始化GPIO 3为输出模式
    gpio = GPIO(3, "out")
    print("Blinking LED on GPIO 3 (press CTRL+C to stop)...")
    try:
        while True:
            # 点亮LED
            gpio.write(True)
            time.sleep(0.2)  # 亮0.2秒
            # 熄灭LED
            gpio.write(False)
            time.sleep(0.2)  # 灭0.2秒
    except KeyboardInterrupt:
        print("\nExiting...")
    finally:
        # 确保LED关闭并释放GPIO资源
        gpio.write(False)
        gpio.close()
if __name__ == "__main__":
    main()
