from periphery import SPI,GPIO
#通过SPI总线发送三个字节数据
#spi=SPI("/dev/spidev0.0",0,1000000)
#to_send=[0x01,0x02,0x03]
#data_in=spi.transfer(to_send)
from PIL import Image,ImageDraw,ImageFont
import time
gpio_res=GPIO(128,"out")
gpio_dc=GPIO(81,"out")
spi=SPI("/dev/spidev0.0",0,1000000)
WIDTH=128
HEIGHT=64
def ssd1306_command(cmd):
    gpio_dc.write(False)
    spi.transfer([cmd])
def ssd1306_data(buf):
    gpio_dc.write(True)
    spi.transfer(list(buf))
def init_display():
    gpio_res.write(False)
    time.sleep(0.1)
    gpio_res.write(True)
    cmds = [
    0xAE, # Display off
    0xD5, 0x80, # Clock divide
    0xA8, 0x3F, # Multiplex ratio
    0xD3, 0x00, # Display offset
    0x40, # Start line at 0
    0x8D, 0x14, # Enable charge pump
    0x20, 0x00, # Memory mode horizontal
    0xA1, # Segment remap
    0xC8, # COM scan dec
    0xDA, 0x12, # COM pins config
    0x81, 0xCF, # Contrast
    0xD9, 0xF1, # Precharge
    0xDB, 0x40, # VCOM detect
    0xA4, # Resume display from RAM
    0xA6, # Normal display
    0xAF # Display ON
     ]
    for cmd in cmds:
        ssd1306_command(cmd)
def show_image(img):
    img_bw=img.convert("1").resize((WIDTH,HEIGHT))
    pixels=list(img_bw.getdata())
    buffer=[0x00]*(WIDTH*HEIGHT//8)
    for y in range(HEIGHT):
        for x in range(WIDTH):
            if pixels[x+y*WIDTH]:
                buffer[x+(y//8)*WIDTH]|=(1<<(y%8))
    ssd1306_command(0x21)
    ssd1306_command(0)
    ssd1306_command(WIDTH-1)
    ssd1306_command(0x22)
    ssd1306_command(0)
    ssd1306_command((HEIGHT//8)-1)
    ssd1306_data(buffer)
def main():
    init_display()
    img=Image.new("1",(WIDTH,HEIGHT))
    draw=ImageDraw.Draw(img)
    font=ImageFont.load_default()
    draw.text((0,0),"Hello World!",font=font,fill=255)
    show_image(img)
    print("Displayed!")
if __name=="__main__":
    try:
        main()
    finally:
        spi.close()
        gpio_res.close()
        gpio_dc.close()
