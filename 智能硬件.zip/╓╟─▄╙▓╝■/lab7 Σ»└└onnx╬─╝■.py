import onnx
import onnxruntime as ort
import numpy as np

def analyze_onnx_model(model_path):
    # 加载模型
    model = onnx.load(model_path)
    
    print("=" * 50)
    print("模型基本信息")
    print("=" * 50)
    print(f"模型名称: {model.graph.name}")
    print(f"IR 版本: {model.ir_version}")
    print(f"生产者: {model.producer_name}")
    print(f"生产者版本: {model.producer_version}")
    print(f"域: {model.domain}")
    print(f"模型版本: {model.model_version}")
    
    # Opset 信息
    for opset in model.opset_import:
        print(f"Opset - 域: {opset.domain}, 版本: {opset.version}")
    
    print("\n" + "=" * 50)
    print("输入信息")
    print("=" * 50)
    for input in model.graph.input:
        print(f"输入名称: {input.name}")
        tensor_type = input.type.tensor_type
        print(f"  数据类型: {tensor_type.elem_type}")
        if tensor_type.shape.dim:
            shape = []
            for dim in tensor_type.shape.dim:
                if dim.dim_value > 0:
                    shape.append(dim.dim_value)
                else:
                    shape.append(dim.dim_param if dim.dim_param else '?')
            print(f"  形状: {shape}")
        else:
            print(f"  形状: 未指定")
    
    print("\n" + "=" * 50)
    print("输出信息")
    print("=" * 50)
    for output in model.graph.output:
        print(f"输出名称: {output.name}")
        tensor_type = output.type.tensor_type
        print(f"  数据类型: {tensor_type.elem_type}")
        if tensor_type.shape.dim:
            shape = []
            for dim in tensor_type.shape.dim:
                if dim.dim_value > 0:
                    shape.append(dim.dim_value)
                else:
                    shape.append(dim.dim_param if dim.dim_param else '?')
            print(f"  形状: {shape}")
        else:
            print(f"  形状: 未指定")
    
    print("\n" + "=" * 50)
    print("模型结构统计")
    print("=" * 50)
    print(f"节点总数: {len(model.graph.node)}")
    print(f"初始值数量 (权重/偏置): {len(model.graph.initializer)}")
    print(f"中间值数量: {len(model.graph.value_info)}")
    
    # 统计操作类型
    op_count = {}
    for node in model.graph.node:
        op_type = node.op_type
        op_count[op_type] = op_count.get(op_type, 0) + 1
    
    print("\n操作类型统计:")
    for op_type, count in sorted(op_count.items()):
        print(f"  {op_type}: {count}")
    
    # 显示前几个节点的详细信息
    print("\n" + "=" * 50)
    print("前10个节点详情")
    print("=" * 50)
    for i, node in enumerate(model.graph.node[:10]):
        print(f"节点 {i}: {node.op_type}")
        print(f"  输入: {node.input}")
        print(f"  输出: {node.output}")
        if node.attribute:
            print(f"  属性: {[attr.name for attr in node.attribute]}")
        print()

# 运行分析
analyze_onnx_model('model.onnx')
