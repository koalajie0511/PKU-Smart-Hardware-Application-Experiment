from periphery import GPIO
import random
import time
buttons={GPIO(82,"in"),GPIO(38,"in"),GPIO(79,"in")}
buttons[0].edge="falling"
buttons[1].edge="falling"
buttons[2].edge="falling"
gpio=GPIO(3,"out") #用于显示成功输入手势
pinnum=[1,1,1]
A=[[0.25,0.25],[0.25,0.25]]
scores={"player":0,"computer":0,"tie":0}
win={82:79,38:82,79:38}
tot=3
learning_prob=0.1
decay_prob=0.99
pin_to_index={82:0,38:1,79:2}
index_to_pin={0:82,1:38,2:79}
probability=[1/3,1/3,1/3]
last=None #上一轮使用的策略
last_index=None #上一轮策略编号
def judgewin(pin,machine):
    if pin==machine:
        scores["tie"]+=1
        return 0
    elif machine==win[pin]:
        scores["player"]+=1
        return 1
    else:
        scores["computer"]+=1
        return 2
def prob():
    probability[0]=pinnum[0]/tot
    probability[1]=pinnum[1]/tot
    probability[2]=pinnum[2]/tot
def A_update(result,last_index): #根据结果和策略，调整概率矩阵A
    global A
    if index==0:
        i=0
        j=0
    elif index==1:
        i=0
        j=1
    elif index==2:
        i=1
        j=0
    else:
        i=1
        j=1
    if result==2: #电脑获胜，对应的策略的信赖值加大
        reward=learning_prob #奖励大小为learning_prob的概率
    elif result==1: #玩家获胜，对相应的策略进行概率惩罚
        reward=-learning_prob()
    else:
        reward=0 #如果平局，不奖励也不惩罚
    A[i][j]=max(0.1,min(0.9,A[i][j]+reward)) #保证各个策略的概率在[0.1,0.9]防止越界
    normal() #对矩阵进行归一化
def normal():
    sum_A=A[0][0]+A[0][1]+A[1][0]+A[1][1]
    for i in range(2):
        for j in range(2):
            A[i][j]/=sum_A
def blink(): #按键输入成功，灯光闪烁三次
    speed=0.2
    for i in range(3):
        gpio.write(True)
        time.sleep(speed)
        gpio.write(False)
        time.sleep(speed)
def generate_machine():
    prob()
    max_prob=max(probability)
    min_prob=min(probability)
    max_index=probability.index(max_prob)
    min_index=probability.index(min_prob)
    beat_high=win[index_to_pin[max_index]]
    beat_beat_high=win[beat_high] #分别给出"反制"和"反制的反制"对应的手势
    beat_low=win[index_to_pin[min_index]]
    beat_beat_low=win[beat_low]
    temp=random.random()
    if temp<A[0][0]:
        #采用对高概率手势进行反制的策略
        choice=beat_high
        last_index=0
    elif temp<A[0][0]+A[0][1]:
        #采用对高概率手势进行反制的反制
        choice=beat_beat_high
        last_index=1
    elif temp<A[0][0]+A[0][1]+A[1][0]:
        choice=beat_low
        last_index=2
    else:
        choice=beat_beat_low
        last_index=3
    return choice
try:
    for button in buttons:
        button.read()
    while True:
        for button in buttons:
            button.read()
        machine=generate_machine()
        events=GPIO.poll_multiple(buttons,timeout=1.0)
        if not events:
            continue
        for button in events:
            pin=button.line
        blink()
        if pin==82:
            pinnum[0]+=1
            print("82")
        elif pin==38:
            pinnum[1]+=1
            print("38")
        else:
            pinnum[2]+=1
            print("79")
        tot+=1
        state=judgewin(pin,machine)
        if last_index is not None:
            A_update()
        if state==0:
            print("Tie!")
        elif state==1:
            print("Player Wins!")
        else:
            print("Computer Wins!")
        gpio.write(False)
        time.sleep(0.5)
except KeyboardInterrupt:
    print("\nProgram stopped by user!")
finally:
    gpio.write(False)
    gpio.close()
    for button in buttons:
        button.close()
