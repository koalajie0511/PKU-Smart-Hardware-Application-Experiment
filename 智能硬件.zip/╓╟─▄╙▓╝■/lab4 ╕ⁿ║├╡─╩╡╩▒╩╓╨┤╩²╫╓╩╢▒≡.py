import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import cv2
from torch.utils.data import DataLoader
from torchvision import transforms, datasets
import matplotlib.pyplot as plt
import time
from sklearn.metrics import accuracy_score

class EnhancedNet(nn.Module):
    """增强的卷积神经网络模型"""
    def __init__(self):
        super(EnhancedNet, self).__init__()
        self.conv_layers = nn.Sequential(
            # 第一卷积块
            nn.Conv2d(1, 32, kernel_size=3, padding=1),
            nn.BatchNorm2d(32),
            nn.ReLU(),
            nn.Conv2d(32, 32, kernel_size=3, padding=1),
            nn.BatchNorm2d(32),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2),
            nn.Dropout(0.25),
            
            # 第二卷积块
            nn.Conv2d(32, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(),
            nn.Conv2d(64, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2),
            nn.Dropout(0.25),
            
            # 第三卷积块
            nn.Conv2d(64, 128, kernel_size=3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2),
            nn.Dropout(0.25)
        )
        
        self.classifier = nn.Sequential(
            nn.Linear(128 * 3 * 3, 256),
            nn.ReLU(),
            nn.BatchNorm1d(256),
            nn.Dropout(0.5),
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.BatchNorm1d(128),
            nn.Dropout(0.5),
            nn.Linear(128, 10)
        )
    
    def forward(self, x):
        x = self.conv_layers(x)
        x = x.view(x.size(0), -1)
        x = self.classifier(x)
        return x

class AdvancedDigitPredictor:
    """高级数字预测器，结合深度学习和传统方法"""
    def __init__(self, model_path=None):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"使用设备: {self.device}")
        
        # 加载PyTorch模型
        self.model = EnhancedNet().to(self.device)
        if model_path:
            self.model.load_state_dict(torch.load(model_path, map_location=self.device))
        self.model.eval()
        
        # 图像预处理
        self.transform = transforms.Compose([
            transforms.ToPILImage(),
            transforms.Resize((28, 28)),
            transforms.ToTensor(),
            transforms.Normalize((0.1307,), (0.3081,))
        ])
        
        # 预测稳定性控制
        self.predictions_history = []
        self.last_stable_prediction = None
        self.last_prediction_time = 0
        self.stability_threshold = 0.6
        self.time_interval = 1.0
        
    def preprocess_camera_image(self, image):
        """预处理摄像头图像"""
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image
        
        # 高斯模糊
        blurred = cv2.GaussianBlur(gray, (5, 5), 0)
        
        # 自适应阈值
        binary = cv2.adaptiveThreshold(blurred, 255, 
                                      cv2.ADAPTIVE_THRESH_GAUSSIAN_C, 
                                      cv2.THRESH_BINARY_INV, 11, 2)
        
        return binary
    
    def extract_digit_roi(self, binary_image, min_area=500, max_area=10000):
        """提取数字区域"""
        contours, _ = cv2.findContours(binary_image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        if not contours:
            return None, None
        
        # 按面积排序
        contours = sorted(contours, key=cv2.contourArea, reverse=True)
        
        for contour in contours:
            area = cv2.contourArea(contour)
            if min_area < area < max_area:
                x, y, w, h = cv2.boundingRect(contour)
                
                # 宽高比过滤
                aspect_ratio = w / h
                if 0.3 < aspect_ratio < 3.0:
                    # 添加边界
                    border = 10
                    x = max(0, x - border)
                    y = max(0, y - border)
                    w = min(binary_image.shape[1] - x, w + 2 * border)
                    h = min(binary_image.shape[0] - y, h + 2 * border)
                    
                    roi = binary_image[y:y+h, x:x+w]
                    return roi, (x, y, w, h)
        
        return None, None
    
    def prepare_for_model(self, roi):
        """准备模型输入"""
        # 调整大小并添加边界到28x28
        h, w = roi.shape
        size = max(h, w)
        
        # 创建正方形图像
        square = np.zeros((size, size), dtype=np.uint8)
        y_start = (size - h) // 2
        x_start = (size - w) // 2
        square[y_start:y_start+h, x_start:x_start+w] = roi
        
        # 调整到28x28
        resized = cv2.resize(square, (28, 28), interpolation=cv2.INTER_AREA)
        
        # 转换为模型输入格式
        tensor = self.transform(resized).unsqueeze(0).to(self.device)
        return tensor, resized
    
    def predict_digit(self, image_tensor):
        """预测数字"""
        with torch.no_grad():
            outputs = self.model(image_tensor)
            probabilities = F.softmax(outputs, dim=1)
            confidence, predicted = torch.max(probabilities, 1)
            
            return predicted.item(), confidence.item(), probabilities.cpu().numpy()[0]
    
    def get_stable_prediction(self, digit, confidence, timestamp):
        """获取稳定的预测结果"""
        # 添加当前预测到历史
        if confidence > 0.3:  # 最小置信度阈值
            self.predictions_history.append((digit, confidence, timestamp))
        
        # 清理旧数据（保留最近3秒）
        self.predictions_history = [
            (d, c, t) for d, c, t in self.predictions_history 
            if timestamp - t < 3.0
        ]
        
        # 检查时间间隔
        if timestamp - self.last_prediction_time < self.time_interval:
            return self.last_stable_prediction
        
        if len(self.predictions_history) < 5:
            return None
        
        # 分析历史预测
        digit_counts = {}
        digit_confidences = {}
        
        for d, c, _ in self.predictions_history:
            digit_counts[d] = digit_counts.get(d, 0) + 1
            if d not in digit_confidences:
                digit_confidences[d] = []
            digit_confidences[d].append(c)
        
        # 找到最频繁的数字
        if digit_counts:
            max_count = max(digit_counts.values())
            most_common_digits = [d for d, count in digit_counts.items() if count == max_count]
            
            if len(most_common_digits) == 1:
                stable_digit = most_common_digits[0]
                frequency = max_count / len(self.predictions_history)
                
                if frequency >= self.stability_threshold:
                    avg_confidence = np.mean(digit_confidences[stable_digit])
                    
                    # 更新稳定预测
                    self.last_stable_prediction = (stable_digit, avg_confidence)
                    self.last_prediction_time = timestamp
                    
                    # 清空历史，开始新的统计
                    self.predictions_history = []
                    
                    return stable_digit, avg_confidence
        
        return None

def train_enhanced_model():
    """训练增强模型"""
    # 超参数
    batch_size = 128
    learning_rate = 0.001
    epochs = 15
    
    # 数据预处理
    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.1307,), (0.3081,)),
        transforms.RandomAffine(degrees=10, translate=(0.1, 0.1), scale=(0.9, 1.1))
    ])
    
    # 加载数据
    train_dataset = datasets.MNIST(root='./data/mnist', train=True, download=True, transform=transform)
    test_dataset = datasets.MNIST(root='./data/mnist', train=False,download=True,transform=transform)
    
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)
    
    # 模型和优化器
    model = EnhancedNet()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)
    
    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate, weight_decay=1e-4)
    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=5, gamma=0.5)
    
    # 训练循环
    train_losses = []
    test_accuracies = []
    
    print("开始训练增强模型...")
    for epoch in range(epochs):
        model.train()
        running_loss = 0.0
        
        for batch_idx, (data, target) in enumerate(train_loader):
            data, target = data.to(device), target.to(device)
            
            optimizer.zero_grad()
            output = model(data)
            loss = criterion(output, target)
            loss.backward()
            optimizer.step()
            
            running_loss += loss.item()
            
            if batch_idx % 100 == 0:
                print(f'Epoch: {epoch+1} [{batch_idx * len(data)}/{len(train_loader.dataset)}] '
                      f'Loss: {loss.item():.6f}')
        
        scheduler.step()
        
        # 测试
        model.eval()
        correct = 0
        total = 0
        
        with torch.no_grad():
            for data, target in test_loader:
                data, target = data.to(device), target.to(device)
                outputs = model(data)
                _, predicted = torch.max(outputs.data, 1)
                total += target.size(0)
                correct += (predicted == target).sum().item()
        
        accuracy = 100 * correct / total
        test_accuracies.append(accuracy)
        train_losses.append(running_loss / len(train_loader))
        
        print(f'Epoch {epoch+1}: 测试准确率: {accuracy:.2f}%')
    
    # 保存模型
    torch.save(model.state_dict(), 'enhanced_mnist_model.pth')
    print("模型已保存为 'enhanced_mnist_model.pth'")
    
    # 绘制训练曲线
    plt.figure(figsize=(12, 4))
    plt.subplot(1, 2, 1)
    plt.plot(train_losses)
    plt.title('训练损失')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    
    plt.subplot(1, 2, 2)
    plt.plot(test_accuracies)
    plt.title('测试准确率')
    plt.xlabel('Epoch')
    plt.ylabel('Accuracy (%)')
    
    plt.tight_layout()
    plt.show()
    
    return model

def main():
    """主函数 - 实时摄像头识别"""
    print("手写数字识别系统启动中...")
    
    # 检查是否有训练好的模型
    try:
        predictor = AdvancedDigitPredictor('enhanced_mnist_model.pth')
        print("已加载预训练模型")
    except:
        print("未找到预训练模型，请先训练模型")
        response = input("是否现在训练模型？(y/n): ")
        if response.lower() == 'y':
            train_enhanced_model()
            predictor = AdvancedDigitPredictor('enhanced_mnist_model.pth')
        else:
            print("使用基础模型（准确率可能较低）")
            predictor = AdvancedDigitPredictor()
    
    # 启动摄像头
    cap = cv2.VideoCapture(0)
    
    if not cap.isOpened():
        print("无法打开摄像头")
        return
    
    print("\n使用说明:")
    print("- 在摄像头前展示手写数字")
    print("- 系统会自动检测并识别数字")
    print("- 按 'q' 退出程序")
    print("- 按 'r' 重置稳定预测器")
    print("- 按 's' 保存当前帧")
    
    frame_count = 0
    last_stable_text = "等待识别..."
    last_stable_color = (255, 255, 255)
    
    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                break
                
            display_frame = frame.copy()
            current_time = time.time()
            frame_count += 1
            
            # 预处理图像
            processed = predictor.preprocess_camera_image(frame)
            
            # 提取数字区域
            digit_roi, bbox = predictor.extract_digit_roi(processed)
            
            current_prediction = None
            current_confidence = 0.0
            
            if digit_roi is not None and bbox is not None:
                x, y, w, h = bbox
                
                # 绘制边界框
                cv2.rectangle(display_frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
                
                # 准备并预测
                image_tensor, processed_roi = predictor.prepare_for_model(digit_roi)
                digit, confidence, all_probs = predictor.predict_digit(image_tensor)
                
                current_prediction = digit
                current_confidence = confidence
                
                # 获取稳定预测
                stable_result = predictor.get_stable_prediction(digit, confidence, current_time)
                
                if stable_result:
                    stable_digit, stable_conf = stable_result
                    last_stable_text = f"识别结果: {stable_digit} (置信度: {stable_conf:.3f})"
                    last_stable_color = (0, 255, 0) if stable_conf > 0.8 else (0, 255, 255)
                    
                    # 控制台输出
                    if frame_count % 30 == 0:
                        print(f"稳定预测: {stable_digit}, 置信度: {stable_conf:.3f}")
                else:
                    last_stable_text = "识别中..."
                    last_stable_color = (255, 255, 0)
                
                # 显示当前预测
                current_text = f"当前: {digit}({confidence:.3f})"
                cv2.putText(display_frame, current_text, (20, 120), 
                          cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 0), 2)
                
                # 显示概率分布
                prob_text = "概率: " + " ".join([f"{i}:{p:.2f}" for i, p in enumerate(all_probs) if p > 0.1])
                cv2.putText(display_frame, prob_text, (20, 150), 
                          cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
            
            else:
                last_stable_text = "未检测到数字"
                last_stable_color = (255, 255, 255)
            
            # 显示稳定结果
            cv2.putText(display_frame, last_stable_text, (20, 40), 
                      cv2.FONT_HERSHEY_SIMPLEX, 0.8, last_stable_color, 2)
            
            # 显示处理后的图像
            if digit_roi is not None:
                # 显示检测区域
                roi_display = cv2.resize(digit_roi, (100, 100))
                roi_display = cv2.cvtColor(roi_display, cv2.COLOR_GRAY2BGR)
                display_frame[10:110, display_frame.shape[1]-110:display_frame.shape[1]-10] = roi_display
                
                # 显示模型输入
                if 'processed_roi' in locals():
                    model_input_display = cv2.resize(processed_roi, (100, 100))
                    model_input_display = cv2.cvtColor(model_input_display, cv2.COLOR_GRAY2BGR)
                    display_frame[120:220, display_frame.shape[1]-110:display_frame.shape[1]-10] = model_input_display
            
            # 显示状态信息
            cv2.putText(display_frame, "按 'q' 退出, 'r' 重置, 's' 保存", 
                      (20, display_frame.shape[0] - 20), 
                      cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
            
            cv2.imshow('增强手写数字识别系统', display_frame)
            
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break
            elif key == ord('r'):
                predictor.predictions_history = []
                predictor.last_stable_prediction = None
                print("预测器已重置")
            elif key == ord('s'):
                cv2.imwrite(f'capture_{int(time.time())}.jpg', frame)
                print("当前帧已保存")
                
    except KeyboardInterrupt:
        print("用户中断程序")
    finally:
        cap.release()
        cv2.destroyAllWindows()
        print("程序已退出")

if __name__ == "__main__":
    # 可以选择直接运行实时识别，或者先训练模型
    print("选择模式:")
    print("1. 训练新模型")
    print("2. 实时识别（需要已有模型）")
    
    choice = input("请输入选择 (1/2, 默认2): ").strip()
    
    if choice == "1":
        train_enhanced_model()
    else:
        main()
