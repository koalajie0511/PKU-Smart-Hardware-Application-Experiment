'''import cv2
import numpy as np

# 创建背景减除器
bs = cv2.createBackgroundSubtractorKNN(detectShadows=True)

# 打开摄像头
cap = cv2.VideoCapture(0)

if not cap.isOpened():
    print("无法打开摄像头")
    exit()

print("按q键退出程序")

while True:
    # 读取视频帧
    ret, frame = cap.read()
    if not ret:
        print("无法接收帧（可能是流结束或摄像头连接丢失）")
        break
    
    # 应用背景减除
    fgmask = bs.apply(frame)
    
    # 二值化处理
    th = cv2.threshold(fgmask.copy(), 244, 255, cv2.THRESH_BINARY)[1]
    
    # 形态学操作（膨胀）以连接断开的区域
    dilated = cv2.dilate(th, 
                         cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3)), 
                         iterations=2)
    
    # 查找轮廓
    contours, hier = cv2.findContours(dilated, 
                                     cv2.RETR_EXTERNAL, 
                                     cv2.CHAIN_APPROX_SIMPLE)
    
    # 在原始帧上绘制检测到的移动物体
    frame_with_boxes = frame.copy()
    
    for contour in contours:
        # 计算轮廓面积，过滤掉太小的轮廓
        if cv2.contourArea(contour) < 500:  # 可根据实际情况调整阈值
            continue
        
        # 获取边界框
        x, y, w, h = cv2.boundingRect(contour)
        
        # 在帧上绘制矩形框
        cv2.rectangle(frame_with_boxes, (x, y), (x+w, y+h), (0, 255, 0), 2)
        cv2.putText(frame_with_boxes, 'Moving Object', (x, y-10), 
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
    
    # 显示结果
    cv2.imshow('Original', frame)
    cv2.imshow('Foreground Mask', fgmask)
    cv2.imshow('Threshold', th)
    cv2.imshow('Dilated', dilated)
    cv2.imshow('Detection Result', frame_with_boxes)
    
    # 按q键退出
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# 释放资源
cap.release()
cv2.destroyAllWindows()'''
import cv2
import numpy as np
bs=cv2.createBackgroundSubtractorKNN(detectShadows=True)
cap=cv2.VideoCapture("") #视频地址
a,b,c,d=50,200,180,180
track_window=(a,b,c,d)
try:
    while True:
        ret,frame=cap.read()
        if not ret:
            break
        roi_frame=frame[b:b+d,a:a+c]
        fgmask=bs.apply(frame)
        fgmask=cv2.morphologyEx(fgmask,cv2.MORPH_OPEN,np.ones((5,5),np.uint8))
        th=cv2.threshold(fgmask.copy(),244,255,cv2.THRESH_BINARY)[1]
        kernel=cv2.getStructingElement(cv2.MORPH_ELLIPSE,(3,3))
        dilated=cv2.dilate(th,kernel,iterations=2)
        contours,hier=cv2.findContours(dilated,cv2.RETR_EXTERNAL,
                                       cv2.CHAIN_APPROX_SIMPLE)
        for contour in contours:
            area=cv2.contourArea(contour)
            if area>10000:
                x,y,w,h=cv2.boundingRect(contour)
                if abs(w-h)<100:
                    cv2.rectangle(frame,(x,y),(x+w,y+h),(0,255,0),2)
        cv2.imshow(Frame,frame)
except KeyboardInterrupt:
    cap.release()
    cv2.destroyAllWindows()
