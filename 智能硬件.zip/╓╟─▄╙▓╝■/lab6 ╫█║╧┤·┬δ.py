import cv2
import numpy as np
import time
import matplotlib.pyplot as plt
from IPython.display import display, clear_output
import os

def record_video(duration=20, filename='recorded_video.avi'):
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("无法打开摄像头")
        return False
    
    frame_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    frame_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = 30.0
    fourcc = cv2.VideoWriter_fourcc(*'XVID')
    out = cv2.VideoWriter(filename, fourcc, fps, (frame_width, frame_height))
    
    print(f"开始录制 {duration} 秒视频...")
    start_time = time.time()
    fig, ax = plt.subplots(figsize=(10, 8))
    plt.ion()
    
    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                print("无法读取摄像头画面")
                break
            
            out.write(frame)
            frame_display = frame.copy()
            cv2.putText(frame_display, f"Recording... {duration - int(time.time() - start_time)}s", 
                       (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
            
            frame_rgb = cv2.cvtColor(frame_display, cv2.COLOR_BGR2RGB)
            ax.clear()
            ax.imshow(frame_rgb)
            ax.set_title(f"Recording... {duration - int(time.time() - start_time)}s remaining")
            ax.axis('off')
            clear_output(wait=True)
            display(fig)
            
            if time.time() - start_time > duration:
                break
            plt.pause(0.01)
    except KeyboardInterrupt:
        print("录制被用户中断")
    finally:
        print("录制完成!")
        cap.release()
        out.release()
        plt.close(fig)
        plt.ioff() 
    return True

def track_face(video_path, output_path='tracked_video.avi'):
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        print("无法打开视频文件")
        return
    frame_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    frame_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    original_fps = cap.get(cv2.CAP_PROP_FPS)
    output_fps = 5.0 
    fourcc = cv2.VideoWriter_fourcc(*'XVID')
    out = cv2.VideoWriter(output_path, fourcc, output_fps, (frame_width, frame_height))
    ret, frame = cap.read()
    if not ret:
        print("无法读取视频帧")
        return
    
    height, width = frame.shape[:2]
    center_x, center_y = width // 2, height // 2
    track_width, track_height = 120, 160
    x = max(0, center_x - track_width // 2)
    y = max(0, center_y - track_height // 2)
    w = min(track_width, width - x)
    h = min(track_height, height - y)
    track_window = (x, y, w, h)
    
    print(f"使用初始跟踪窗口: {track_window}")
    print(f"原始视频帧率: {original_fps:.2f}")
    print(f"输出视频帧率: {output_fps:.2f}")
    print(f"输出视频将保存为: {output_path}")
    
    roi = frame[y:y+h, x:x+w]
    if roi.size == 0:
        print("初始ROI区域无效")
        return
    
    hsv_roi = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
    mask = cv2.inRange(hsv_roi, np.array((0., 60., 32.)), np.array((180., 255., 255.)))
    roi_hist = cv2.calcHist([hsv_roi], [0], mask, [180], [0, 180])
    cv2.normalize(roi_hist, roi_hist, 0, 255, cv2.NORM_MINMAX)
    
    term_crit = (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 10, 1)
    print("开始CamShift人脸跟踪...")
    
    fig, ax = plt.subplots(figsize=(12, 8))
    frame_count = 0
    start_time = time.time()
    
    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                print("视频播放完毕")
                break
            
            frame_count += 1
            hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
            dst = cv2.calcBackProject([hsv], [0], roi_hist, [0, 180], 1)
            
            ret, track_window = cv2.CamShift(dst, track_window, term_crit)
            pts = cv2.boxPoints(ret)
            pts = np.int32(pts)
            img2 = cv2.polylines(frame, [pts], True, (0, 255, 0), 2)
            center = tuple(np.mean(pts, axis=0).astype(int))
            cv2.circle(img2, center, 5, (255, 0, 0), -1)
            cv2.putText(img2, f"Frame: {frame_count}", (10, 30), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
            cv2.putText(img2, "DETECTED", (10, 60), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
            out.write(img2)
            img_rgb = cv2.cvtColor(img2, cv2.COLOR_BGR2RGB)
            ax.clear()
            ax.imshow(img_rgb)
            ax.set_title(f" Face Tracking - Frame {frame_count}")
            ax.axis('off')
            if frame_count % 2 == 0: 
                clear_output(wait=True)
                display(fig)
            plt.pause(0.001) 
    except KeyboardInterrupt:
        print("跟踪被用户中断")
    except Exception as e:
        print(f"跟踪过程中出现错误: {e}")
    finally:
        end_time = time.time()
        processing_time = end_time - start_time
        cap.release()
        out.release()
        plt.close(fig)
        
        print(f"处理了 {frame_count} 帧")
        print(f"处理时间: {processing_time:.2f} 秒")
        print(f"输出视频已保存为: {output_path}")
        if os.path.exists(output_path):
            output_cap = cv2.VideoCapture(output_path)
            output_frame_count = int(output_cap.get(cv2.CAP_PROP_FRAME_COUNT))
            output_fps_actual = output_cap.get(cv2.CAP_PROP_FPS)
            output_duration = output_frame_count / output_fps_actual if output_fps_actual > 0 else 0
            output_cap.release()
            
            print(f"输出视频信息:")
            print(f"  - 帧数: {output_frame_count}")
            print(f"  - 帧率: {output_fps_actual:.2f}")
            print(f"  - 时长: {output_duration:.2f} 秒")

def main():
    video_filename = "face_video.avi"
    tracked_filename = "face_tracked.avi"
    
    print("=== 视频录制阶段 ===")
    success = record_video(20, video_filename)
    if not success:
        print("视频录制失败，程序退出")
        return
    
    print("\n=== CamShift人脸跟踪阶段 ===")
    track_face(video_filename, tracked_filename)
    
    print("程序结束")

if __name__ == "__main__":
    main()





















import cv2 
import time
import numpy as np
import matplotlib.pyplot as plt
from IPython.display import display, clear_output
face_cascade = cv2.CascadeClassifier(
    cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
eye_cascade = cv2.CascadeClassifier(
    cv2.data.haarcascades + 'haarcascade_eye.xml')
cap = cv2.VideoCapture(0)
time.sleep(1)
try:
    frame_count = 0
    max_frames = 1000  
    while frame_count < max_frames:
        ret, frame = cap.read()
        if not ret:
            print("无法读取摄像头帧")
            break
        height, width = frame.shape[:2]
        mask_x_begin = width // 4
        mask_x_end = 3 * width // 4
        mask_y_begin = height // 4
        mask_y_end = 3 * height // 4
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = face_cascade.detectMultiScale(gray, 1.3, 5)
        eyes = eye_cascade.detectMultiScale(gray, 1.3, 5)
        for (x, y, w, h) in eyes:
            frame = cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 0), 2)
            mask_x_begin = max(0, x - 50)
            mask_x_end = min(width, x + w + 50)
            mask_y_begin = max(0, y + h + 20) 
            mask_y_end = min(height, y + h + 150)  
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        skin = cv2.inRange(hsv, np.array([0, 25, 0]), np.array([50, 255, 255]))
        skin_mask = np.zeros((frame.shape[0], frame.shape[1]), dtype=np.uint8)
        skin_mask[mask_y_begin:mask_y_end, mask_x_begin:mask_x_end] = skin[
            mask_y_begin:mask_y_end, mask_x_begin:mask_x_end]
        out = cv2.bitwise_and(frame, frame, mask=skin_mask)
        mask_area = skin_mask[mask_y_begin:mask_y_end, mask_x_begin:mask_x_end].sum() // 255
        mask_region_area = (mask_x_end - mask_x_begin) * (mask_y_end - mask_y_begin)
        if mask_region_area > 0:
            mask_ratio = mask_area / mask_region_area
        else:
            mask_ratio = 0
        cv2.rectangle(frame, (mask_x_begin, mask_y_begin), 
                     (mask_x_end, mask_y_end), (0, 255, 255), 2)
        if mask_ratio <0.25:  
            cv2.putText(frame, "Mask Detected", (50, 50),
                        cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
        else:
            cv2.putText(frame, "No Mask Detected", (50, 50),
                        cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
        cv2.putText(frame, f"Ratio: {mask_ratio:.2f}", (50, 100),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        clear_output(wait=True)
        plt.figure(figsize=(12, 8))
        plt.imshow(frame_rgb)
        status = "Mask Detected" if mask_ratio > 0.8 else "No Mask Detected"
        plt.title(f'Mask Detection - {status} (Ratio: {mask_ratio:.2f}) - Frame: {frame_count}/{max_frames}')
        plt.axis('off')
        plt.show()
        frame_count += 1
        time.sleep(0.03) 
except KeyboardInterrupt:
    print("程序被用户中断")
except Exception as e:
    print(f"发生错误: {e}")
finally:
    cap.release()
    print(f"检测完成，共处理 {frame_count} 帧")























import cv2
import numpy as np
import matplotlib.pyplot as plt
from IPython.display import display, clear_output
cap = cv2.VideoCapture('./pingpong.mp4') 
ret, frame = cap.read()
r, h, c, w = 280, 140, 102, 140
track_window = (c, r, w, h)
roi = frame[r:r+h, c:c+w]
hsv_roi = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
roi_hist = cv2.calcHist([hsv_roi], [0], None, [180], [0,180])
cv2.normalize(roi_hist, roi_hist, 0, 255, cv2.NORM_MINMAX)
term_crit = (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 10, 1)
try:
    frame_count = 0
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        dst = cv2.calcBackProject([hsv], [0], roi_hist, [0,180], 1)
        ret, track_window = cv2.CamShift(dst, track_window, term_crit)
        pts = cv2.boxPoints(ret)
        pts = np.int32(pts)
        img2 = cv2.polylines(frame, [pts], True, (0, 255, 0), 2)
        img2_rgb = cv2.cvtColor(img2, cv2.COLOR_BGR2RGB)
        clear_output(wait=True)
        plt.figure(figsize=(12, 8))
        plt.imshow(img2_rgb)
        plt.title(f'CamShift Object Tracking - Frame: {frame_count} (Press Ctrl+C to stop)')
        plt.axis('off')
        plt.show()
        frame_count += 1
except KeyboardInterrupt:
    print("程序被用户中断")
except Exception as e:
    print(f"发生错误: {e}")
finally:
    cap.release()
    print(f"跟踪完成，共处理 {frame_count} 帧")
























import cv2 as cv
import matplotlib.pyplot as plt
from IPython.display import display, clear_output
import time
def calculate_overlap(rect1, rect2):
    x1, y1, w1, h1 = rect1
    x2, y2, w2, eh2 = rect2
    x_left = max(x1, x2)
    y_top = max(y1, y2)
    x_right = min(x1 + w1, x2 + w2)
    y_bottom = min(y1 + h1, y2 + eh2)
    if x_right < x_left or y_bottom < y_top:
        return 0.0
    intersection_area = (x_right - x_left) * (y_bottom - y_top)
    area1 = w1 * h1
    area2 = w2 * eh2
    return intersection_area / min(area1, area2)
def detect_face_eyes():
    face_cascade = cv.CascadeClassifier(cv.data.haarcascades + 'haarcascade_frontalface_default.xml')
    eye_cascade1 = cv.CascadeClassifier(cv.data.haarcascades + 'haarcascade_eye.xml')
    eye_cascade2 = cv.CascadeClassifier(cv.data.haarcascades + 'haarcascade_eye_tree_eyeglasses.xml')
    cap = cv.VideoCapture(0)
    if not cap.isOpened():
        print("无法打开摄像头")
        return
    try:
        frame_count = 0
        max_frames = 200 
        while frame_count < max_frames:
            ret, img = cap.read()
            if not ret:
                print("无法读取帧")
                break
            gray = cv.cvtColor(img, cv.COLOR_BGR2GRAY)
            faces = face_cascade.detectMultiScale(gray, 1.3, 5)
            face_count = 0
            total_eye_count = 0
            for (x, y, w, h) in faces:
                face_count += 1
                cv.rectangle(img, (x, y), (x + w, y + h), (255, 0, 0), 2)
                cv.putText(img, f'Face {face_count}', (x, y-10), 
                          cv.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 0), 2)
                upper_face_height = int(h * 0.6)
                roi_gray = gray[y:y + upper_face_height, x:x + w]
                roi_color = img[y:y + upper_face_height, x:x + w]
                eyes1 = eye_cascade1.detectMultiScale(roi_gray, 1.1, 8, 
                                                     minSize=(20, 20), maxSize=(60, 60))
                eyes2 = eye_cascade2.detectMultiScale(roi_gray, 1.1, 10, 
                                                     minSize=(20, 20), maxSize=(60, 60))
                all_eyes = list(eyes1) + list(eyes2)
                final_eyes = []
                for i, eye1 in enumerate(all_eyes):
                    ex1, ey1, ew1, eh1 = eye1
                    keep = True
                    for j, eye2 in enumerate(all_eyes):
                        if i != j:
                            ex2, ey2, ew2, eh2 = eye2
                            overlap = calculate_overlap((ex1, ey1, ew1, eh1), 
                                                      (ex2, ey2, ew2, eh2))
                            if overlap > 0.5: 
                                if ew1 * eh1 < ew2 * eh2:  
                                    keep = False
                                    break
                    if keep:
                        final_eyes.append(eye1)
                eye_count = 0
                for (ex, ey, ew, eh) in final_eyes:
                    eye_count += 1
                    total_eye_count += 1
                    cv.rectangle(roi_color, (ex, ey), (ex + ew, ey + eh), (0, 255, 0), 2)
                    cv.putText(roi_color, f'Eye {eye_count}', (ex, ey-5), 
                              cv.FONT_HERSHEY_SIMPLEX, 0.4, (0, 255, 0), 1)
            cv.putText(img, f'Faces: {face_count}, Eyes: {total_eye_count}', 
                      (10, 30), cv.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
            cv.putText(img, f'Frame: {frame_count}/{max_frames}', (10, 60), 
                      cv.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1)
            img_rgb = cv.cvtColor(img, cv.COLOR_BGR2RGB)
            clear_output(wait=True)
            plt.figure(figsize=(12, 8))
            plt.imshow(img_rgb)
            plt.title(f'人脸和眼睛检测 - 人脸: {face_count}, 眼睛: {total_eye_count}')
            plt.axis('off')
            plt.show()
            frame_count += 1
            time.sleep(0.03) 
    except KeyboardInterrupt:
        print("检测被用户中断")
    except Exception as e:
        print(f"发生错误: {e}")
    finally:
        cap.release()
        print(f"检测完成，共处理 {frame_count} 帧")
if __name__ == "__main__":
    detect_face_eyes()


