import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rcParams

plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'DejaVu Sans'] 
plt.rcParams['axes.unicode_minus'] = False  


mean1 = 13
sigma1 = 2
x = mean1 + sigma1 * np.random.randn(360)
mean2 = 28
sigma2 = 1
y = mean2 + sigma2 * np.random.randn(360)

# 合并数据并进行聚类分析
D = np.concatenate([x, y]) 
k = 2
centers = np.random.choice(D, size=k, replace=False)
new_centers = centers.copy()  
max_iter = 100  
for iter in range(max_iter):
    dist = np.zeros((D.shape[0], k))
    for j in range(k):
        dist[:, j] = np.abs(D - centers[j])
    
    clusters = np.argmin(dist, axis=1)
    new_centers = np.array([np.mean(D[clusters == j]) for j in range(k)])
    
    if np.allclose(centers, new_centers, atol=0.01):
        break 
    centers = new_centers
print("聚类结果分析:")
for i in range(k):
    print(f"第{i+1}个人的喜好温度: {centers[i]:.2f}°C")
cluster_counts = np.bincount(clusters)
t1 = float(cluster_counts[0] / 6)  
t2 = float(cluster_counts[1] / 6)  
print(f"第1个人的使用时间：{t1:.1f}小时")
print(f"第2个人的使用时间：{t2:.1f}小时")
temp = 25  
print(f"\n当前温度: {temp:.2f}°C")
if temp < np.mean([centers[0], centers[1]]):
    current_user = 1 if centers[0] < centers[1] else 2
    print(f"当前用户: 用户{current_user}")
else:
    current_user = 2 if centers[0] < centers[1] else 1
    print(f"当前用户: 用户{current_user}")
plt.figure(figsize=(12, 8))
plt.subplot(2, 1, 1)
plt.hist(x, 40, histtype='bar', facecolor='blue', alpha=0.7, label='用户1温度偏好')
plt.hist(y, 40, histtype='bar', facecolor='green', alpha=0.7, label='用户2温度偏好')
for i, center in enumerate(centers):
    plt.axvline(center, color='red' if i == 0 else 'orange', linestyle='--', 
                linewidth=2, label=f'用户{i+1}偏好温度: {center:.1f}°C')
plt.xlabel('Temperature')
plt.ylabel('Frequency')
plt.title('Preference Distribution')
plt.legend()
plt.grid(True, alpha=0.3)
plt.subplot(2, 1, 2)
labels = [f'用户1: {t1:.1f}小时', f'用户2: {t2:.1f}小时']
sizes = [t1, t2]
colors = ['lightblue', 'lightgreen']
plt.pie(sizes, labels=labels, colors=colors, autopct='%1.1f%%', startangle=90)
plt.axis('equal')
plt.title('Time distribution')
plt.tight_layout()
plt.show()
