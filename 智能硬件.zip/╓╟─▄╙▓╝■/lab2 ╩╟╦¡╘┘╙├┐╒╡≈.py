import numpy as np
import matplotlib.pyplot as plt
mean1=15 #第一个人喜欢的温度为15度
sigma1=2 #第一个人的方差
x=mean1+sigma1*np.random.randn(360)
mean2=25
sigma2=1
y=mean2+sigma2*np.randpm.randn(360)
D=np.concatenate(x,y)
K=2
centers=np.random.choice(D,size=2,replace=False)
new_centers=np.random.choice(D,size=2,replace=False)
mx=100
for i in range(mx):
    dist=np.zeros(D.shape[0],K)
    for j in range(K):
        dist[:,j]=np.abs(D-centers[j])
    clusters=np.argmin(dist,axis=1)
    for j in range(K):
        centers[j]=np.mean(D[clusters==j])
    if np.allclose(centers,new_centers,atol=0.01):
        break
    centers=new_centers
for i in range(K):
    print(f"第{i+1}个人的喜好温度：{centers[i]}")
cluster_counts=np.bincount(clusters)
t1=(float)(cluster_count[0])/2
t2=(float)(cluster_count[1])/2
print(f"第1个人的使用时间：{t1}小时")
print(f"第2个人的使用时间：{t2}小时")
tfile=open("") #导入文件名
text=tfile.read()
tfile.close()
secondline=text.split("\n")[1]
temp=secondline.split(" ")[9]
tem=float(temp[2:])
tem=tem/1000
print(f"现在的温度是:{tem}度")
if tem<np.mean(x):
    print("现在是第一个人在使用办公室")
else:
    print("现在是第二个人在使用办公室")
plt.hist(x,80,histtype=bar,facecolor=blue,alpha=0.75)
plt.hist(y,80,histtype=bar,facecolor=green,alpha=0.75)
plt.show()
