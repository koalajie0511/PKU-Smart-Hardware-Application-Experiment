'''import cv2 
import time
import numpy as np
cap=cv2.VideoCapture(0)
time.sleep(1)
try:
    while True:
        ret,frame=cap.read()
        face_cascade = cv2.CascadeClassifier(
            cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
        eye_cascade = cv2.CascadeClassifier(
            cv2.data.haarcascades + 'haarcascade_eye.xml')
        gray=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
        faces=face_cascade.detectMultiScale(gray,1.3,5)
        eyes=eye_cascade.detectMultiScale(gray,1.3,5)
        hsv=cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)
        skin=cv2.inRange(hsv,np.array([0,25,0]),np.array([50,255,255]))
        for (x,y,w,h) in eyes:
            frame=cv2.rectangle(frame,(x,y),(x+w,y+h),(255,0,0),2)
            mask_x_begin=x+100
            mask_x_end=x+300
            mask_y_begin=y+50
            mask_y_end=y+300
        skin_mask=np.zeros((frame.shape[0],frame.shape[1]),dtype=np.uint8)
        skin_mask[mask_y_begin:mask_y_end,mask_x_begin:mask_x_end]=skin[
            mask_y_begin:mask_y_end,mask_x_begin:mask_x_end]
        out=cv2.bitwise_and(frame,frame,mask=skin_mask)
        mask=np.where((out==0),0,1).astype("uint8")
        mask_area=mask.sum()
        mask_ratio=mask_area/((mask_x_end-mask_x_begin)*(mask_y_end
                                                         -mask_y_begin))
        if mask_ratio>0.8:
            cv2.putText(frame,"Mask Detected",(50,150),
                        cv2.FONT_HERSHEY_SIMPLEX,1,(0,255,0),2)
        else:
            cv2.putText(frame,"No Mask Detected",(50,150),
                        cv2.FONT_HERSHEY_SIMPLEX,1,(0,0,255),2)
        cv2.imshow("Mask Detection",frame)
        time.sleep(1)
except KeyboardInterrupt:
    cap.release()
    cv2.destroyAllWindows()
finally:
    cap.release()
    cv2.destroyAllWindows()'''
import cv2 
import time
import numpy as np
face_cascade = cv2.CascadeClassifier(
    cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
eye_cascade = cv2.CascadeClassifier(
    cv2.data.haarcascades + 'haarcascade_eye.xml')
cap = cv2.VideoCapture(0)
time.sleep(1)
try:
    while True:
        ret, frame = cap.read()
        if not ret:
            print("无法读取摄像头帧")
            break
        height, width = frame.shape[:2]
        mask_x_begin = width // 4
        mask_x_end = 3 * width // 4
        mask_y_begin = height // 4
        mask_y_end = 3 * height // 4
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = face_cascade.detectMultiScale(gray, 1.3, 5)
        eyes = eye_cascade.detectMultiScale(gray, 1.3, 5)
        for (x, y, w, h) in eyes:
            frame = cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 0), 2)
            mask_x_begin = max(0, x - 50)
            mask_x_end = min(width, x + w + 50)
            mask_y_begin = max(0, y + h + 20) 
            mask_y_end = min(height, y + h + 200)  
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        skin = cv2.inRange(hsv, np.array([0, 25, 0]), np.array([50, 255, 255]))
        skin_mask = np.zeros((frame.shape[0], frame.shape[1]), dtype=np.uint8)
        skin_mask[mask_y_begin:mask_y_end, mask_x_begin:mask_x_end] = skin[
            mask_y_begin:mask_y_end, mask_x_begin:mask_x_end]
        
        out = cv2.bitwise_and(frame, frame, mask=skin_mask)
        mask_area = skin_mask[mask_y_begin:mask_y_end, mask_x_begin:mask_x_end].sum() // 255
        mask_region_area = (mask_x_end - mask_x_begin) * (mask_y_end - mask_y_begin)
        
        if mask_region_area > 0:
            mask_ratio = mask_area / mask_region_area
        else:
            mask_ratio = 0
        cv2.rectangle(frame, (mask_x_begin, mask_y_begin), 
                     (mask_x_end, mask_y_end), (0, 255, 255), 2)
        
        if mask_ratio > 0.8:  
            cv2.putText(frame, "Mask Detected", (50, 50),
                        cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
        else:
            cv2.putText(frame, "No Mask Detected", (50, 50),
                        cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
        cv2.putText(frame, f"Ratio: {mask_ratio:.2f}", (50, 100),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        cv2.imshow("Mask Detection", frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break    
except KeyboardInterrupt:
    print("程序被用户中断")
except Exception as e:
    print(f"发生错误: {e}")
finally:
    cap.release()
    cv2.destroyAllWindows()
