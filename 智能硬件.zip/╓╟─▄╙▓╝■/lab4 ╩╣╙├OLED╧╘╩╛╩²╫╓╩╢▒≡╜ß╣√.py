import matplotlib.pyplot as plt
from periphery import GPIO
import time
from sklearn import datasets,svm,metrics
digits=datasets.load_digits()
images_and_labels=list(zip(digits.images,digits.target))
for index,(image,label) in enumerate(images_and_labels[:4]):
    plt.subplot(2,4,index+1)
    plt.axis("off")
    plt.imshow(image,cmap=plt.cm.gray_r,interpolation="nearest")
    plt.title("Training: %i"%label)
n_samples=len(digits.images)
data=digits.images.reshape((n_samples,-1))
classifier=svm.SVC(gamma=0.001)
classifier.fit(data[:n_samples//2],digits.target[:n_samples//2])
expected=digits.target[n_samples//2:]
predicted=classifier.predict(data[n_samples//2:])
print("Classification report for classifier %s:\n%s\n"
      % (classifier , metrics.classification_report(expected , predicted)))
print("Confusion matrix:\n%s" % metrics.confusion_matrix(expected , predicted))
images_and_predictions=list(zip(digits.images[n_samples//2:],predicted))
for index,(image,prediction) in enumerate(images_and_predictions[:4]):
    plt.subplot(2,4,index+5)
    plt.axis("off")
    plt.imshow(image,cmap=plt.cm.gray_r,interpolation="nearest")
    plt.title("Prediction: %i"%prediction)
plt.show()
a=n_samples//2
try:
    while True:
        if GPIO.input(20)==GPIO.LOW:
            kk=digits.image[a]
            digit=Image.fromarray((kk*8).astype(np.uint8),mode=L).resize((48,48)).convert
            img.paste(digit,(0,16,digit.size[0],digit.size[1]+16))
            disp.clear()
            disp.image(img)
            disp.display()
            font=ImageFont.load_default()
            draw=ImageDraw.Draw(img)
            number=predicted[a-n_samples//2]
            draw.text((50,40),str(number),font=font,fill=white)
            disp.image(img)
            disp.display()
            a+=1
        time.sleep(0.1)
except KeyboardInterrupt:
    GPIO.cleanup()
