'''import cv2 as cv # 加 载 OpenCV 库
img = cv.imread("Morning",1) # 打 开 图 像 文 件
cv.imshow('Lena',img) # 显 示 图 像
cv.waitKey(0) # 等 待 用 户 按 键
cv.destroyWindow('Lena') # 关 闭 显 示 窗 口'''
import cv2 as cv
import os
img = cv.imread('C:/Users/LIUSICHENG/Desktop/Morning.png')
image_path = 'Morning.png'
if os.path.exists(image_path):
    img = cv.imread(image_path)
if img is not None:
    cv.imshow('Lena', img)
    cv.waitKey(0)
    cv.destroyAllWindows()
else:
    print("图像加载失败！")
