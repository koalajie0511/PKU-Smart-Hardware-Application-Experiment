import matplotlib.pyplot as plt
from sklearn import datasets, svm, metrics
import numpy as np
digits = datasets.load_digits()
images_and_labels = list(zip(digits.images, digits.target))
for index, (image, label) in enumerate(images_and_labels[:4]):
    plt.subplot(2, 4, index + 1)
    plt.axis("off")
    plt.imshow(image, cmap=plt.cm.gray_r, interpolation="nearest")
    plt.title("Training: %i" % label)
n_samples = len(digits.images)
data = digits.images.reshape((n_samples, -1))
kernels = ['linear', 'poly', 'rbf', 'sigmoid']
for kernel in kernels:
    print(f"\n{'='*50}")
    print(f"使用核函数: {kernel}")
    print(f"{'='*50}")
    if kernel == 'rbf':
        classifier = svm.SVC(kernel=kernel, gamma=0.001)
    elif kernel == 'poly':
        classifier = svm.SVC(kernel=kernel, degree=3, gamma='scale')  # 多项式核可以调整degree
    else:
        classifier = svm.SVC(kernel=kernel, gamma='scale')
    classifier.fit(data[:n_samples//2], digits.target[:n_samples//2])
    expected = digits.target[n_samples//2:]
    predicted = classifier.predict(data[n_samples//2:])
    print("Classification report:\n%s" 
          % metrics.classification_report(expected, predicted))
    print("Accuracy: %.4f" % metrics.accuracy_score(expected, predicted))
    print("Confusion matrix:\n%s" % metrics.confusion_matrix(expected, predicted))
