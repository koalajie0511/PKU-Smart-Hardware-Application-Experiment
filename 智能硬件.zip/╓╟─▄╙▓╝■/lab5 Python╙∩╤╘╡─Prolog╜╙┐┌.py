from pyswip import Prolog
prolog=Prolog()
prolog.consult("birdrule.pl")
prolog.assertz("color(blue)")
prolog.assertz("season(all_year)")
prolog.assertz("size(small)")
for result in prolog.query("bird(X)"):
    print(result["X"])
