from periphery import GPIO
import time
button=GPIO(2,"in")
gpio=GPIO(3,"out")
button.edge="falling"
speed=1
flag=False #flag用于记录灯是否处于闪烁状态
last=0 #上一次检测到按键按下时的时间
def check_double():
    global last
    current=time.time() #本次检测到按键被按下的时间
    if current-last<0.5:
        last=current
        return True
    else:
        last=current
        return False
def blink():
    gpio.write(True)
    time.sleep(speed)
    gpio.write(False)
    time.sleep(speed)
try:
    while True:
        if button.poll(timeout=0.4):
            button.read()
            if check_double():
                flag=False #双击按键，停止闪烁
                speed=1 #回复原来的频率
                gpio.write(False)
            else:
                if flag==False: #原来是暗态
                    flag=True
                    speed=speed*2 #保证以单位频率起振
                speed=speed/2 #频率变为原来的两倍
        if flag==True: #灯管处于闪烁状态
            blink()
        else:
            time.sleep(0.1)
except KeyboardInterrupt:
    print("\n 程序停止")
finally:
    gpio.write(False)
    gpio.close()
    button.close()
