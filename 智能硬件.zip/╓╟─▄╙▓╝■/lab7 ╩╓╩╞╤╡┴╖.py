import numpy as np
import cv2
import time
import os
from io import BytesIO
from IPython.display import display
import ipywidgets as widgets
import threading  # 线程控制，防止 Notebook 卡死

# 配置参数
FOLDER_NAME = './dataset/train/Five'  # 样本保存目录
START_INDEX = 1  # 起始编号
CAPTURE_CNT = 500  # 每个手势采集的样本数量

# 创建保存目录
os.makedirs(FOLDER_NAME, exist_ok=True)

def frame_to_bytes(frame, fmt='jpeg', quality=60):
    """将帧转换为字节流用于显示"""
    jpg = cv2.imencode(f'.{fmt}', frame, [int(cv2.IMWRITE_JPEG_QUALITY), quality])[1]
    return jpg.tobytes()

# 控件初始化
image_widget = widgets.Image(format='jpeg', width=640, height=480, value=b'')
btn_preview = widgets.Button(description="1. 开始预览")
btn_capture = widgets.Button(description="2. 开始采集")
btn_stop = widgets.Button(description="3. 停止", button_style='danger')
progress = widgets.IntProgress(value=0, min=0, max=CAPTURE_CNT, description='采集:', 
                              style={'bar_color': 'lightblue'})
status_label = widgets.HTML(value="状态: 等待操作...")
controls = widgets.HBox([btn_preview, btn_capture, btn_stop])
display(widgets.VBox([image_widget, progress, controls, status_label]))

# 初始化摄像头
cap = cv2.VideoCapture(0)
if not cap.isOpened():
    raise Exception("无法打开摄像头")

# 控制标志（用 list 包装，线程内可变）
state = [False, False]  # [running, capturing]

# 线程函数 - 预览
def preview_loop():
    while state[0]:
        ret, frame = cap.read()
        if not ret:
            break
        # 预览：肤色分割
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        mask = cv2.inRange(hsv, np.array([0, 0, 0]), np.array([50, 200, 160]))
        preview = cv2.bitwise_and(frame, frame, mask=mask)
        preview = cv2.resize(preview, (640, 480))
        image_widget.value = frame_to_bytes(preview)
        time.sleep(0.03)
    status_label.value = "<b style='color:gray'>状态：预览已停止</b>"

# 线程函数 - 采集
def capture_loop():
    index = START_INDEX
    progress.value = 0
    status_label.value = "<b style='color:green'>状态：正在采集中...</b>"

    while state[0] and state[1] and index < START_INDEX + CAPTURE_CNT:
        ret, frame = cap.read()
        if not ret:
            continue
        
        # 处理并保存
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        mask = cv2.inRange(hsv, np.array([0, 0, 0]), np.array([50, 200, 160]))
        output = cv2.bitwise_and(gray, gray, mask=mask)
        output = cv2.resize(output, (80, 60))
        output = cv2.blur(output, (2, 2))
        cv2.imwrite(f'{FOLDER_NAME}/{index}.png', output)

        # 更新 UI
        progress.value = index - START_INDEX
        status_label.value = f"<b>状态：正在采集 {index} / {START_INDEX + CAPTURE_CNT - 1}</b>"
        image_widget.value = frame_to_bytes(frame, quality=50)

        index += 1
        time.sleep(0.5)  # 每0.5秒采集一张

    # 采集结束，统一停止
    state[0] = state[1] = False
    if index >= START_INDEX + CAPTURE_CNT:
        status_label.value = "<b style='color:green'>状态：采集完成!</b>"
    else:
        status_label.value = "<b style='color:gray'>状态：已停止</b>"
    progress.value = 0

# 按钮回调函数
def start_preview(b):
    if state[0]:
        return
    state[0] = True
    state[1] = False
    threading.Thread(target=preview_loop, daemon=True).start()

def start_capture(b):
    if not state[0]:
        status_label.value = "<b style='color:red'>错误：请先开始预览!</b>"
        return
    if state[1]:
        return
    state[1] = True
    threading.Thread(target=capture_loop, daemon=True).start()

def stop(b):
    state[0] = state[1] = False
    status_label.value = "<b style='color:gray'>状态：已停止</b>"
    progress.value = 0
    cap.release()

# 绑定事件
btn_preview.on_click(start_preview)
btn_capture.on_click(start_capture)
btn_stop.on_click(stop)
