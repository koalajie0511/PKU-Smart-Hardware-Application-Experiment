import time
import cv2
address=0x20
i2c=I2C("/dev/i2c-7")
msgs=[I2C.Message([0xff])]
i2c.transfer(address,msgs)
def read_adc(i2c,channel=0):
    if channel<0 or channel>3:
        raise ValueError("Channel must be 0-3")
    control=0x40|channel
    msgs=[I2C.Message([control])]
    i2c.transfer(PCF8591_ADDR,msgs)
    msgs=[I2C.Message([0x00],read=True)]
    adc_value=msgs[0].data[0]
    i2c.transfer(PCF8591_ADDR,msgs)
    return adc_value
def write_dac(i2c,value):
    if not (0<=value<=255):
        raise ValueError("Value must be 0-255")
    msgs=[I2C.Message([0x40,value])]
    print(msgs[0].data[0])
    i2c.transfer(PCF8591_ADDR,msgs)
    '''
#对电压信号进行采样并存储，输出信号的电压信息
try:
    while True:
        adc_calue=read_adc(i2c)
        print(adc_value)'''
#调整DA输出，设计发光二极管的开、关、调亮、调暗等功能
cap=cv2.VideoCapture(0)

try:
    while True:
        options=int(input("请输入数字：1表示开，2表示关，3表示调亮，4表示调暗"))
        if options==1:
            write_dac(i2c,255)
        elif options==2:
            write_dac(i2c,0)
        elif option==3:
            for i in range(255):
                write_dac(i2c,i)
                sleep(0.01)
        else:
            for i in range(255):
                write_dac(i2c,255-i)
                sleep(0.01)
        sleep(0.5)
'''
#用电位器的输出控制发光二极管的明暗
try:
    while True:
        adc_value=read_adc(i2c)
        write_dac(i2c,adc_value)'''
'''
import torch
import torch.nn as nn
import cv2
import numpy as np
import time
from periphery import I2C

# I2C设备地址
PCF8591_ADDR = 0x48

# 初始化I2C
try:
    i2c = I2C("/dev/i2c-7")
    address_8574 = 0x20
    msgs_init = [I2C.Message([0xff])]
    i2c.transfer(address_8574, msgs_init)
    print("✅ I2C初始化成功")
except Exception as e:
    print(f"❌ I2C初始化失败: {e}")
    i2c = None

# DAC控制函数
def write_dac(i2c, value):
    """控制DAC输出，调节LED亮度"""
    if not (0 <= value <= 255):
        raise ValueError("Value must be 0-255")
    if i2c is None:
        print(f"模拟DAC输出: {value}")
        return
    
    try:
        msgs = [I2C.Message([0x40, value])]
        i2c.transfer(PCF8591_ADDR, msgs)
    except Exception as e:
        print(f"DAC控制错误: {e}")

# 神经网络定义
class GestureNet(nn.Module):
    def __init__(self, num_classes=4):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(1, 6, 5), 
            nn.ReLU(),
            nn.MaxPool2d(4),
            nn.Conv2d(6, 12, 5), 
            nn.ReLU(),
            nn.MaxPool2d(4),
            nn.Flatten(),
            nn.Linear(12 * 3 * 2, 60),
            nn.ReLU(),
            nn.Linear(60, 30),
            nn.ReLU(),
            nn.Linear(30, num_classes)
        )
    
    def forward(self, x):
        return self.net(x)

# 加载模型
DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'
model = GestureNet(num_classes=4).to(DEVICE)

try:
    model.load_state_dict(torch.load("runs/model.pth", map_location=DEVICE))
    print("✅ 模型加载成功")
except Exception as e:
    print(f"❌ 模型加载失败: {e}")
    exit()

model.eval()

# 类别映射
class_mapping = {0: 'Five', 1: 'Left', 2: 'Palm', 3: 'Right'}

# 图像预处理函数
def preprocess_image(frame):
    """预处理图像用于神经网络输入"""
    if len(frame.shape) == 3:
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    else:
        gray = frame
    
    resized = cv2.resize(gray, (80, 60))
    blurred = cv2.blur(resized, (2, 2))
    normalized = blurred / 255.0
    tensor = torch.FloatTensor(normalized).unsqueeze(0).unsqueeze(0)
    
    return tensor

# 手势识别函数
def recognize_gesture(image_tensor):
    """识别手势类别"""
    with torch.no_grad():
        image_tensor = image_tensor.to(DEVICE)
        logits = model(image_tensor)
        probs = torch.softmax(logits, dim=1)
        conf, pred = torch.max(probs, dim=1)
    
    return class_mapping[pred.item()], conf.item()

# LED控制逻辑
class LEDController:
    def __init__(self):
        self.current_brightness = 0
        self.is_on = False
    
    def control_led(self, gesture, confidence):
        """根据手势控制LED"""
        if confidence < 0.6:
            return
        
        if gesture == 'Five':
            self.turn_on()
        elif gesture == 'Palm':
            self.turn_off()
        elif gesture == 'Right':
            self.increase_brightness()
        elif gesture == 'Left':
            self.decrease_brightness()
    
    def turn_on(self):
        if not self.is_on:
            self.is_on = True
            self.current_brightness = 255
            write_dac(i2c, 255)
            print("💡 LED已打开")
    
    def turn_off(self):
        if self.is_on:
            self.is_on = False
            self.current_brightness = 0
            write_dac(i2c, 0)
            print("🔌 LED已关闭")
    
    def increase_brightness(self):
        if self.is_on and self.current_brightness < 255:
            self.current_brightness = min(255, self.current_brightness + 25)
            write_dac(i2c, self.current_brightness)
            print(f"🔆 亮度增加至: {self.current_brightness}")
        elif not self.is_on:
            self.turn_on()
    
    def decrease_brightness(self):
        if self.is_on and self.current_brightness > 0:
            self.current_brightness = max(0, self.current_brightness - 25)
            write_dac(i2c, self.current_brightness)
            print(f"🔅 亮度降低至: {self.current_brightness}")
            if self.current_brightness == 0:
                self.is_on = False
                print("🔌 LED已关闭")

# 主函数 - 精简版本，适合JupyterLab
def gesture_control():
    """手势识别控制LED - JupyterLab版本"""
    cap = cv2.VideoCapture(0)
    led_controller = LEDController()
    
    if not cap.isOpened():
        print("❌ 无法打开摄像头")
        return
    
    print("🚀 手势识别LED控制系统启动")
    print("📋 手势控制:")
    print("  - ✋ 五指张开: 开灯")
    print("  - 🖐️ 手掌: 关灯") 
    print("  - ➡️ 右滑: 调亮")
    print("  - ⬅️ 左滑: 调暗")
    print("🛑 按 Ctrl+C 停止程序")
    
    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                print("❌ 无法读取摄像头帧")
                break
            
            frame = cv2.flip(frame, 1)
            
            # 直接使用灰度图预处理，简化处理流程
            processed_tensor = preprocess_image(frame)
            
            # 识别手势
            gesture, confidence = recognize_gesture(processed_tensor)
            
            # 控制LED
            led_controller.control_led(gesture, confidence)
            
            # 控制帧率
            time.sleep(0.2)  # 降低处理频率
            
    except KeyboardInterrupt:
        print("\n🛑 程序被用户中断")
    except Exception as e:
        print(f"❌ 发生错误: {e}")
    finally:
        # 释放资源
        cap.release()
        # 关闭LED
        led_controller.turn_off()
        print("✅ 程序结束，LED已关闭")

# 在JupyterLab中运行
if __name__ == "__main__":
    gesture_control()'''
