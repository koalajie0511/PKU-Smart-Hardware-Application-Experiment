from periphery import GPIO
import time
def main():
    gpio=GPIO(3,"out")
    print("Fading LED on GPIO 3 using software PWM")
    try:
        while True:
            for i in range(STEPS):
                duty=i/(STEPS-1)
                pwm_cycle(gpio,duty)
            for i in reversed(range(STEPS)):
                duty=i/(STEPS-1)
                pwm_cycle(gpio,duty)
    except KeyboardInterrupt:
        print("\nExiting")
    finally:
        gpio.write(False)
        gpio.close()
def pwm_cycle(gpio,duty):
    on_time=PWM_PERIOD*duty
    off_time=PWM_PERIOD-on_time
    gpio.write(True)
    time.sleep(on_time)
    gpio.write(False)
    time.sleep(off_time)
if __name__=="__main__":
    STEPS=int(input("STEP:"))
    PWM_PERIOD=float(input("PWM_PERIOD:"))
    main()
#推荐的参数取值：STEPS:50-100;PWM_PERIOD:0.01-0.05
