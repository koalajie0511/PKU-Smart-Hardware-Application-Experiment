import RPi.GPIO as GPIO
import smbus
import time
from time import sleep

# GPIO 初始化
GPIO.setmode(GPIO.BCM)
GPIO.setup(12, GPIO.OUT)  # 使用 12 号管脚控制舵机
GPIO.setup(20, GPIO.IN, GPIO.PUD_UP)

# PWM 初始化（舵机控制）
pwm = GPIO.PWM(12, 50)  # 频率 50Hz
pwm.start(0)

# I2C 初始化（五向摇杆）
address = 0x20  # 目标设备地址
bus = smbus.SMBus(1)  # 使用树莓派上的第 1 条 I2C 总线
bus.write_byte(address, 0x8f)  # 初始化设备

# 全局变量：记录用户回答
yes_s = []
no_s = []

# 主输出函数
def go(animal):
    print("I guess that the animal is: ", animal)

# 假设生成函数（推理入口）
def hypothesize():
    if cheetah():
        return "cheetah"
    elif tiger():
        return "tiger"
    elif giraffe():
        return "giraffe"
    elif zebra():
        return "zebra"
    elif ostrich():
        return "ostrich"
    elif penguin():
        return "penguin"
    elif albatross():
        return "albatross"
    else:
        return "unknown"

# 动物识别规则函数
def cheetah():
    return mammal() and carnivore() and verify("has_tawny_color") and verify("has_dark_spots")

def tiger():
    return mammal() and carnivore() and verify("has_tawny_color") and verify("has_black_stripes")

def giraffe():
    return ungulate() and verify("has_long_neck") and verify("has_long_legs")

def zebra():
    return ungulate() and verify("has_black_stripes")

def ostrich():
    return bird() and verify("does_not_fly") and verify("has_long_neck")

def penguin():
    return bird() and verify("does_not_fly") and verify("swims") and verify("is_black_and_white")

def albatross():
    return bird() and verify("appears_in_story_Ancient_Mariner") and verify("flys_well")

# 分类规则函数
def mammal():
    return verify("has_hair") or verify("gives_milk")

def bird():
    return verify("has_feathers") or (verify("flys") and verify("lays_eggs"))

def carnivore():
    return verify("eats_meat") or (verify("has_pointed_teeth") and verify("has_claws") and verify("has_forward_eyes"))

def ungulate():
    return mammal() and (verify("has_hooves") or verify("chews_cud"))

# 交互函数：通过摇杆获取用户输入
def ask(question):
    print("Does the animal have the following attribute: " + question + "?")
    
    while True:
        value = bus.read_byte(address)  # 读取摇杆状态
        
        if (value & 0x1) == 0:  # 向左 = yes
            print("Left, yes")
            response = "yes"
            yes_s.append(question)  # 记录到 yes 列表
            sleep(1)
            return response
            
        elif (value & 0x8) == 0:  # 向右 = no
            print("Right, no")
            response = "no"
            no_s.append(question)  # 记录到 no 列表
            sleep(1)
            return response

# 验证函数：检查问题是否已回答
def verify(s):
    if s in yes_s:  # 问题在 yes 列表中
        return True
    elif s in no_s:  # 问题在 no 列表中
        return False
    else:  # 未回答过，进行提问
        ans = ask(s)
        return ans == "yes" or ans == "y"

# 舵机控制函数：根据识别结果转动到对应角度
def a(ani):
    if ani == "cheetah":
        pwm.ChangeDutyCycle(3.5)
    elif ani == "tiger":
        pwm.ChangeDutyCycle(8.7)
    elif ani == "giraffe":
        pwm.ChangeDutyCycle(10.5)
    elif ani == "zebra":
        pwm.ChangeDutyCycle(7.25)
    elif ani == "ostrich":
        pwm.ChangeDutyCycle(12.5)
    elif ani == "penguin":
        pwm.ChangeDutyCycle(4.75)
    elif ani == "albatross":
        pwm.ChangeDutyCycle(6.0)
    else:  # unknown
        pwm.ChangeDutyCycle(2.5)
    
    sleep(1)

# 清理函数：重置回答记录
def undo():
    yes_s.clear()
    no_s.clear()

# 主程序
if __name__ == "__main__":
    try:
        # 初始化回答记录
        yes_s = []
        no_s = []
        
        # 执行动物识别
        animal = hypothesize()
        go(animal)
        
        # 控制舵机显示结果
        a(animal)
        
        # 清理资源
        pwm.stop()
        GPIO.cleanup()
        undo()
        
    except Exception as e:
        print("Error:", e)
        pwm.stop()
        GPIO.cleanup()
