import matplotlib.pyplot as plt
import numpy as np
r1=2
r2=4
p1=[]
p2=[]
for i in range(10000):
    x=np.random.rand()*r2*2-r2
    y=np.random.rand()*r2*2-r2
    if abs(x*x+y*y-r1)<0.5:
        p1.append([x,y])
    if abs(x*x+y*y-r2)<0.5:
        p2.append([x,y])
plt.scatter(np.array(p1)[:,0],np.array(p1)[:,1],c="r",s=3)
plt.scatter(np.array(p2)[:,0],np.array(p2)[:,1],c="b",s=3)
plt.show()
