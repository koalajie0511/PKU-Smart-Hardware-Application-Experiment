import os
import json
import soundfile as sf
import pyaudio
import numpy as np
RATE = 48000  # 采样率
CHUNK = 2000  # 每次读取的音频块大小
LENGTH = 1.0  # 每个数字录音时长（秒）
N_EACH = 10   # 每个数字录制次数，共100条
def record_one(sec):
    frames = []
    for _ in range(int(RATE / CHUNK * sec)):
        data = stream.read(CHUNK, exception_on_overflow=False)
        frames.append(np.frombuffer(data, np.int16))
    return np.concatenate(frames).astype(np.float32) / 32768
p = pyaudio.PyAudio()
stream = p.open(format=pyaudio.paInt16, 
                channels=1,
                rate=RATE, 
                input=True, 
                frames_per_buffer=CHUNK)
os.makedirs("digits_wav", exist_ok=True)
meta = []
for digit in range(10):
    input(f"\n请准备读数字 {digit}，按回车开始录音（共 {N_EACH} 次）")
    for idx in range(N_EACH):
        print(f"录音 {idx+1}/{N_EACH}...", end="")
        wav = record_one(LENGTH)
        fname = f"digits_wav/{digit}_{idx}.wav"
        sf.write(fname, wav, RATE)
        meta.append({"file": fname, "label": digit})
        print(" 完成")
with open("digits_wav/meta.json", "w") as f:
    json.dump(meta, f, indent=2)
stream.stop_stream()
stream.close()
p.terminate()
print("所有录音完成！")
