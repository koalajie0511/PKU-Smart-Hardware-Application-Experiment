import time
from periphery import GPIO
from periphery import I2C
SERVO_GPIO = 80
PWM_FREQ = 50
PERIOD = 1 / PWM_FREQ
address = 0x20
i2c = I2C("/dev/i2c-7")
servo_gpio = GPIO(SERVO_GPIO, "out")
msgs = [I2C.Message([0xff])]
i2c.transfer(address, msgs)
msgs = [I2C.Message([0x00], read=True)]
i2c.transfer(address, msgs)
joystick_val = msgs[0].data[0] 
yes_s = []
no_s = []
def angle_to_pulse_width(angle):
    return 0.0005 + (angle / 180.0) * 0.002
def set_servo(gpio, angle):
    pulse_width = angle_to_pulse_width(angle)
    gpio.write(True)
    time.sleep(pulse_width)
    gpio.write(False)
    time.sleep(PERIOD - pulse_width)
def move_servo_to_animal_position(animal):
    animal_angles = {
        "cheetah": 25,
        "tiger": 120,
        "giraffe": 140,
        "zebra": 95,
        "ostrich": 170,
        "penguin": 60,
        "albatross": 85,
        "unknown": 0
    }
    angle = animal_angles.get(animal, 90) 
    print(f"Moving servo to {angle} degrees for {animal}")
    return angle
def go(animal):
    print("I guess that the animal is: ", animal)
    move_servo_to_animal_position(animal)
def hypothesize():
    if cheetah():
        return "cheetah"
    elif tiger():
        return "tiger"
    elif giraffe():
        return "giraffe"
    elif zebra():
        return "zebra"
    elif ostrich():
        return "ostrich"
    elif penguin():
        return "penguin"
    elif albatross():
        return "albatross"
    else:
        return "unknown"
def cheetah():
    return mammal() and carnivore() and verify("has_tawny_color") and verify("has_dark_spots")
def tiger():
    return mammal() and carnivore() and verify("has_tawny_color") and verify("has_black_stripes")
def giraffe():
    return ungulate() and verify("has_long_neck") and verify("has_long_legs")
def zebra():
    return ungulate() and verify("has_black_stripes")
def ostrich():
    return bird() and verify("does_not_fly") and verify("has_long_neck")
def penguin():
    return bird() and verify("does_not_fly") and verify("swims") and verify("is_black_and_white")
def albatross():
    return bird() and verify("appears_in_story_Ancient_Mariner") and verify("flys_well")
def mammal():
    return verify("has_hair") or verify("gives_milk")
def bird():
    return verify("has_feathers") or (verify("flys") and verify("lays_eggs"))
def carnivore():
    return verify("eats_meat") or (verify("has_pointed_teeth") and verify("has_claws") and verify("has_forward_eyes"))
def ungulate():
    return mammal() and (verify("has_hooves") or verify("chews_cud"))
def ask(question):
    print("Does the animal have the following attribute: " + question + "?")
    while True:
        '''user_input = input("Enter 'y' for yes or 'n' for no: ").lower()
        if user_input in ['y', 'yes']:
            yes_s.append(question)
            return "yes"
        elif user_input in ['n', 'no']:
            no_s.append(question)
            return "no"
        else:
            print("Invalid input. Please enter 'y' or 'n'.")'''
        mags=[I2C.Message([0xff])]
        i2c.transfer(address,mags)
        mags=[I2C.Message([0x00],read=True)]
        i2c.transfer(address,mags)
        joystick_val=mags[0].data[0]
        #左边为254,右边为247
        if joystick_val==254:
            yes_s.append(question)
            print("y")
            time.sleep(3)
            return "yes"
        elif joystick_val==247:
            no_s.append(question)
            print("no")
            time.sleep(3)
            return "no"
        time.sleep(0.5)
def verify(s):
    if s in yes_s:  
        return True
    elif s in no_s:  
        return False
    else:  
        ans = ask(s)
        return ans == "yes"
def undo():
    yes_s.clear()
    no_s.clear()
def cleanup():
    servo_gpio.write(False)
    servo_gpio.close()
    i2c.close()
if __name__ == "__main__":
    yes_s = []
    no_s = []
    animal = hypothesize()
    go(animal)
    print("Servo will hold position for 5 seconds...")
    angle=move_servo_to_animal_position(animal)
    for _ in range(5000):  
        set_servo(servo_gpio, angle)
        #time.sleep(5)
    undo()
    cleanup()
    print("System cleaned up and exited.")





















import time
from periphery import GPIO
from periphery import I2C
SERVO_GPIO = 80
PWM_FREQ = 50
PERIOD = 1 / PWM_FREQ
address = 0x20
i2c = I2C("/dev/i2c-7")
servo_gpio = GPIO(SERVO_GPIO, "out")
msgs = [I2C.Message([0xff])]
i2c.transfer(address, msgs)
msgs = [I2C.Message([0x00], read=True)]
i2c.transfer(address, msgs)
joystick_val = msgs[0].data[0] 
yes_s = []
no_s = []
def angle_to_pulse_width(angle):
    return 0.001 + (angle / 180.0) * 0.001
def set_servo(gpio, angle):
    pulse_width = angle_to_pulse_width(angle)
    gpio.write(True)
    time.sleep(pulse_width)
    gpio.write(False)
    time.sleep(PERIOD - pulse_width)
def move_servo_to_animal_position(animal):
    animal_angles = {
        "cheetah": 160,
        "tiger": 60,
        "giraffe": 45,
        "zebra": 90,
        "ostrich": 20,
        "penguin": 150,
        "albatross": 80,
        "unknown": 170 
    }
    angle = animal_angles.get(animal, 90) 
    print(f"Moving servo to {angle} degrees for {animal}")
    return angle
def go(animal):
    print("I guess that the animal is: ", animal)
    move_servo_to_animal_position(animal)
def hypothesize():
    if cheetah():
        return "cheetah"
    elif tiger():
        return "tiger"
    elif giraffe():
        return "giraffe"
    elif zebra():
        return "zebra"
    elif ostrich():
        return "ostrich"
    elif penguin():
        return "penguin"
    elif albatross():
        return "albatross"
    else:
        return "unknown"
def cheetah():
    return mammal() and carnivore() and verify("has_tawny_color") and verify("has_dark_spots")
def tiger():
    return mammal() and carnivore() and verify("has_tawny_color") and verify("has_black_stripes")
def giraffe():
    return ungulate() and verify("has_long_neck") and verify("has_long_legs")
def zebra():
    return ungulate() and verify("has_black_stripes")
def ostrich():
    return bird() and verify("does_not_fly") and verify("has_long_neck")
def penguin():
    return bird() and verify("does_not_fly") and verify("swims") and verify("is_black_and_white")
def albatross():
    return bird() and verify("appears_in_story_Ancient_Mariner") and verify("flys_well")
def mammal():
    return verify("has_hair") or verify("gives_milk")
def bird():
    return verify("has_feathers") or (verify("flys") and verify("lays_eggs"))
def carnivore():
    return verify("eats_meat") or (verify("has_pointed_teeth") and verify("has_claws") and verify("has_forward_eyes"))
def ungulate():
    return mammal() and (verify("has_hooves") or verify("chews_cud"))
def ask(question):
    print("Does the animal have the following attribute: " + question + "?")
    while True:
        user_input = input("Enter 'y' for yes or 'n' for no: ").lower()
        if user_input in ['y', 'yes']:
            yes_s.append(question)
            return "yes"
        elif user_input in ['n', 'no']:
            no_s.append(question)
            return "no"
        else:
            print("Invalid input. Please enter 'y' or 'n'.")
def verify(s):
    if s in yes_s:  
        return True
    elif s in no_s:  
        return False
    else:  
        ans = ask(s)
        return ans == "yes"
def undo():
    yes_s.clear()
    no_s.clear()
def cleanup():
    servo_gpio.write(False)
    servo_gpio.close()
    i2c.close()
if __name__ == "__main__":
    try:
        yes_s = []
        no_s = []
        animal = hypothesize()
        go(animal)
        print("Servo will hold position for 5 seconds...")
        angle=move_servo_to_animal_position(animal)
        for _ in range(500):  
            set_servo(servo_gpio, angle)
        #time.sleep(5)
    except Exception as e:
        print("Error:", e)
    finally:
        undo()
        cleanup()
        print("System cleaned up and exited.")


















