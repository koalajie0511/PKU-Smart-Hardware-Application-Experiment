from python_speech_features import mfcc
from scipy.io import wavfile
from hmmlearn import hmm
import os
import joblib
import numpy as np
import pyaudio
import wave
import time
import warnings
warnings.filterwarnings("ignore")

filen = "./test.wav"

def record_audio(filename, record_second): 
    CHUNK = 512
    FORMAT = pyaudio.paInt16
    CHANNELS = 1
    RATE = 44100
    p = pyaudio.PyAudio()
    print("begin")
    stream = p.open(format=FORMAT, channels=CHANNELS, rate=RATE, input=True,
                    frames_per_buffer=CHUNK)
    wf = wave.open(filename, 'wb')
    wf.setnchannels(CHANNELS)
    wf.setsampwidth(p.get_sample_size(FORMAT))
    wf.setframerate(RATE)
    
    for i in range(0, int(RATE/CHUNK * record_second)):
        data = stream.read(CHUNK)
        wf.writeframes(data)
    
    print("done")
    stream.stop_stream()
    stream.close()
    p.terminate()
    wf.close()

def gen_wavlist(filepath):
    wavdict = {}
    labeldict = {}
    for (dirpath, dirnames, filenames) in os.walk(filepath):
        for filename in filenames:
            if filename.endswith(".wav"):
                line = os.path.join(dirpath, filename)
                fileid = filename.strip('.wav')
                label = fileid.split("_")[0]
                wavdict[fileid] = line
                labeldict[fileid] = label
    return wavdict, labeldict

def compute_mfcc(file):
    fs, audio = wavfile.read(file)
    mfcc_feat = mfcc(audio)
    return mfcc_feat

class Model():
    def __init__(self, CATEGORY=None, n_comp=3, n_mix=3, cov_type='diag', n_iter=1000):
        super(Model, self).__init__()
        self.CATEGORY = CATEGORY
        self.category = len(CATEGORY)
        self.n_comp = n_comp
        self.n_mix = n_mix
        self.cov_type = cov_type
        self.n_iter = n_iter
        self.models = []
        for k in range(self.category):
            model = hmm.GMMHMM(
                n_components=self.n_comp, 
                n_mix=self.n_mix,
                covariance_type=self.cov_type, 
                n_iter=self.n_iter,
                init_params='',  # 防止警告
                random_state=42
            )
            self.models.append(model)
    
    def train(self, wavdict=None, labeldict=None):
        print("开始训练...")
        print(f"训练数据数量: {len(wavdict)}")
        
        # 按类别组织训练数据
        train_data = {label: [] for label in self.CATEGORY}
        
        for fileid, filepath in wavdict.items():
            label = labeldict[fileid]
            if label in self.CATEGORY:
                mfcc_feat = compute_mfcc(filepath)
                train_data[label].append(mfcc_feat)
        
        # 训练每个类别的模型
        for i, label in enumerate(self.CATEGORY):
            print(f"训练数字 {label} 的模型...")
            if train_data[label]:  # 确保有训练数据
                # 将所有该数字的MFCC特征连接起来
                X = np.vstack(train_data[label])
                lengths = [len(feat) for feat in train_data[label]]
                
                try:
                    self.models[i].fit(X, lengths=lengths)
                    print(f"数字 {label} 训练完成")
                except Exception as e:
                    print(f"数字 {label} 训练失败: {e}")
            else:
                print(f"警告: 数字 {label} 没有训练数据")
        
        print("所有模型训练完成")
    
    def reco(self, fil):
        try:
            mfcc_feat = compute_mfcc(fil)
            scores = []
            
            for k in range(self.category):
                try:
                    # 检查模型是否已经训练
                    if hasattr(self.models[k], 'startprob_') and self.models[k].startprob_ is not None:
                        score = self.models[k].score(mfcc_feat)
                        scores.append(score)
                    else:
                        scores.append(-np.inf)  # 未训练的模型给最低分
                except Exception as e:
                    print(f"模型 {self.CATEGORY[k]} 评分失败: {e}")
                    scores.append(-np.inf)
            
            if len(scores) > 0 and max(scores) > -np.inf:
                best_index = np.argmax(scores)
                result = self.CATEGORY[best_index]
                print(f'识别结果: {result}')
                return result
            else:
                print("所有模型评分失败")
                return None
                
        except Exception as e:
            print(f"识别过程中出错: {e}")
            return None
    
    def save(self, path="models.pkl"):
        joblib.dump(self.models, path)
        print(f"模型已保存到 {path}")
    
    def load(self, path="models.pkl"):
        self.models = joblib.load(path)
        print(f"模型已从 {path} 加载")

if __name__ == '__main__':
    CATEGORY = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
    
    # 检查录音文件是否存在
    if not os.path.exists('./digits_wav'):
        print("错误: 找不到录音文件目录 './digits_wav'")
        print("请先运行录音程序生成训练数据")
        exit(1)
    
    wavdict, labeldict = gen_wavlist('./digits_wav')
    print(f"找到 {len(wavdict)} 个音频文件")
    
    if len(wavdict) == 0:
        print("错误: 没有找到任何.wav文件")
        exit(1)
    
    # 检查每个数字是否有足够的训练数据
    label_counts = {}
    for label in labeldict.values():
        label_counts[label] = label_counts.get(label, 0) + 1
    
    print("各数字训练数据数量:")
    for label in CATEGORY:
        count = label_counts.get(label, 0)
        print(f"数字 {label}: {count} 个")
    
    # 分割训练集和测试集
    train_wavdict = {}
    train_labeldict = {}
    test_wavdict = {}
    test_labeldict = {}
    
    # 每个数字取前8个作为训练，后2个作为测试
    for digit in CATEGORY:
        digit_files = [k for k, v in labeldict.items() if v == digit]
        digit_files.sort()  # 按文件名排序
        
        if len(digit_files) >= 8:
            # 训练集
            for fileid in digit_files[:8]:
                train_wavdict[fileid] = wavdict[fileid]
                train_labeldict[fileid] = labeldict[fileid]
            # 测试集
            for fileid in digit_files[8:10]:
                test_wavdict[fileid] = wavdict[fileid]
                test_labeldict[fileid] = labeldict[fileid]
    
    print(f"训练集: {len(train_wavdict)} 个文件")
    print(f"测试集: {len(test_wavdict)} 个文件")
    
    # 进行训练
    print("开始训练模型...")
    models = Model(CATEGORY=CATEGORY, n_comp=3, n_mix=2, n_iter=100)
    models.train(wavdict=train_wavdict, labeldict=train_labeldict)
    models.save()
    
    print("\n测试模型...")
    correct = 0
    total = 0
    
    for key in test_wavdict.keys():
        actual_label = test_labeldict[key]
        predicted_label = models.reco(test_wavdict[key])
        
        if predicted_label == actual_label:
            correct += 1
            print(f"✓ 正确: 预测 {predicted_label}, 实际 {actual_label}")
        else:
            print(f"✗ 错误: 预测 {predicted_label}, 实际 {actual_label}")
        total += 1
        print('---')
    
    if total > 0:
        accuracy = correct / total * 100
        print(f"测试准确率: {accuracy:.1f}% ({correct}/{total})")
    
    print("\n开始实时测试...")
    print("按 Ctrl+C 停止")
    try:
        while True:
            record_audio(filen, record_second=1)
            models.reco(filen)
            time.sleep(0.5)
    except KeyboardInterrupt:
        print("\n程序结束")
