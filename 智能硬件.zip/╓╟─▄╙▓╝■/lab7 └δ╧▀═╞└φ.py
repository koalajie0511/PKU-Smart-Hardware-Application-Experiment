import torch
import torch.nn as nn
class Net(nn.Module):
    def __init__(self, num_classes=4):
        super().__init__()
        self.net = nn.Sequential(
            # 卷积层1: 输入1通道, 输出6通道, 5x5卷积核
            nn.Conv2d(1, 6, 5), 
            nn.ReLU(),
            # 池化层1: 4x4最大池化
            nn.MaxPool2d(4),
            
            # 卷积层2: 输入6通道, 输出12通道, 5x5卷积核
            nn.Conv2d(6, 12, 5), 
            nn.ReLU(),
            # 池化层2: 4x4最大池化
            nn.MaxPool2d(4),
            
            # 展平特征图
            nn.Flatten(),
            
            # 全连接层
            nn.Linear(12 * 3 * 2, 60),  # 根据输入尺寸调整
            nn.ReLU(),
            nn.Linear(60, 30),
            nn.ReLU(),
            nn.Linear(30, num_classes)  # 输出层
        )
    
    def forward(self, x):
        return self.net(x)
PTH_PATH="runs/model.pth"
ONNX_PATH="runs/model.onnx"
INPUT_SHAPE=(1,1,60,80)
device="cpu"
model=Net(num_classes=4).to(device)
model.load_state_dict(torch.load(PTH_PATH,map_location=device))
model.eval()
dummy=torch.randn(INPUT_SHAPE)
torch.onnx.export(model,dummy,ONNX_PATH,
                  opset_version=11,
                  do_constant_folding=True,
                  input_names=["input"],output_names=["output"],
                  dynamic_axes{"input":{0,"batch"},"output":{0,"batch"}})
import numpy as np
import cv2
from ais_bench.infer.interface import InferSession
from scipy.special import softmax
import json
OM_PATH="runs/model.om"
IMG_PATH="test.png"
INPUT_HW=(60,80)
with open("runs/classes.json","r",encoding="utf-8") as f:
    class_to_idx=json.load(f)
class_names=[None]*len(class_to_idx)
for name,idx in class_to_idx.items():
    class_names[idx]=name
sess=InferSession(device_id=0,model_path=OM_PATH)
img=cv2.imread(IMG_PATH,cv2.IMREAD_GRAYSCALE)
img=cv2.resize(img,(INPUT_HW[1],INPUT_HW[0]))
img=img.astype(np.float32)/255.0
img=img[np.newaxis,np.newaxis,...]
outs=sess.infer([img])
prob=softmax(outs[0].squeeze())
pred=int(prob.argmax())
conf=float(prob[pred])
print(f"预测类别:{class_names[pred]}")
print(f"置信度:{conf:.4f}")
