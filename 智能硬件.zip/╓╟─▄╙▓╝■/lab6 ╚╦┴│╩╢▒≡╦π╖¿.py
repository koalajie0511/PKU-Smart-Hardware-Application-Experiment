import cv2 as cv
import matplotlib.pyplot as plt
def detect_and_return_image(filename):
    face_cascade = cv.CascadeClassifier(cv.data.haarcascades + 'haarcascade_frontalface_default.xml')
    img = cv.imread(filename)
    if img is None:
        print("No pictures!")
        return None
    gray = cv.cvtColor(img, cv.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, 1.3, 5)
    for (x, y, w, h) in faces:
        cv.rectangle(img, (x, y), (x+w, y+h), (255, 0, 0), 2)
    return cv.cvtColor(img, cv.COLOR_BGR2RGB)
def show_pic(filename):
    result_img = detect_and_return_image(filename)
    if result_img is not None:
        plt.figure(figsize=(10, 6))
        plt.imshow(result_img)
        plt.title("Face Detected!")
        plt.axis("off")
        plt.show()
def detect_face_from_camera():
    face_cascade = cv.CascadeClassifier(cv.data.haarcascades + 'haarcascade_frontalface_default.xml')
    cap = cv.VideoCapture(0)  
    if not cap.isOpened():
        print("无法打开摄像头")
        return
    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                print("无法读取帧")
                break
            gray = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)
            faces = face_cascade.detectMultiScale(gray, 1.3, 5)
            for (x, y, w, h) in faces:
                cv.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 0), 2)
            cv.imshow('Face Detection', frame)
            if cv.waitKey(1) & 0xFF == ord('q'):
                break
    finally:
        cap.release()
        cv.destroyAllWindows()
if __name__ == "__main__":  
    detect_face_from_camera()
