import cv2 as cv
import numpy as np
import time
from PIL import Image
import matplotlib.pyplot as plt
from sklearn import datasets,svm,metrics

digits=datasets.load_digits()
images_and_labels=list(zip(digits.images,digits.target))

for index,(image,label) in enumerate(images_and_labels[:4]):
    plt.subplot(2,3,index+1)
    plt.axis("off")
    plt.imshow(image,cmap=plt.cm.gray_r,interpolation="nearest")
    plt.title("Training:%i"%label)

plt.tight_layout()
plt.show()  # 显示训练图像

n_samples=len(digits.images)
data=digits.images.reshape((n_samples,-1))
classifier=svm.SVC(gamma=0.001)
classifier.fit(data[:n_samples//2],digits.target[:n_samples//2])

cap=cv.VideoCapture(0)

print("程序开始运行，按 'q' 键退出...")

try:
    while True:
        ret,frame=cap.read()
        if not ret:
            print("无法读取摄像头画面")
            break
            
        # 创建原始画面的副本用于显示
        display_frame = frame.copy()
        
        # 在画面上添加识别结果
        gray=cv.cvtColor(frame,cv.COLOR_BGR2GRAY)
        resized=cv.resize(gray,(8,8),interpolation=cv.INTER_AREA)
        re=(resized/16).astype(int)
        reshaped=re.reshape(1,-1)
        predicted=classifier.predict(reshaped)
        
        print(f"预测数字: {predicted[0]}")
        
        # 在画面上显示预测结果
        cv.putText(display_frame, f"Digit: {predicted[0]}", (20, 50), 
                  cv.FONT_HERSHEY_SIMPLEX, 1.5, (0, 255, 0), 3)
        
        # 添加其他信息
        cv.putText(display_frame, "Press 'q' to quit", (20, display_frame.shape[0] - 20), 
                  cv.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        
        # 显示处理后的灰度图像（可选）
        gray_display = cv.cvtColor(gray, cv.COLOR_GRAY2BGR)
        gray_resized = cv.resize(gray_display, (200, 200))
        
        # 在右下角显示灰度图像
        h, w = display_frame.shape[:2]
        display_frame[h-200:h, w-200:w] = gray_resized
        
        # 在灰度图像上添加标签
        cv.putText(display_frame, "Gray", (w-190, h-180), 
                  cv.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
        
        # 显示摄像头画面
        cv.imshow('Handwritten Digit Recognition', display_frame)
        
        # 降低识别频率以减少CPU使用
        time.sleep(0.1)
        
        # 检测按键
        if cv.waitKey(1) & 0xFF == ord('q'):
            break
            
except KeyboardInterrupt:
    print("用户终止了程序！")
    
finally:
    cap.release()
    cv.destroyAllWindows()
    print("程序已退出")
'''
import cv2 as cv
import numpy as np
from sklearn import datasets, svm, metrics
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
import matplotlib.pyplot as plt
import time

# 设置matplotlib
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

def create_camera_like_training_data():
    """创建与摄像头数据分布相似的训练数据"""
    digits = datasets.load_digits()
    
    camera_like_images = []
    camera_like_targets = []
    
    for image, target in zip(digits.images, digits.target):
        # 反相处理 - 将白底黑字变为黑底白字
        inverted = 16 - image
        
        # 添加噪声和模糊，模拟摄像头效果
        noisy = inverted + np.random.normal(0, 0.5, image.shape)
        noisy = np.clip(noisy, 0, 16)
        
        # 调整对比度
        high_contrast = inverted * 1.2
        high_contrast = np.clip(high_contrast, 0, 16)
        
        # 添加到训练集
        camera_like_images.extend([inverted, noisy, high_contrast])
        camera_like_targets.extend([target, target, target])
    
    camera_like_images = np.array(camera_like_images)
    camera_like_targets = np.array(camera_like_targets)
    
    return camera_like_images, camera_like_targets

def preprocess_for_camera(image):
    """专门针对摄像头的预处理"""
    if len(image.shape) == 3:
        gray = cv.cvtColor(image, cv.COLOR_BGR2GRAY)
    else:
        gray = image
    
    # 高斯模糊
    blurred = cv.GaussianBlur(gray, (3, 3), 0)
    
    # 直方图均衡化
    equalized = cv.equalizeHist(blurred)
    
    # 自适应阈值
    binary = cv.adaptiveThreshold(equalized, 255, 
                                 cv.ADAPTIVE_THRESH_GAUSSIAN_C, 
                                 cv.THRESH_BINARY_INV, 25, 10)
    
    return binary

def extract_best_contour(image):
    """提取最佳轮廓"""
    contours, _ = cv.findContours(image, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE)
    
    if not contours:
        return None, None
    
    # 按面积排序
    contours = sorted(contours, key=cv.contourArea, reverse=True)
    
    for contour in contours[:3]:
        x, y, w, h = cv.boundingRect(contour)
        
        if (30 < w < 300 and 30 < h < 300 and 
            w/h > 0.3 and w/h < 3.0):
            roi = image[y:y+h, x:x+w]
            return roi, (x, y, w, h)
    
    return None, None

def prepare_camera_image_for_prediction(digit_roi):
    """将摄像头图像转换为模型输入格式"""
    # 调整大小为8x8
    resized = cv.resize(digit_roi, (8, 8), interpolation=cv.INTER_AREA)
    
    # 转换为0-1范围
    normalized = resized / 255.0
    
    # 反相并缩放到0-16范围
    processed = (1 - normalized) * 16
    
    # 确保数据类型正确
    processed = processed.astype(np.float32)
    
    return processed

class StableDigitPredictor:
    """稳定的数字预测器，解决频繁输出和低置信度问题"""
    def __init__(self, stability_threshold=0.4, min_confidence=0.3, time_interval=1.0):
        self.predictions_history = []
        self.last_prediction_time = 0
        self.stability_threshold = stability_threshold
        self.min_confidence = min_confidence
        self.time_interval = time_interval  # 秒
        self.current_stable_prediction = None
        self.current_confidence = 0.0
        
    def add_prediction(self, digit, confidence, timestamp):
        """添加预测结果"""
        # 只添加置信度足够高的预测
        if confidence < self.min_confidence:
            return False
            
        self.predictions_history.append((digit, confidence, timestamp))
        
        # 只保留最近2秒内的预测
        self.predictions_history = [
            (d, c, t) for d, c, t in self.predictions_history 
            if timestamp - t < 2.0
        ]
        
        return True
        
    def get_stable_prediction(self, current_timestamp):
        """获取稳定的预测结果"""
        # 检查时间间隔
        if current_timestamp - self.last_prediction_time < self.time_interval:
            return self.current_stable_prediction, self.current_confidence
            
        if len(self.predictions_history) < 3:
            return None, 0.0
            
        # 分析历史预测
        recent_predictions = [(d, c) for d, c, t in self.predictions_history]
        digits = [d for d, c in recent_predictions]
        
        # 找到最频繁出现的数字
        digit_counts = {}
        for digit in digits:
            digit_counts[digit] = digit_counts.get(digit, 0) + 1
            
        if not digit_counts:
            return None, 0.0
            
        # 找到出现次数最多的数字
        max_count = max(digit_counts.values())
        most_common_digits = [d for d, count in digit_counts.items() if count == max_count]
        
        # 如果只有一个最频繁的数字，且出现频率足够高
        if len(most_common_digits) == 1 and max_count / len(recent_predictions) >= self.stability_threshold:
            stable_digit = most_common_digits[0]
            
            # 计算该数字的平均置信度
            confidences = [c for d, c in recent_predictions if d == stable_digit]
            avg_confidence = np.mean(confidences) if confidences else 0.0
            
            # 更新稳定预测
            self.current_stable_prediction = stable_digit
            self.current_confidence = avg_confidence
            self.last_prediction_time = current_timestamp
            
            # 清空历史，开始新的统计周期
            self.predictions_history = []
            
            return stable_digit, avg_confidence
        
        return None, 0.0

# 创建训练数据
print("创建训练数据...")
camera_images, camera_targets = create_camera_like_training_data()

# 准备训练数据
data = camera_images.reshape((len(camera_images), -1))

# 使用多个分类器
from sklearn.neighbors import KNeighborsClassifier

classifiers = {
    'RandomForest': RandomForestClassifier(n_estimators=200, random_state=42),
    'KNN': KNeighborsClassifier(n_neighbors=3),
    'SVM': svm.SVC(gamma=0.001, C=10, probability=True)
}

# 训练和评估
X_train, X_test, y_train, y_test = train_test_split(
    data, camera_targets, test_size=0.2, random_state=42
)

best_classifier = None
best_accuracy = 0

for name, clf in classifiers.items():
    clf.fit(X_train, y_train)
    y_pred = clf.predict(X_test)
    accuracy = metrics.accuracy_score(y_test, y_pred)
    print(f"{name} 准确率: {accuracy:.3f}")
    
    if accuracy > best_accuracy:
        best_accuracy = accuracy
        best_classifier = clf

print(f"\n选择最佳分类器: {best_classifier.__class__.__name__}")

# 创建稳定的预测器
predictor = StableDigitPredictor(
    stability_threshold=0.5,  # 稳定性阈值
    min_confidence=0.2,       # 最小置信度
    time_interval=1.5         # 输出间隔(秒)
)

# 摄像头实时识别
print("\n启动摄像头识别...")
print("使用说明:")
print("- 数字会保持稳定显示约1.5秒")
print("- 只有高置信度的稳定预测才会显示")
print("- 按 'q' 退出程序")

cap = cv.VideoCapture(0)

try:
    frame_count = 0
    last_display_text = "等待识别..."
    last_display_color = (255, 255, 255)
    
    while True:
        ret, frame = cap.read()
        if not ret:
            break
            
        display_frame = frame.copy()
        current_time = time.time()
        frame_count += 1
        
        # 预处理
        processed = preprocess_for_camera(frame)
        
        # 提取数字
        digit_roi, bbox = extract_best_contour(processed)
        
        if digit_roi is not None and bbox is not None:
            x, y, w, h = bbox
            
            # 绘制边界框
            cv.rectangle(display_frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
            
            # 准备预测数据
            prediction_data = prepare_camera_image_for_prediction(digit_roi)
            flattened = prediction_data.reshape(1, -1)
            
            # 预测
            try:
                predicted = best_classifier.predict(flattened)
                probabilities = best_classifier.predict_proba(flattened)
                confidence = np.max(probabilities)
                predicted_digit = predicted[0]
                
                # 添加到稳定预测器
                predictor.add_prediction(predicted_digit, confidence, current_time)
                
                # 获取稳定预测
                stable_digit, stable_confidence = predictor.get_stable_prediction(current_time)
                
                if stable_digit is not None:
                    # 更新显示文本
                    last_display_text = f"识别结果: {stable_digit} (置信度: {stable_confidence:.2f})"
                    last_display_color = (0, 255, 0) if stable_confidence > 0.6 else (0, 255, 255)
                    
                    # 控制台输出（减少频率）
                    if frame_count % 30 == 0:  # 每30帧输出一次
                        print(f"稳定预测: {stable_digit}, 置信度: {stable_confidence:.3f}")
                
                # 实时显示当前帧的预测（小字，用于调试）
                current_text = f"当前: {predicted_digit}({confidence:.2f})"
                cv.putText(display_frame, current_text, (20, 120), 
                          cv.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 0), 1)
                
            except Exception as e:
                last_display_text = "预测错误"
                last_display_color = (0, 0, 255)
        else:
            # 没有检测到数字时重置
            last_display_text = "未检测到数字"
            last_display_color = (255, 255, 255)
            predictor = StableDigitPredictor()  # 重置预测器
        
        # 显示主要结果（稳定预测）
        cv.putText(display_frame, last_display_text, (20, 40), 
                  cv.FONT_HERSHEY_SIMPLEX, 0.8, last_display_color, 2)
        
        # 显示状态信息
        status_text = f"帧: {frame_count}, 间隔: {predictor.time_interval}秒"
        cv.putText(display_frame, status_text, (20, 80), 
                  cv.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
        
        cv.putText(display_frame, "按 'q' 退出", (20, display_frame.shape[0] - 20), 
                  cv.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
        
        # 显示处理后的图像
        if digit_roi is not None:
            roi_display = cv.resize(digit_roi, (100, 100))
            roi_display = cv.cvtColor(roi_display, cv.COLOR_GRAY2BGR)
            display_frame[10:110, display_frame.shape[1]-110:display_frame.shape[1]-10] = roi_display
            
            # 显示8x8输入
            pred_display = cv.resize(prediction_data, (100, 100), interpolation=cv.INTER_NEAREST)
            pred_display = (pred_display / 16.0 * 255).astype(np.uint8)
            pred_display = cv.cvtColor(pred_display, cv.COLOR_GRAY2BGR)
            display_frame[120:220, display_frame.shape[1]-110:display_frame.shape[1]-10] = pred_display
            
            cv.putText(display_frame, "检测区域", (display_frame.shape[1]-105, 125), 
                      cv.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
            cv.putText(display_frame, "8x8输入", (display_frame.shape[1]-105, 235), 
                      cv.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
        
        cv.imshow('手写数字识别 - 稳定版', display_frame)
        
        if cv.waitKey(1) & 0xFF == ord('q'):
            break
            
except KeyboardInterrupt:
    print("用户中断")
    
finally:
    cap.release()
    cv.destroyAllWindows()
    print("程序退出")
'''
