import torch
import torch.nn as nn
import cv2
import numpy as np
import time
from PIL import Image
import json
from periphery import I2C
from IPython.display import display, clear_output
import ipywidgets as widgets
from io import BytesIO

# PCF8591地址
PCF8591_ADDR = 0x48

# 初始化I2C
i2c = I2C("/dev/i2c-7")

# 神经网络定义（与训练时相同的结构）
class Net(nn.Module):
    def __init__(self, num_classes=4):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(1, 6, 5), nn.ReLU(), nn.MaxPool2d(4),
            nn.Conv2d(6, 12, 5), nn.ReLU(), nn.MaxPool2d(4),
            nn.Flatten(),
            nn.Linear(12*3*2, 60), nn.ReLU(),
            nn.Linear(60, 30), nn.ReLU(),
            nn.Linear(30, num_classes)
        )
    
    def forward(self, x):
        return self.net(x)

# D/A转换函数
def write_dac(i2c, value):
    if not (0 <= value <= 255):
        raise ValueError("Value must be 0-255")
    msgs = [I2C.Message([0x40, value])]
    i2c.transfer(PCF8591_ADDR, msgs)

# 手势类别映射
class_names = ['Palm', 'Five', 'Left', 'Right']

def frame_to_bytes(frame, fmt='jpeg', quality=80):
    """将帧转换为字节流用于显示"""
    success, buffer = cv2.imencode(f'.{fmt}', frame, [int(cv2.IMWRITE_JPEG_QUALITY), quality])
    if success:
        return buffer.tobytes()
    return None

def main():
    # 设备设置
    DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'
    
    # 加载模型
    model = Net(num_classes=4).to(DEVICE)
    try:
        model.load_state_dict(torch.load('runs/model.pth', map_location=DEVICE))
        print("模型加载成功")
    except Exception as e:
        print(f"模型加载失败: {e}")
        print("请确保模型文件 'runs/model.pth' 存在")
        return
    
    model.eval()
    
    # 加载类别映射
    try:
        with open('runs/classes.json', 'r', encoding='utf-8') as f:
            class_to_idx = json.load(f)
        # 反转字典，从索引到类别名
        idx_to_class = {v: k for k, v in class_to_idx.items()}
        print("类别映射加载成功")
    except:
        print("类别映射加载失败，使用默认映射")
        idx_to_class = {0: 'Palm', 1: 'Five', 2: 'Left', 3: 'Right'}
    
    # 打开摄像头
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("无法打开摄像头")
        return
    
    # 创建显示控件
    image_widget = widgets.Image(format='jpeg', width=640, height=480)
    status_label = widgets.HTML(value="<b>状态: 准备开始...</b>")
    control_label = widgets.HTML(
        value="<h3>手势控制说明:</h3>"
              "<ul>"
              "<li><b>Palm(手掌)</b>: LED开启</li>"
              "<li><b>Five(五指)</b>: LED关闭</li>" 
              "<li><b>Left(向左)</b>: LED调亮</li>"
              "<li><b>Right(向右)</b>: LED调暗</li>"
              "</ul>"
    )
    stop_button = widgets.Button(description="停止识别", button_style='danger')
    
    # 显示所有控件
    display(widgets.VBox([control_label, image_widget, status_label, stop_button]))
    
    print("手势识别系统启动成功！")
    
    current_brightness = 0
    last_gesture = None
    is_running = True
    
    def stop_recognition(b):
        nonlocal is_running
        is_running = False
        status_label.value = "<b style='color:red'>状态: 正在停止...</b>"
    
    stop_button.on_click(stop_recognition)
    
    try:
        while is_running:
            ret, frame = cap.read()
            if not ret:
                status_label.value = "<b style='color:red'>状态: 无法获取视频帧</b>"
                break
            
            # 图像预处理（与训练时相同）
            hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            
            # 肤色分割
            mask = cv2.inRange(hsv, np.array([0, 0, 0]), np.array([50, 200, 160]))
            output = cv2.bitwise_and(gray, gray, mask=mask)
            
            # 调整大小和模糊
            output = cv2.resize(output, (80, 60))
            output = cv2.blur(output, (2, 2))
            
            # 转换为Tensor
            img_tensor = torch.from_numpy(output).float().unsqueeze(0).unsqueeze(0) / 255.0
            img_tensor = img_tensor.to(DEVICE)
            
            # 神经网络推理
            with torch.no_grad():
                logits = model(img_tensor)
                probs = torch.softmax(logits, dim=1)
                conf, pred = torch.max(probs, dim=1)
            
            gesture_idx = pred.item()
            confidence = conf.item()
            gesture_name = idx_to_class.get(gesture_idx, f"Class_{gesture_idx}")
            
            # 在帧上添加识别信息
            display_frame = cv2.resize(frame, (640, 480))
            cv2.putText(display_frame, f"Gesture: {gesture_name}", (10, 30), 
                        cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
            cv2.putText(display_frame, f"Confidence: {confidence:.3f}", (10, 70), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
            cv2.putText(display_frame, f"Brightness: {current_brightness}/255", (10, 110), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
            
            # 更新图像显示
            frame_bytes = frame_to_bytes(display_frame)
            if frame_bytes:
                image_widget.value = frame_bytes
            
            # 只在置信度足够高时执行控制
            if confidence > 0.7:
                if gesture_name != last_gesture:  # 避免重复执行相同手势
                    status_text = f"<b style='color:green'>状态: 检测到 {gesture_name} (置信度: {confidence:.3f})</b>"
                    status_label.value = status_text
                    if gesture_name == 'Palm':  # 开启LED
                        current_brightness = 255
                        write_dac(i2c, current_brightness)
                        print("LED已开启")
                        
                    elif gesture_name == 'Five':  # 关闭LED
                        current_brightness = 0
                        write_dac(i2c, current_brightness)
                        print("LED已关闭")
                        
                    elif gesture_name == 'Left':  # 调亮
                        '''if current_brightness < 255:
                            current_brightness = min(255, current_brightness + 51)  # 每次增加20%
                            write_dac(i2c, current_brightness)
                            print(f"LED调亮至: {current_brightness}/255")'''
                        for i in range(255):
                            write_dac(i2c,i)
                        
                    elif gesture_name == 'Right':  # 调暗
                        '''if current_brightness > 0:
                            current_brightness = max(0, current_brightness - 51)  # 每次减少20%
                            write_dac(i2c, current_brightness)
                            print(f"LED调暗至: {current_brightness}/255")'''
                        for j in range(255):
                            write_dac(i2c,255-j)
                    
                    last_gesture = gesture_name
            else:
                status_label.value = f"<b>状态: 检测中... (当前: {gesture_name}, 置信度: {confidence:.3f})</b>"
            
            time.sleep(0.5)  
            
    except Exception as e:
        status_label.value = f"<b style='color:red'>状态: 发生错误 - {e}</b>"
        print(f"发生错误: {e}")
    finally:
        cap.release()
        write_dac(i2c, 0)  # 关闭LED
        status_label.value = "<b style='color:blue'>状态: 已停止，LED已关闭</b>"
        print("LED已关闭，程序结束")
if __name__ == "__main__":
    main()
























import time
from periphery import I2C
address=0x48
i2c=I2C("/dev/i2c-7")
def read_adc(i2c,channel=0):
    if channel<0 or channel>3:
        raise ValueError("Channel must be 0-3")
    control=0x40|channel
    msgs=[I2C.Message([control])]
    i2c.transfer(address,msgs)
    msgs=[I2C.Message([0x00],read=True)]
    adc_value=msgs[0].data[0]
    return adc_value
def write_dac(i2c,value):
    if not (0<=value<=255):
        raise ValueError("Value must be 0-255")
    msgs=[I2C.Message([0x40,value])]
    i2c.transfer(address,msgs)
    '''
try:
    while True:
        adc_value=read_adc(i2c)
        print(adc_value)
        time.sleep(0.5)
except KeyboardInterrupt:
    pass
    
'''
try:
    while True:
        try:
            
            options = int(input("请输入数字：1表示开，2表示关，3表示调亮，4表示调暗: "))
            if options == 1:
                write_dac(i2c,255)
                print("LED turned ON")
                
            elif options == 2:
                write_dac(i2c,0)
                print("LED turned OFF")
                
                
            elif options == 3:
                print("Gradually brightening LED...")
                for i in range(256):
                    write_dac(i2c,i)
                    time.sleep(0.01)
                print("LED at maximum brightness")
                
            elif options == 4:
                print("Gradually dimming LED...")
                for i in range(256):
                    write_dac(i2c,255 - i)
                    time.sleep(0.01)
                print("LED turned OFF")
            
                
            else:
                print("无效输入，请输入1-4之间的数字")
                
            time.sleep(0.5)
            
        except ValueError:
            print("请输入有效的数字！")
        except Exception as e:
            print(f"发生错误: {e}")
finally:
    write_dac(i2c,0)




















import numpy as np
import cv2
from ais_bench.infer.interface import InferSession
from scipy.special import softmax
import json
OM_PATH="model.om"
IMG_PATH="palm.jpg"
INPUT_HW=(60,80)
with open("classes.json","r",encoding="utf-8") as f:
    class_to_idx=json.load(f)
class_names=[None]*len(class_to_idx)
for name,idx in class_to_idx.items():
    class_names[idx]=name
sess=InferSession(device_id=0,model_path=OM_PATH)
img=cv2.imread(IMG_PATH,cv2.IMREAD_GRAYSCALE)
img=cv2.resize(img,(INPUT_HW[1],INPUT_HW[0]))
img=img.astype(np.float32)/255.0
img=img[np.newaxis,np.newaxis,...]
outs=sess.infer([img])
prob=softmax(outs[0].squeeze())
pred=int(prob.argmax())
conf=float(prob[pred])
print(f"预测类别:{class_names[pred]}")
print(f"置信度:{conf:.4f}")




import torch
import torch.nn as nn
class Net(nn.Module):
    def __init__(self, num_classes=4):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(1, 6, 5), 
            nn.ReLU(),
            nn.MaxPool2d(4),
            nn.Conv2d(6, 12, 5), 
            nn.ReLU(),
            nn.MaxPool2d(4),
            nn.Flatten(),
            nn.Linear(12 * 3 * 2, 60),  
            nn.ReLU(),
            nn.Linear(60, 30),
            nn.ReLU(),
            nn.Linear(30, num_classes) 
        )
    
    def forward(self, x):
        return self.net(x)
PTH_PATH="runs/model.pth"
ONNX_PATH="runs/model.onnx"
INPUT_SHAPE=(1,1,60,80)
device="cpu"
model=Net(num_classes=4).to(device)
model.load_state_dict(torch.load(PTH_PATH,map_location=device))
model.eval()
dummy=torch.randn(INPUT_SHAPE)
torch.onnx.export(model,dummy,ONNX_PATH,
                  opset_version=11,
                  do_constant_folding=True,
                  input_names=["input"],output_names=["output"],
                  dynamic_axes={"input":{0:"batch"},"output":{0:"batch"}})








'''import torch
import torch.nn as nn
class Net(nn.Module):
    def __init__(self, num_classes=4):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(1, 6, 5), 
            nn.ReLU(),
            nn.MaxPool2d(4),
            nn.Conv2d(6, 12, 5), 
            nn.ReLU(),
            nn.MaxPool2d(4),
            nn.Flatten(),
            nn.Linear(12 * 3 * 2, 60),  
            nn.ReLU(),
            nn.Linear(60, 30),
            nn.ReLU(),
            nn.Linear(30, num_classes) 
        )
    
    def forward(self, x):
        return self.net(x)
PTH_PATH="runs/model.pth"
ONNX_PATH="runs/model.onnx"
INPUT_SHAPE=(1,1,60,80)
device="cpu"
model=Net(num_classes=4).to(device)
model.load_state_dict(torch.load(PTH_PATH,map_location=device))
model.eval()
dummy=torch.randn(INPUT_SHAPE)
torch.onnx.export(model,dummy,ONNX_PATH,
                  opset_version=11,
                  do_constant_folding=True,
                  input_names=["input"],output_names=["output"],
                  dynamic_axes={"input":{0:"batch"},"output":{0:"batch"}})
'''
