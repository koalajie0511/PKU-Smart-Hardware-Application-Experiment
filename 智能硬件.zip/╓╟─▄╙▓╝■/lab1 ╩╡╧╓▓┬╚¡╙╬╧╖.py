from periphery import GPIO
import random
buttons=[GPIO(82,"in"),GPIO(38,"in"),GPIO(79,"in")] #设置各个按钮的信息，分别表示剪刀，石头和布
buttons[0].edge="falling"
buttons[1].edge="falling"
buttons[2].edge="falling"
gpio=GPIO(3,"out")
pinnum=[1,1,1] #记录用户按下各个按键的数目，初始化为1
probability=[1/3,2/3]
scores={"player":0,"computer":0,"tie":0} #记录成绩
win={82:79,38:82,79:38} #记录获胜情况，键赢值
tot=3 #总计按下的按键数目
def judgewin():
    if pin==machine:
        scores["tie"]+=1
        return 0 #0表示平局
    elif machine==win[pin]:
        scores["player"]+=1 #玩家获胜
        return 1
    else:
        scores["computer"]+=1 #系统获胜
        return 2
def prob(): #调整列表probability中的数值大小
    probability[0]=pindict[0]/tot
    probability[1]=(pindict[0]+pindict[1])/tot
def generate_machine(): #生成参数machine
    #概率函数生成算法：假设pindict记录的玩家按键数目分别为a,b,c,则probability各参数为a/(a+b+c),(a+b)/(a+b+c)
    temp=random.random() #生成一个(0,1)之间的随机数
    if temp<probability[0]:
        return 38 #表示预判玩家出剪刀，试图出石头
    elif temp<probability[1]:
        return 79 #表示预判玩家出石头，试图出布
    else:
        return 82
try:
    while True:
        machine=generate_machine()
        events=GPIO.poll_multiple(buttons,timeout=1.0) #同时监控多个按键
        if not events:
            continue
        for gpio in events:
            pin=gpio.line #给出被按下的按钮编号
            gpio.write(True)
            if pin==82:
                pinnum[0]+=1
            elif pin==38:
                pinnum[1]+=1
            else:
                pinnum[2]+=1
            tot+=1
            prob()
            gpio.read()
        state=judgewin()
        gpio.write(False)
        if state==0:
            print("Tie!")
        elif state==1:
            print("Player Wins!")
        else:
            print("Computer Wins!")
        print("-----Total Scores-----")
        print ("player:{} computer:{} tie:{}".format(scores["player"],scores["computer"],scores["tie"]))
        time.sleep(0.5)
except KeyboardInterrupt:
    print("\n program stopped by user!")
finally:
    gpio.write(False)
    gpio.close()
    for button in buttons:
        button.close()
