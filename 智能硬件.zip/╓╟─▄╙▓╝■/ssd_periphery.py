from periphery import SPI, GPIO
import time

# === SSD1306 command constants ===
SSD1306_SETCONTRAST = 0x81
SSD1306_DISPLAYALLON_RESUME = 0xA4
SSD1306_DISPLAYALLON = 0xA5
SSD1306_NORMALDISPLAY = 0xA6
SSD1306_INVERTDISPLAY = 0xA7
SSD1306_DISPLAYOFF = 0xAE
SSD1306_DISPLAYON = 0xAF
SSD1306_SETDISPLAYOFFSET = 0xD3
SSD1306_SETCOMPINS = 0xDA
SSD1306_SETVCOMDETECT = 0xDB
SSD1306_SETDISPLAYCLOCKDIV = 0xD5
SSD1306_SETPRECHARGE = 0xD9
SSD1306_SETMULTIPLEX = 0xA8
SSD1306_SETSTARTLINE = 0x40
SSD1306_MEMORYMODE = 0x20
SSD1306_COLUMNADDR = 0x21
SSD1306_PAGEADDR = 0x22
SSD1306_COMSCANINC = 0xC0
SSD1306_COMSCANDEC = 0xC8
SSD1306_SEGREMAP = 0xA0
SSD1306_CHARGEPUMP = 0x8D
SSD1306_EXTERNALVCC = 0x1
SSD1306_SWITCHCAPVCC = 0x2


class SSD1306:
    """SSD1306 OLED driver using python-periphery (SPI + GPIO)."""

    def __init__(self, rst, dc, spi_dev="/dev/spidev0.0", vccstate=SSD1306_SWITCHCAPVCC):
        self.width = 128
        self.height = 64
        self._pages = self.height // 8
        self._buffer = [0x00] * (self.width * self._pages)
        self._vccstate = vccstate

        # Initialize GPIOs
        self._rst = GPIO(rst, "out")
        self._dc = GPIO(dc, "out")

        # Initialize SPI
        self._spi = SPI(spi_dev, 0, 1000000)  # 1 MHz safe default
        self._spi.mode = 0
        self._spi.bit_order = "msb"
        self._spi.bits_per_word = 8

    # === Low-level helpers ===
    def command(self, cmd):
        self._dc.write(False)
        self._spi.transfer([cmd])

    def data(self, val):
        if isinstance(val, int):
            val = [val]
        self._dc.write(True)
        self._spi.transfer(val)

    # === High-level methods ===
    def reset(self):
        """Reset the OLED controller."""
        self._rst.write(True)
        time.sleep(0.001)
        self._rst.write(False)
        time.sleep(0.01)
        self._rst.write(True)
        time.sleep(0.05)

    def begin(self):
        """Initialize the display hardware."""
        self.reset()

        self.command(SSD1306_DISPLAYOFF)
        self.command(SSD1306_SETDISPLAYCLOCKDIV)
        self.command(0x80)

        self.command(SSD1306_SETMULTIPLEX)
        self.command(0x3F)

        self.command(SSD1306_SETDISPLAYOFFSET)
        self.command(0x00)

        self.command(SSD1306_SETSTARTLINE | 0x00)

        self.command(SSD1306_CHARGEPUMP)
        if self._vccstate == SSD1306_EXTERNALVCC:
            self.command(0x10)
        else:
            self.command(0x14)

        self.command(SSD1306_MEMORYMODE)
        self.command(0x00)

        self.command(SSD1306_SEGREMAP | 0x1)
        self.command(SSD1306_COMSCANDEC)

        self.command(SSD1306_SETCOMPINS)
        self.command(0x12)

        self.command(SSD1306_SETCONTRAST)
        if self._vccstate == SSD1306_EXTERNALVCC:
            self.command(0x9F)
        else:
            self.command(0xCF)

        self.command(SSD1306_SETPRECHARGE)
        if self._vccstate == SSD1306_EXTERNALVCC:
            self.command(0x22)
        else:
            self.command(0xF1)

        self.command(SSD1306_SETVCOMDETECT)
        self.command(0x40)

        self.command(SSD1306_DISPLAYALLON_RESUME)
        self.command(SSD1306_NORMALDISPLAY)
        self.command(SSD1306_DISPLAYON)

    def clear(self):
        """Clear display buffer."""
        self._buffer = [0x00] * (self.width * self._pages)

    def image(self, image):
        """Copy a PIL image into the internal buffer."""
        if image.mode != "1":
            raise ValueError("Image must be in mode '1' (1-bit pixels).")
        if image.size != (self.width, self.height):
            raise ValueError(f"Image must be {self.width}x{self.height}")

        pix = image.load()
        idx = 0
        for page in range(self._pages):
            for x in range(self.width):
                bits = 0
                for bit in range(8):
                    y = page * 8 + bit
                    if pix[x, y]:
                        bits |= (1 << bit)
                self._buffer[idx] = bits
                idx += 1

    def display(self):
        """Flush the internal buffer to the OLED display."""
        self.command(SSD1306_COLUMNADDR)
        self.command(0)
        self.command(self.width - 1)

        self.command(SSD1306_PAGEADDR)
        self.command(0)
        self.command(self._pages - 1)

        self.data(self._buffer)

    def set_contrast(self, contrast):
        """Set display contrast (0–255)."""
        if not 0 <= contrast <= 255:
            raise ValueError("Contrast must be between 0–255.")
        self.command(SSD1306_SETCONTRAST)
        self.command(contrast)

    def dim(self, dim_on):
        """Dim or undim display."""
        contrast = 0x00 if dim_on else (0x9F if self._vccstate == SSD1306_EXTERNALVCC else 0xCF)
        self.set_contrast(contrast)

    def close(self):
        """Release GPIO and SPI."""
        self._spi.close()
        self._rst.close()
        self._dc.close()
