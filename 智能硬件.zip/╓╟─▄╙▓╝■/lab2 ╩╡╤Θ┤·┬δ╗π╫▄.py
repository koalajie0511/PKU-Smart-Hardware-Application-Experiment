import time
import matplotlib.pyplot as plt
from bmp280 import BMP280
sensor=BMP280("/dev/i2c-7",0x76)
duration=60
interval=1
timestamps=[]
temperatures=[]
try:
    start_time=time.time()
    end_time=start_time+duration
    while time.time()<end_time:
        temp=sensor.get_temperature()
        current_time=time.time()-start_time
        timestamps.append(current_time)
        temperatures.append(temp)
        print(f"时间：{current_time:.1f}s,温度：{temp:.2f}摄氏度")
        time.sleep(interval-(time.time()%interval))
except KeyboardInterrupt:
    print("用户中断记录")
finally:
    sensor.close()
plt.figure(figsize=(10,6))
plt.plot(timestamps,temperatures,"b-",marker="o",markersize=3)
plt.title("Temperature Change")
plt.xlabel("Time(s)")
plt.ylabel("Temperature")









import matplotlib.pyplot as plt
import numpy as np
r1=2
r2=4
p1=[]
p2=[]
for i in range(100000):
    x=np.random.rand()*r2*2-r2
    y=np.random.rand()*r2*2-r2
    if abs(x*x+y*y-r1)<0.5:
        p1.append([x,y])
    if abs(x*x+y*y-r2)<0.5:
        p2.append([x,y])
plt.scatter(np.array(p1)[:,0],np.array(p1)[:,1],c="r",s=3)
plt.scatter(np.array(p2)[:,0],np.array(p2)[:,1],c="b",s=3)
plt.show()








import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rcParams
from bmp280 import BMP280
sensor=BMP280("/dev/i2c-7",0x76)
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'DejaVu Sans'] 
plt.rcParams['axes.unicode_minus'] = False  
mean1 = 23
sigma1 = 2
x = mean1 + sigma1 * np.random.randn(360)
mean2 = 28
sigma2 = 1
y = mean2 + sigma2 * np.random.randn(360)
D = np.concatenate([x, y]) 
k = 2
centers = np.random.choice(D, size=k, replace=False)
new_centers = centers.copy()  
max_iter = 100  
for iter in range(max_iter):
    dist = np.zeros((D.shape[0], k))
    for j in range(k):
        dist[:, j] = np.abs(D - centers[j])
    clusters = np.argmin(dist, axis=1)
    new_centers = np.array([np.mean(D[clusters == j]) for j in range(k)])
    if np.allclose(centers, new_centers, atol=0.01):
        break 
    centers = new_centers
for i in range(k):
    print(f"第{i+1}个人的喜好温度: {centers[i]:.2f}°C")
cluster_counts = np.bincount(clusters)
t1 = float(cluster_counts[0] / 2)  
t2 = float(cluster_counts[1] / 2)  
print(f"第1个人的使用时间：{t1}小时")
print(f"第2个人的使用时间：{t2}小时")

temp = sensor.get_temperature()
print(temp)
if temp < np.mean(x):
    print("1")
else:
    print("2")
plt.figure(figsize=(10, 6))
plt.hist(x, 80, histtype='bar', facecolor='blue', alpha=0.75, label='用户1')
plt.hist(y, 80, histtype='bar', facecolor='green', alpha=0.75, label='用户2')
plt.xlabel('Temp')
plt.ylabel('Frequency')
plt.title('Preference')
plt.legend()
plt.show()














import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rcParams

plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'DejaVu Sans'] 
plt.rcParams['axes.unicode_minus'] = False  
from bmp280 import BMP280
sensor = BMP280("/dev/i2c-7", 0x76)

mean1 = 23
sigma1 = 2
x = mean1 + sigma1 * np.random.randn(360)
mean2 = 28
sigma2 = 1
y = mean2 + sigma2 * np.random.randn(360)

# 合并数据并进行聚类分析
D = np.concatenate([x, y]) 
k = 2
centers = np.random.choice(D, size=k, replace=False)
new_centers = centers.copy()  
max_iter = 100  
for iter in range(max_iter):
    dist = np.zeros((D.shape[0], k))
    for j in range(k):
        dist[:, j] = np.abs(D - centers[j])
    
    clusters = np.argmin(dist, axis=1)
    new_centers = np.array([np.mean(D[clusters == j]) for j in range(k)])
    
    if np.allclose(centers, new_centers, atol=0.01):
        break 
    centers = new_centers
print("聚类结果分析:")
for i in range(k):
    print(f"第{i+1}个人的喜好温度: {centers[i]:.2f}°C")
cluster_counts = np.bincount(clusters)
t1 = float(cluster_counts[0] / 6)  
t2 = float(cluster_counts[1] / 6)  
print(f"第1个人的使用时间：{t1:.1f}小时")
print(f"第2个人的使用时间：{t2:.1f}小时")
temp = sensor.get_temperature()  
print(f"\n当前温度: {temp:.2f}°C")
if temp < np.mean([centers[0], centers[1]]):
    current_user = 1 if centers[0] < centers[1] else 2
    print(f"当前用户: 用户{current_user}")
else:
    current_user = 2 if centers[0] < centers[1] else 1
    print(f"当前用户: 用户{current_user}")
plt.figure(figsize=(12, 8))
plt.subplot(2, 1, 1)
plt.hist(x, 40, histtype='bar', facecolor='blue', alpha=0.7, label='用户1温度偏好')
plt.hist(y, 40, histtype='bar', facecolor='green', alpha=0.7, label='用户2温度偏好')
for i, center in enumerate(centers):
    plt.axvline(center, color='red' if i == 0 else 'orange', linestyle='--', 
                linewidth=2, label=f'用户{i+1}偏好温度: {center:.1f}°C')
plt.xlabel('Temperature')
plt.ylabel('Frequency')
plt.title('Preference Distribution')
plt.legend()
plt.grid(True, alpha=0.3)
plt.subplot(2, 1, 2)
labels = [f'用户1: {t1:.1f}小时', f'用户2: {t2:.1f}小时']
sizes = [t1, t2]
colors = ['lightblue', 'lightgreen']
plt.pie(sizes, labels=labels, colors=colors, autopct='%1.1f%%', startangle=90)
plt.axis('equal')
plt.title('Time distribution')
plt.tight_layout()
plt.show()
sensor.close()





















import time
import matplotlib.pyplot as plt
from bmp280 import BMP280
sensor=BMP280("/dev/i2c-7",0x76)
duration=60
interval=1
timestamps=[]
atmos=[]
try:
    start_time=time.time()
    end_time=start_time+duration
    while time.time()<end_time:
        pressure=sensor.get_pressure()
        current_time=time.time()-start_time
        timestamps.append(current_time)
        atmos.append(pressure)
        print(current_time,pressure)
        time.sleep(interval-(time.time()%interval))
except KeyboardInterrupt:
    print("用户中断记录")
finally:
    sensor.close()
plt.figure(figsize=(10,6))
plt.plot(timestamps,atmos,"b-",marker="o",markersize=3)
plt.title("Pressure Change")
plt.xlabel("Time(s)")
plt.ylabel("Pressure")

















import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rcParams
from bmp280 import BMP280
from scipy.spatial import distance
import matplotlib.cm as cm
import time
plt.rcParams['font.sans-serif'] = ['WenQuanYi Micro Hei', 'SimHei', 'Microsoft YaHei', 'DejaVu Sans'] 
plt.rcParams['axes.unicode_minus'] = False  
sensor = BMP280("/dev/i2c-7", 0x76)
class TwoDUserRecognizer:
    def __init__(self, n_users=2):
        self.n_users = n_users
        self.centers = None
        self.user_profiles = []    
    def generate_simulated_data(self):
        temp1 = 23 + 2 * np.random.randn(180)  
        pressure1 = 1003 + 5 * np.random.randn(180)  
        temp2 = 26 + 1.5 * np.random.randn(180)
        pressure2 = 1015 + 8 * np.random.randn(180)
        user1_data = np.column_stack((temp1, pressure1))
        user2_data = np.column_stack((temp2, pressure2))
        return user1_data, user2_data
    def kmeans_2d(self, data, max_iter=100):
        n_points = data.shape[0]
        centers = data[np.random.choice(n_points, self.n_users, replace=False)]
        for iteration in range(max_iter):
            distances = np.zeros((n_points, self.n_users))
            for i in range(self.n_users):
                temp_normalized = (data[:, 0] - np.mean(data[:, 0])) / np.std(data[:, 0])
                pressure_normalized = (data[:, 1] - np.mean(data[:, 1])) / np.std(data[:, 1])
                center_temp_normalized = (centers[i, 0] - np.mean(data[:, 0])) / np.std(data[:, 0])
                center_pressure_normalized = (centers[i, 1] - np.mean(data[:, 1])) / np.std(data[:, 1])
                distances[:, i] = np.sqrt(
                    (temp_normalized - center_temp_normalized)**2 + 
                    (pressure_normalized - center_pressure_normalized)**2
                )
            labels = np.argmin(distances, axis=1)
            new_centers = np.array([data[labels == i].mean(axis=0) for i in range(self.n_users)])
            if np.allclose(centers, new_centers, atol=0.01):
                break  
            centers = new_centers
        return centers, labels
    def train(self):
        user1_data, user2_data = self.generate_simulated_data()
        all_data = np.vstack([user1_data, user2_data])
        true_labels = np.array([0]*len(user1_data) + [1]*len(user2_data))
        self.centers, cluster_labels = self.kmeans_2d(all_data)
        self.analyze_clusters(all_data, cluster_labels, true_labels)
        return all_data, cluster_labels, true_labels
    def analyze_clusters(self, data, cluster_labels, true_labels):
        self.user_profiles = []
        for i in range(self.n_users):
            cluster_data = data[cluster_labels == i]
            cluster_true_labels = true_labels[cluster_labels == i]
            if len(cluster_data) == 0:
                continue
            temp_mean = np.mean(cluster_data[:, 0])
            temp_std = np.std(cluster_data[:, 0])
            pressure_mean = np.mean(cluster_data[:, 1])
            pressure_std = np.std(cluster_data[:, 1])
            if len(cluster_true_labels) > 0:
                main_user = np.bincount(cluster_true_labels).argmax()
                user_ratio = np.sum(cluster_true_labels == main_user) / len(cluster_true_labels)
            else:
                main_user = i
                user_ratio = 1.0
            profile = {
                'temp_mean': temp_mean,
                'temp_std': temp_std,
                'pressure_mean': pressure_mean,
                'pressure_std': pressure_std,
                'main_user': main_user,
                'user_ratio': user_ratio
            }
            self.user_profiles.append(profile)
    def recognize_user(self, current_temp, current_pressure):
        current_point = np.array([current_temp, current_pressure])
        temp_normalized = (current_temp - np.mean([center[0] for center in self.centers])) / np.std([center[0] for center in self.centers])
        pressure_normalized = (current_pressure - np.mean([center[1] for center in self.centers])) / np.std([center[1] for center in self.centers])
        distances = []
        for center in self.centers:
            center_temp_normalized = (center[0] - np.mean([c[0] for c in self.centers])) / np.std([c[0] for c in self.centers])
            center_pressure_normalized = (center[1] - np.mean([c[1] for c in self.centers])) / np.std([c[1] for c in self.centers])
            dist = np.sqrt(
                (temp_normalized - center_temp_normalized)**2 + 
                (pressure_normalized - center_pressure_normalized)**2
            )
            distances.append(dist)    
        closest_cluster = np.argmin(distances)
        profile = self.user_profiles[closest_cluster]
        recognized_user = profile['main_user'] + 1
        min_dist = distances[closest_cluster]
        max_dist = max(distances)
        confidence = max(0, 1.0 - (min_dist / (max_dist + 0.001)))  
        return recognized_user, confidence, min_dist
    def visualize_results(self, data, labels, true_labels, current_reading=None):
        fig = plt.figure(figsize=(15, 10))
        plt.subplot(2, 2, 1)
        colors = ['blue', 'green']
        for i in range(self.n_users):
            cluster_data = data[labels == i]
            if len(cluster_data) > 0:
                plt.scatter(cluster_data[:, 0], cluster_data[:, 1], 
                           c=colors[i], alpha=0.6, label=f'Cluster {i+1}', s=30)
        for i, center in enumerate(self.centers):
            plt.scatter(center[0], center[1], c='red', marker='X', s=200, 
                       label=f'Center {i+1}', edgecolors='black')
        if current_reading is not None:
            plt.scatter(current_reading[0], current_reading[1], c='orange', 
                       marker='*', s=300, label='Current Reading', edgecolors='black')
        plt.xlabel('Temperature (°C)')
        plt.ylabel('Pressure (hPa)')
        plt.title('2D Clustering Results')
        plt.legend()
        plt.grid(True, alpha=0.3)
        plt.subplot(2, 2, 2)
        for i in range(self.n_users):
            cluster_data = data[labels == i]
            if len(cluster_data) > 0:
                plt.hist(cluster_data[:, 0], alpha=0.6, label=f'Cluster {i+1}', 
                        bins=20, color=colors[i])
        plt.xlabel('Temperature (°C)')
        plt.ylabel('Frequency')
        plt.title('Temperature Distribution')
        plt.legend()
        plt.grid(True, alpha=0.3)
        plt.subplot(2, 2, 3)
        for i in range(self.n_users):
            cluster_data = data[labels == i]
            if len(cluster_data) > 0:
                plt.hist(cluster_data[:, 1], alpha=0.6, label=f'Cluster {i+1}', 
                        bins=20, color=colors[i])
        plt.xlabel('Pressure (hPa)')
        plt.ylabel('Frequency')
        plt.title('Pressure Distribution')
        plt.legend()
        plt.grid(True, alpha=0.3)
        plt.subplot(2, 2, 4)
        usage_hours = []
        for i in range(self.n_users):
            if len(data[labels == i]) > 0:
                usage_hours.append(np.sum(labels == i) / 30)
            else:
                usage_hours.append(0)
        plt.bar(range(1, self.n_users+1), usage_hours, color=colors, alpha=0.7)
        plt.xlabel('User')
        plt.ylabel('Usage Time (hours)')
        plt.title('User Usage Time Distribution')
        plt.xticks(range(1, self.n_users+1), [f'User {i+1}' for i in range(self.n_users)])
        plt.tight_layout()
        plt.show()

def main():
    recognizer = TwoDUserRecognizer(n_users=2)
    data, cluster_labels, true_labels = recognizer.train()
    
    try:
        current_temp = sensor.get_temperature()
        current_pressure_pa = sensor.get_pressure()  
        user, confidence, distance = recognizer.recognize_user(current_temp, current_pressure_pa)
        print(f"\n=== 识别结果 ===")
        print(f"当前用户: 用户{user}")
        print(f"置信度: {confidence:.2%}")
        print(f"与聚类中心距离: {distance:.2f}")
        current_reading = np.array([current_temp, current_pressure_pa])
        recognizer.visualize_results(data, cluster_labels, true_labels, current_reading)
    finally:
        sensor.close()
if __name__ == "__main__":
    try:
        temp = sensor.get_temperature()
        pressure = sensor.get_pressure()
        print(f"传感器测试 - 温度: {temp:.2f}°C, 气压: {pressure:.2f} Pa")
    except Exception as e:
        print(f"传感器测试失败: {e}")
    main()
