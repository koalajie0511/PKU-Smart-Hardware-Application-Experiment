# 此代码用于训练及测试神经网络
# 需要在此代码所在的目录下存放一个数据集文件夹
# 数据集文件夹包含"train"、"test"两个子文件夹
# 两个子文件夹下均有四个以手势类型命名的文件夹，存放着样本
# 训练部分使用小批量梯度下降、Adam优化器
# 最后绘制出损失和准确率的变化曲线、混淆矩阵

import os, time, torch, torch.nn as nn, torch.optim as optim
import torchvision.datasets as datasets, torchvision.transforms as T
from torch.utils.data import DataLoader
from tqdm.auto import tqdm
import numpy as np, matplotlib.pyplot as plt
import json

# --- 参数 ---
DATA_DIR = 'dataset'    # 数据集根目录
RUN_DIR = 'runs'    # 结果保存目录
EPOCHS = 10    # 训练轮数
BATCH_SIZE = 32    # 批大小
LR = 1e-3    # Adam 学习率
DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'
os.makedirs(RUN_DIR, exist_ok=True)

# --- 数据 ---
transform = T.Compose([T.Grayscale(), T.ToTensor()])
train_ds = datasets.ImageFolder(f'{DATA_DIR}/train', transform)
test_ds = datasets.ImageFolder(f'{DATA_DIR}/test', transform)
train_dl = DataLoader(train_ds, BATCH_SIZE, shuffle=True)
test_dl = DataLoader(test_ds, BATCH_SIZE, shuffle=False)

# --- 模型 ---
class Net(nn.Module):
    def __init__(self):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(1, 6, 5), nn.ReLU(), nn.MaxPool2d(4),
            nn.Conv2d(6, 12, 5), nn.ReLU(), nn.MaxPool2d(4),
            nn.Flatten(),
            nn.Linear(12*3*2, 60), nn.ReLU(),
            nn.Linear(60, 30), nn.ReLU(),
            nn.Linear(30, len(train_ds.classes))
        )
    
    def forward(self, x):
        return self.net(x)

model = Net().to(DEVICE)
opt = optim.Adam(model.parameters(), lr=LR)
loss_fn = nn.CrossEntropyLoss()

# --- 训练 & 记录 ---
train_losses, val_losses = [], []
train_accs, val_accs = [], []

for epoch in range(EPOCHS):
    model.train()
    running_loss, correct, total = 0.0, 0, 0
    
    for x, y in tqdm(train_dl, desc=f'Epoch {epoch+1}/{EPOCHS}'):
        x, y = x.to(DEVICE), y.to(DEVICE)
        opt.zero_grad()
        logits = model(x)
        loss = loss_fn(logits, y)
        loss.backward()
        opt.step()
        
        running_loss += loss.item() * x.size(0)
        correct += (logits.argmax(1) == y).sum().item()
        total += x.size(0)
    
    train_losses.append(running_loss / total)
    train_accs.append(correct / total)
    
    # 验证
    model.eval()
    running_loss, correct, total = 0.0, 0, 0
    with torch.no_grad():
        for x, y in test_dl:
            x, y = x.to(DEVICE), y.to(DEVICE)
            logits = model(x)
            running_loss += loss_fn(logits, y).item() * x.size(0)
            correct += (logits.argmax(1) == y).sum().item()
            total += x.size(0)
    
    val_losses.append(running_loss / total)
    val_accs.append(correct / total)

# --- 可视化: 过拟合曲线 ---
plt.figure(figsize=(6,3))
plt.subplot(1,2,1)
plt.plot(train_losses, label='train')
plt.plot(val_losses, label='val')
plt.title('Loss'); plt.ylabel('CE'); plt.legend()

plt.subplot(1,2,2)
plt.plot(train_accs, label='train')
plt.plot(val_accs, label='val')
plt.title('Accuracy'); plt.ylabel('acc'); plt.legend()
plt.tight_layout(); plt.show()

# --- 混淆矩阵 ---
model.eval()
all_preds, all_labels = [], []
with torch.no_grad():
    for x, y in test_dl:
        preds = model(x.to(DEVICE)).argmax(1).cpu()
        all_preds.append(preds)
        all_labels.append(y)

all_preds = torch.cat(all_preds)
all_labels = torch.cat(all_labels)

num_classes = len(test_ds.classes)
cm = np.zeros((num_classes, num_classes), dtype=int)
for t, p in zip(all_labels.numpy(), all_preds.numpy()):
    cm[t, p] += 1

plt.figure(figsize=(4,4))
plt.imshow(cm, cmap='Blues')
plt.colorbar()
ticks = np.arange(num_classes)
plt.xticks(ticks, test_ds.classes, rotation=45)
plt.yticks(ticks, test_ds.classes)
plt.ylabel('True'); plt.xlabel('Predicted')

for i, j in np.ndindex(cm.shape):
    plt.text(j, i, cm[i, j], ha='center', va='center',
             color='white' if cm[i, j] > cm.max()/2 else 'black')
plt.tight_layout()
plt.savefig(f'{RUN_DIR}/confusion.png'); plt.show()

# --- 保存模型 ---
with open(f'{RUN_DIR}/classes.json', 'w', encoding='utf-8') as f:
    json.dump(train_ds.class_to_idx, f, ensure_ascii=False, indent=2)
torch.save(model.state_dict(), f'{RUN_DIR}/model.pth')
print(f'模型已保存至 {RUN_DIR}/model.pth')
