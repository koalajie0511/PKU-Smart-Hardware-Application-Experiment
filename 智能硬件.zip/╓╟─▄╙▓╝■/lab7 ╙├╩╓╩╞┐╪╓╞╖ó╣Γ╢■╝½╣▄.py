import time
address=0x20
i2c=I2C("/dev/i2c-7")
msgs=[I2C.Message([0xff])]
i2c.transfer(address,msgs)
def read_adc(i2c,channel=0):
    if channel<0 or channel>3:
        raise ValueError("Channel must be 0-3")
    control=0x40|channel
    msgs=[I2C.Message([control])]
    i2c.transfer(PCF8591_ADDR,msgs)
    msgs=[I2C.Message([0x00],read=True)]
    adc_value=msgs[0].data[0]
    i2c.transfer(PCF8591_ADDR,msgs)
    return adc_value
def write_dac(i2c,value):
    if not (0<=value<=255):
        raise ValueError("Value must be 0-255")
    msgs=[I2C.Message([0x40,value])]
    print(msgs)
    i2c.transfer(PCF8591_ADDR,msgs)
class GestureNet(nn.Module):
    def __init__(self, num_classes=4):
        super().__init__()
        self.net = nn.Sequential(
            # 卷积层1: 输入1通道, 输出6通道, 5x5卷积核
            nn.Conv2d(1, 6, 5), 
            nn.ReLU(),
            # 池化层1: 4x4最大池化
            nn.MaxPool2d(4),
            
            # 卷积层2: 输入6通道, 输出12通道, 5x5卷积核
            nn.Conv2d(6, 12, 5), 
            nn.ReLU(),
            # 池化层2: 4x4最大池化
            nn.MaxPool2d(4),
            
            # 展平特征图
            nn.Flatten(),
            
            # 全连接层
            nn.Linear(12 * 3 * 2, 60),  # 根据输入尺寸调整
            nn.ReLU(),
            nn.Linear(60, 30),
            nn.ReLU(),
            nn.Linear(30, num_classes)  # 输出层
        )
    
    def forward(self, x):
        return self.net(x)
model=GestureNet().to(DEVICE)
model.load_state_dict(torch.load("runs/model.pth",map_location=DEVICE))
model.eval()
try:
    while True:
        ret,frame=cap.read()
        HSV=cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)
        gray=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
        image_mask=cv2.inRange(HSV,np.array([0,0,0]),np.array([50,200,160]))
        output=cv2.bitwise_and(gray,gray,mask=image_mask)
        output=cv2.blur(output,(2,2))
        
except KeyboardInterrupt:
    cap.release()
finally:
    cap.release()
