import cv2
import numpy as np
cap=cv2.VideoCapture(0)
if not cap.isOpened():
    print("无法打开摄像头")
else:
    ret,frame=cap.read()
    if ret:
        cv2.imwrite("captured_image.jpg",frame)
        print("图片已保存为captured_image.jpg")
    else:
        print("无法读取摄像头画面")
image=cv2.imread("captured_image.jpg")
gray=cv2.cvtColor(image,cv2.COLOR_BGR2GRAY)
blurred=cv2.GaussianBlur(gray,(5,5),0)
_,thresh=cv2.threshold(blurred,127,255,cv2.THRESH_BINARY)
for contour in contours:
    peri=cv2.arcLength(contour,True)
    approx=cv2.approxPolyDP(contour,0.02*peri,True)
    if len(approx)==4:
        original_points= approx.reshape(4,2)
target_points = np.float32([
                [0, 0],          # 左上
                [400, 0],        # 右上
                [400, 300],      # 右下  
                [0, 300]         # 左下
            ])
perspective_matrix=cv.getPerspectiveTransform(original_points,target_points)
output_image=cv.warpPerspective(image,perspective_matrix,(width,height))
