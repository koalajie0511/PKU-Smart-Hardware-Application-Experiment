from pyswip import Prolog, registerForeign

# 初始化 Prolog 环境
prolog = Prolog()
prolog.consult("/home/student/lml_thurs/6.2.pl")  # 导入 Prolog 规则库

# 用于记录已回答的问题
qu = {}

# 定义 ask 函数：向用户提问并记录回答
def ask(question):
    print("Does the animal have the following attribute: " + str(question) + "?")
    response = input()
    if response == "yes" or response == "y":
        qu[question] = True
        return True
    else:
        qu[question] = False
        return False

# 定义 verify 函数：检查是否已回答，否则调用 ask
def verify(s):
    if s in qu:
        return qu[s]
    else:
        response = ask(s)
        return response

# 注册 verify 函数为 Prolog 可调用的外部函数
verify.arity = 1
registerForeign(verify)

# 执行查询并输出结果
for result in prolog.query("hypothesize(X)"):
    print(result["X"])
