#单舵机控制
import time
from periphery import GPIO
SERVO_GPIO=80
PWM_FREQ=50
PERIOD=1.0
def angle_to_pulse_width(angle):
    return 0.001+(angle/180)*0.001
def set_servo(gpio,angle):
    pulse_width=angle_to_pulse_width(angle)
    gpio.write(True)
    time.sleep(pulse_width)
    gpio.write(False)
    time.sleep(PERIOD-pulse_width)
def main():
    gpio=GPIO(SERVO_GPIO,"out")
    print("press ctrl+c to stop")
    try:
        while True:
            for _ in range(20):
                set_servo(gpio,90)
            time.sleep(1)
            for _ in range(20):
                set_servo(gpio,180)
            time.sleep(1)
    except KeyboardInterrupt:
        print("Stopping!")
    finally:
        gpio.write(False)
        gpio.close()
if __name__=="__main__":
    main()


#多舵机控制
from time import sleep
from adafruit_servokit import ServoKit
kit=ServoKit(channels=16)
kit.servo[0].angle=175
sleep(1)
kit.servo[0].angle=45
sleep(1)
