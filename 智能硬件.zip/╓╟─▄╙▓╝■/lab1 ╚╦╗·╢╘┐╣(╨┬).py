from periphery import GPIO
import random
import time
buttons={GPIO(82,"in"),GPIO(38,"in"),GPIO(79,"in")}
buttons[0].edge="falling"
buttons[1].edge="falling"
buttons[2].edge="falling"
gpio=GPIO(3,"out")
pinnum=[1,1,1]
probability=[1/3,2/3]
scores={"player":0,"computer":0,"tie":0}
win={82:79,38:82,79:38}
tot=3
def judgewin(pin,machine):
    if pin==machine:
        scores["tie"]+=1
        return 0
    elif machine==win[pin]:
        scores["player"]+=1
        return 1
    else:
        scores["computer"]+=1
        return 2
def prob():
    probability[0]=pinnum[0]/tot
    probability[1]=(pinnum[0]+pinnum[1])/tot
def generate_machine():
    temp=random.random()
    if temp<probability[0]:
        return 38
    elif temp<probability[1]:
        return 79
    else:
        return 82
try:
    for button in buttons:
        button.read()   
    while True:
        for button in buttons:
            button.read()
        machine=generate_machine()
        events=GPIO.poll_multiple(buttons,timeout=1.0)
        if not events:
            continue
        for button in events:
            pin=button.line
        #gpio.write(True)
        if pin==82:
            pinnum[0]+=1
            print('82')
        elif pin==38:
            pinnum[1]+=1
            print('38')
        else:
            pinnum[2]+=1
            print('79')
        tot+=1
        prob()
        gpio.read()
        button.read()
        state=judgewin(pin,machine)
        #gpio.write(false)
        if state==0:
            print('Tie!')
        elif state==1:
            print("Player Wins!");
        else:
            print("Computer Wins!");
            print("---Total Scores---")
            print("player:{} computer:{} Tie:{}".format(scores["player"],scores["computer"],scores["tie'])
            time.sleep(0.5)
except KeyboardInterrupt:
    print("\n program stopped by user!");
finally:
    gpio.write(false)
    gpio.close()
    for button in buttons:
    button.close()
