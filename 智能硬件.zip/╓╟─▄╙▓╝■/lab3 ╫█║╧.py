import cv2
from IPython.display import display
import ipywidgets as widgets
from io import BytesIO
import numpy as np

cap = cv2.VideoCapture(0)
if not cap.isOpened():
    print("无法打开摄像头")
else:
    # 分别显示原始图像和过滤后的图像
    original_image_widget = widgets.Image(format="jpeg", description="原始图像")
    filtered_image_widget = widgets.Image(format="jpeg", description="皮肤颜色过滤")
    display(widgets.HBox([original_image_widget, filtered_image_widget]))
    
    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                print("无法接收")
                break
            
            # 转换为HSV颜色空间
            hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
            
            # 皮肤颜色的HSV范围（需要根据实际光照条件微调）
            # 范围1：适用于较浅肤色
            lower_skin1 = np.array([0, 20, 70])
            upper_skin1 = np.array([20, 150, 255])
            
            # 范围2：适用于较深肤色
            lower_skin2 = np.array([0, 20, 70])
            upper_skin2 = np.array([20, 150, 255])
            
            # 创建皮肤颜色的掩码
            mask1 = cv2.inRange(hsv, lower_skin1, upper_skin1)
            mask2 = cv2.inRange(hsv, lower_skin2, upper_skin2)
            skin_mask = mask1 + mask2
            
            # 对掩码进行形态学操作，去除噪声
            kernel = np.ones((5,5), np.uint8)
            skin_mask = cv2.morphologyEx(skin_mask, cv2.MORPH_OPEN, kernel)
            skin_mask = cv2.morphologyEx(skin_mask, cv2.MORPH_CLOSE, kernel)
            
            # 应用掩码
            output = cv2.bitwise_and(frame, frame, mask=skin_mask)
            
            # 编码原始图像
            is_success, original_buffer = cv2.imencode(".jpg", frame)
            if is_success:
                original_io_buf = BytesIO(original_buffer)
                original_image_widget.value = original_io_buf.getvalue()
            else:
                print("原始图像编码失败")
            
            # 编码过滤后的图像
            is_success, filtered_buffer = cv2.imencode(".jpg", output)
            if is_success:
                filtered_io_buf = BytesIO(filtered_buffer)
                filtered_image_widget.value = filtered_io_buf.getvalue()
            else:
                print("过滤图像编码失败")
                
    except KeyboardInterrupt:
        print("用户中断")
    finally:
        cap.release()







import cv2 as cv
import numpy as np
import time
from IPython.display import display
import ipywidgets as widgets

cap = cv.VideoCapture(0)

if cap.isOpened():
    image_widget = widgets.Image(format="jpeg")
    display(image_widget)
    
    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            
            # 应用中值模糊
            frame = cv.medianBlur(frame, 5)
            
            # 将彩色图像转换为灰度图像用于霍夫圆检测
            gray = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)
            
            # 适中的霍夫圆检测参数 - 检测适量的圆
            circles = cv.HoughCircles(gray, cv.HOUGH_GRADIENT, 
                                    dp=1,           # 累加器分辨率与图像分辨率的反比
                                    minDist=30,     # 检测到的圆心之间的最小距离（适中）
                                    param1=80,      # Canny边缘检测的高阈值（适中）
                                    param2=35,      # 累加器阈值（适中）
                                    minRadius=5,    # 最小圆半径
                                    maxRadius=150)  # 最大圆半径
            
            # 创建用于显示结果的图像副本
            cframe = frame.copy()
            
            if circles is not None:
                circles = np.uint16(np.around(circles))
                print(f"检测到 {len(circles[0])} 个圆")  # 调试信息
                
                # 为不同的圆使用不同颜色
                colors = [(0, 255, 0), (255, 0, 0), (0, 255, 255), (255, 0, 255), (255, 255, 0)]
                
                for idx, i in enumerate(circles[0, :]):
                    color = colors[idx % len(colors)]  # 循环使用颜色
                    # 绘制外圆
                    cv.circle(cframe, (i[0], i[1]), i[2], color, 2)
                    # 绘制圆心
                    cv.circle(cframe, (i[0], i[1]), 2, color, 3)
                    # 显示圆心坐标和半径
                    cv.putText(cframe, f"r:{i[2]}", 
                              (i[0]-20, i[1]-i[2]-10), cv.FONT_HERSHEY_SIMPLEX, 
                              0.4, color, 1)
            
            # 在Jupyter notebook中显示图像
            cframe_rgb = cv.cvtColor(cframe, cv.COLOR_BGR2RGB)
            _, encoded_image = cv.imencode('.jpeg', cframe_rgb)
            image_widget.value = encoded_image.tobytes()
            
            time.sleep(0.03)
            
    except KeyboardInterrupt:
        print("用户中断")
    finally:
        cap.release()

























import cv2 as cv
import numpy as np
from IPython.display import display, Image
import ipywidgets as widgets
import threading
import time

# 创建界面组件
image_widget = widgets.Image(format='jpeg', width=640, height=480)
capture_button = widgets.Button(description="拍摄并分析", button_style='success')
restart_button = widgets.Button(description="重新预览", button_style='info')
output_widget = widgets.Output()

# 布局
vbox = widgets.VBox([image_widget, 
                     widgets.HBox([capture_button, restart_button]), 
                     output_widget])
display(vbox)

# 全局变量
cap = None
is_preview = True
preview_thread = None
current_frame = None
frame_lock = threading.Lock()

def preview_loop():
    """实时预览循环"""
    global cap, is_preview, current_frame
    try:
        cap = cv.VideoCapture(0)
        if not cap.isOpened():
            with output_widget:
                print("错误: 无法打开摄像头")
            return
        
        while is_preview and cap.isOpened():
            ret, frame = cap.read()
            if ret:
                with frame_lock:
                    current_frame = frame.copy()
                # 实时显示原始图像
                _, jpeg_data = cv.imencode('.jpeg', frame)
                image_widget.value = jpeg_data.tobytes()
            time.sleep(0.03)  # 约30fps
    except Exception as e:
        with output_widget:
            print(f"预览错误: {e}")
    finally:
        if cap:
            cap.release()

def start_preview():
    """开始实时预览"""
    global is_preview, preview_thread
    is_preview = True
    
    # 如果已有预览线程在运行，先停止它
    if preview_thread and preview_thread.is_alive():
        return
    
    preview_thread = threading.Thread(target=preview_loop)
    preview_thread.daemon = True
    preview_thread.start()

def capture_and_analyze(button):
    global is_preview, current_frame
    
    if current_frame is None:
        with output_widget:
            print("错误: 没有可用的图像帧")
        return
    
    # 停止预览
    is_preview = False
    
    # 等待一小段时间确保预览线程收到停止信号
    time.sleep(0.1)
    
    # 获取当前帧的副本
    with frame_lock:
        captured_frame = current_frame.copy() if current_frame is not None else None
    
    if captured_frame is None:
        with output_widget:
            print("错误: 无法捕获图像")
        # 重新开始预览
        start_preview()
        return
    
    # 显示"处理中"提示
    with output_widget:
        output_widget.clear_output()
        print("正在分析图像...")
    
    # 处理图像
    process_captured_image(captured_frame)

def process_captured_image(frame):
    """处理拍摄的图像"""
    try:
        # 处理图像
        framegray = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)
        ret, thresh = cv.threshold(framegray, 127, 255, 0)
        contours, hierarchy = cv.findContours(thresh, cv.RETR_TREE, cv.CHAIN_APPROX_SIMPLE)
        
        # 创建带轮廓的图像
        result_frame = frame.copy()
        
        if len(contours) > 0:
            # 绘制所有轮廓
            cv.drawContours(result_frame, contours, -1, (0, 255, 0), 2)
            
            # 计算周长统计
            perimeters = [cv.arcLength(cnt, True) for cnt in contours]
            total_perimeter = sum(perimeters)
            
            # 显示处理后的图像
            _, result_jpeg = cv.imencode('.jpeg', result_frame)
            image_widget.value = result_jpeg.tobytes()
            
            # 输出统计信息
            with output_widget:
                output_widget.clear_output()
                print("🎯 轮廓分析完成！")
                print("=" * 30)
                print(f"📊 轮廓总数: {len(contours)}")
                print(f"📏 总周长: {total_perimeter:.2f} 像素")
                print(f"📐 平均周长: {total_perimeter/len(contours):.2f} 像素")
                print(f"⬆️  最大周长: {max(perimeters):.2f} 像素")
                print(f"⬇️  最小周长: {min(perimeters):.2f} 像素")
                print("\n各轮廓周长:")
                for i, p in enumerate(perimeters):
                    print(f"  轮廓 {i+1}: {p:.2f} 像素")
                print("=" * 30)
                print("点击'重新预览'可以再次拍摄")
        else:
            # 显示原始图像（无轮廓）
            _, original_jpeg = cv.imencode('.jpeg', frame)
            image_widget.value = original_jpeg.tobytes()
            
            with output_widget:
                output_widget.clear_output()
                print("❌ 未检测到任何轮廓")
                print("点击'重新预览'可以再次拍摄")
                
    except Exception as e:
        with output_widget:
            output_widget.clear_output()
            print(f"❌ 处理图像时发生错误: {e}")

def restart_preview(button):
    """重新开始预览"""
    global is_preview, cap
    
    # 确保摄像头已释放
    if cap:
        cap.release()
        cap = None
    
    # 开始新的预览
    start_preview()
    
    with output_widget:
        output_widget.clear_output()
        print("📷 实时预览已启动")
        print("请对准目标，然后点击'拍摄并分析'")

# 绑定按钮事件
capture_button.on_click(capture_and_analyze)
restart_button.on_click(restart_preview)

# 开始实时预览
start_preview()

with output_widget:
    print("📷 实时预览已启动")
    print("请对准目标，然后点击'拍摄并分析'")
    print("拍摄后图像将被分析，轮廓将以绿色显示")















import cv2 as cv
from IPython.display import display
import ipywidgets as widgets
from io import BytesIO
import numpy as np
def frame_to_bytes(frame, fmt='jpeg', quality=80):
    success, buffer = cv.imencode(f'.{fmt}', frame, [cv.IMWRITE_JPEG_QUALITY, quality])
    if success:
        return buffer.tobytes()
    else:
        return None
cap = cv.VideoCapture(1)
if not cap.isOpened():
    print("无法打开摄像头")
else:
    original_image_widget = widgets.Image(format="jpeg", description="原始图像", width=400, height=300)
    filtered_image_widget = widgets.Image(format="jpeg", description="透视变换", width=400, height=300)
    display(widgets.HBox([original_image_widget, filtered_image_widget]))
    width = 640
    height = 480
    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                print("无法接收帧")
                break
            original_resized = cv.resize(frame, (400, 300))
            original_points = np.float32([
                [100, 100],      # 左上
                [540, 100],      # 右上  
                [540, 380],      # 右下
                [100, 380]       # 左下
            ])
            
            target_points = np.float32([
                [0, 0],          # 左上
                [400, 0],        # 右上
                [400, 300],      # 右下  
                [0, 300]         # 左下
            ])
            
            perspective_matrix = cv.getPerspectiveTransform(original_points, target_points)
            output_image = cv.warpPerspective(frame, perspective_matrix, (400, 300))
            frame_with_points = frame.copy()
            cv.polylines(frame_with_points, [original_points.astype(int)], True, (0, 255, 0), 2)
            original_resized = cv.resize(frame_with_points, (400, 300))
            original_bytes = frame_to_bytes(original_resized)
            filtered_bytes = frame_to_bytes(output_image)
            if original_bytes and filtered_bytes:
                original_image_widget.value = original_bytes
                filtered_image_widget.value = filtered_bytes
    except KeyboardInterrupt:
        print("用户中断")
    finally:
        cap.release()
        print("摄像头已释放")






