import cv2 as cv
import numpy as np
import time
cap=cv2.VideoCapture(0)
if cap.isOpened():
    image_widget=widgets.Image(format="jpeg")
    display(image_widget)
    try:
        while True:
            ret,frame=cap.read()
            if not ret:
                break
            is_success,buffer=cv2.imencode(".jpg",frame)
            if is_success:
                io_buf=BytesIO(buffer)
                image_widget.value=io_buf.getvalue()
            else:
                print("图像编码失败")
    except KeyboardInterrupt:
        print("用户中断")
    finally:
        cap.release()
    
